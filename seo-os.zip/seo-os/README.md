# SEO OS — Autonomous SEO Intelligence & Growth Operating System

A modular, multi-agent SEO system that crawls a site, builds a persistent
knowledge graph of it, audits it against real observed data, prioritizes
findings with a transparent scoring formula, and turns them into
change-managed, approvable/rollback-able actions. Nothing here fabricates
rankings, traffic, search volume, or backlinks — anything that needs an
external data source you haven't configured is explicitly labeled
`unavailable`, never guessed.

## Quick start

```bash
pip install -r requirements.txt

# Run a full audit against a real site (or the bundled fixture site — see tests/)
python3 -m seo_os.cli audit https://example.com

# See what was found, ranked by priority score
python3 -m seo_os.cli opportunities https://example.com --limit 20

# Generate a report
python3 -m seo_os.cli report https://example.com --format html --out report.html

# Review + approve/reject proposed actions (nothing auto-applies)
python3 -m seo_os.cli plan https://example.com
python3 -m seo_os.cli approve https://example.com 1
python3 -m seo_os.cli apply https://example.com 1
python3 -m seo_os.cli rollback https://example.com 1
```

Data persists in a local SQLite file (`./data/seo_os.sqlite3` by default —
see `SEO_OS_DB`). Re-running `audit` on the same URL starts a new crawl run
and layers new findings onto the same knowledge graph, so history
accumulates instead of being thrown away.

## What's real vs. what's a stub

This was built in a sandboxed environment with **no outbound network
access**, so it could not be tested against the live internet or against
real Google Search Console / GA4 / Ahrefs / Semrush accounts. Concretely:

| Component | Status |
|---|---|
| Crawler, technical SEO audit, internal linking, schema audit, keyword heuristics, priority engine, change management, QA, CLI, reporting | **Real, working code**, tested end-to-end against a live local HTTP server with 17 deliberately seeded issues (see `tests/`) |
| Google Search Console / GA4 / Ahrefs / Semrush / PageSpeed / Bing Webmaster providers | **Real client wiring**, gated behind `is_configured()`. They read credentials from env vars and would make real API calls — but calling out to `googleapis.com` etc. was not possible to verify from this sandbox. Until configured, every method returns an explicit "unavailable" result rather than fake data. |
| Content creation/optimization, competitor intelligence, SERP intelligence, local SEO, programmatic SEO, backlink/authority, AI-search-visibility, and experiment agents from the original spec | **Not built.** These fundamentally depend on live SERP/competitor/analytics data or an LLM content-generation call this sandbox can't make. The architecture (provider interfaces, Agent base class, knowledge graph schema, priority engine, change management) is already in place for them — adding one is "write a new Agent subclass that emits Issues," not a redesign. See `docs/ROADMAP.md`. |

See `docs/CONFIGURATION.md` for how to turn on each external provider.

## Architecture

```
seo_os/
  config.py          Central config, all secrets via env vars only
  observability.py   Structured JSON logging, request-id correlation, secret redaction
  db.py               SQLite-backed SEO Knowledge Graph (pages, links,
                       keywords, issues, actions, experiments, agent logs,
                       long-term memory) — see docs/ARCHITECTURE.md
  security/
    url_safety.py       SSRF protection: resolves DNS, blocks private/
                         loopback/link-local targets on every fetch + redirect hop
  providers/
    base.py            Vendor-independent interfaces (CrawlerProvider,
                        SearchConsoleProvider, AnalyticsProvider,
                        SERPProvider, KeywordDataProvider, BacklinkProvider,
                        PageSpeedProvider, LLMProvider)
    http_crawler.py     Real requests-based crawler: SSRF-checked, manual
                        redirect-chain tracking + loop detection, retry/
                        backoff, response-size cap
    unconfigured_providers.py  GSC/GA4/Ahrefs/Semrush/PSI — real client
                        wiring, "unavailable" until credentials are set
  agents/
    base.py             Agent base class: every run is logged (timestamp,
                         agent, task, input, decision, confidence, result,
                         error, duration) to both the DB and structured logs
    crawler_agent.py     Site Crawler Agent (concurrent, per-host rate
                         limited, sitemap-index recursion, hreflang/image
                         extraction)
    technical_seo_agent.py   Technical SEO Agent (20 rule-based checks)
    internal_linking_agent.py  Internal Linking Agent (graph-based)
    schema_agent.py       Schema/structured data Agent
    keyword_agent.py      Keyword Intelligence Agent (heuristic, no fake volume)
    qa_agent.py           SEO QA Agent (pre-apply checks)
    priority_engine.py    Impact × Confidence × BusinessValue × Urgency /
                           (Effort × Risk) scoring, 0–100
    orchestrator.py       Runs the full loop, proposes idempotency-keyed,
                           change-managed actions
  reporting/
    report.py            Markdown + HTML dashboard rendering
  cli.py                Command-line interface (incl. `seo health`)

tests/
  fixtures/fixture_site.py   A small Flask site with 25+ deliberately
                              seeded SEO issues (broken links, redirect
                              chains/loops, canonical loops, bad hreflang,
                              missing alt text, etc.), used for real (not
                              mocked) end-to-end testing
  test_*.py                   pytest-style tests (45, all passing)
  run_all_tests.py            Runs the same tests without needing the
                               pytest package installed (see tests/README.md)
  conftest.py                  Real pytest fixtures, for use wherever
                                pytest is installable
```

### The Knowledge Graph

Everything is stored relationally in SQLite (`seo_os/db.py`) rather than a
bespoke graph database — at single-site scale this is simpler to operate,
inspect, and back up, while still expressing every relationship the spec
calls for: `sites → crawl_runs → pages → links`, `keywords ↔ pages`,
`issues → actions`, plus `agent_runs` (observability) and `memory`
(long-term recommendations/business rules). See `docs/ARCHITECTURE.md` for
the full schema and example queries answering things like "which pages
compete for the same intent" or "which high-value pages are poorly
internally linked."

### Change management

Every finding an agent produces becomes an `issue`. The orchestrator turns
open issues into `actions`, each risk-classified (low/medium/high — see
`RISK_BY_ISSUE_TYPE` in `orchestrator.py`). Actions start `proposed` and
require explicit `approve` before `apply`; every action keeps a
`before_state`/`after_state` snapshot so it can be `rollback`ed. Nothing
auto-applies unless you explicitly set `SEO_OS_AUTO_LOW_RISK=1`, and even
then it still runs through the same approve/apply/log pipeline rather than
mutating anything silently — and this build does not wire `apply` to any
real CMS write; it only advances the change record's status. Connecting
`apply` to a real site (WordPress, a static-site rebuild, etc.) is a
CMSProvider you plug in for your own stack.

## Commands

```
seo audit <url> [--brand term1,term2] [--allow-private-targets]
                                            Full pipeline: crawl → technical
                                            → internal-links → schema →
                                            keywords → business-goal
                                            reweighting → prioritize → propose
seo crawl <url> [--allow-private-targets]   Crawl only
seo technical <url> [--crawl-run-id N]      Technical audit only
seo internal-links <url> [--crawl-run-id N] Internal linking analysis only
seo schema <url> [--crawl-run-id N]         Structured data audit only
seo keywords <url> [--crawl-run-id N] [--brand ...]  Keyword analysis only
seo opportunities <url> [--limit N]         Ranked backlog
seo report <url> [--format md|html] [--out FILE]
seo plan <url>                              List actions awaiting approval
seo approve <url> <action_id>
seo reject <url> <action_id>
seo apply <url> <action_id>
seo rollback <url> <action_id>
seo health                                  DB + provider configuration status (no network calls)
seo goals list <url>
seo goals add <url> --kind KIND --label TEXT [--weight N] [--notes TEXT]
seo goals update <url> <goal_id> [--kind ...] [--label ...] [--weight ...]
seo goals remove <url> <goal_id>
seo history <url> <page_url>                Full historical snapshot log for one page
seo changes <url> [--from-run N --to-run M] What changed between two crawl runs (defaults to latest two)
```

## Configuration

All config is environment variables — nothing is hard-coded, no secrets in
source. See `docs/CONFIGURATION.md` for the full list (crawl limits,
risk/approval policy, and every provider's credential variable).

## Security

- Crawled page content is treated as untrusted data at every layer — the
  crawler extracts structured fields (title, headings, links, JSON-LD) and
  never executes or interprets page content as instructions. No agent
  prompt in this system is ever built by concatenating raw crawled HTML
  into an LLM system prompt.
- All credentials come from environment variables; `config.py` is the only
  place they're read, and nothing is logged.
- The crawler respects `robots.txt` by default (`SEO_OS_RESPECT_ROBOTS=0`
  to override, e.g. for your own staging site).
- Structured-data suggestions explicitly exclude `Review`/`AggregateRating`
  — see `schema_agent.SAFE_TO_SUGGEST` — because generating those without
  real, legitimately collected review data would be deceptive markup.

## Testing

```bash
python3 tests/run_all_tests.py     # works with no packages beyond requirements.txt
# or, in an environment with network access:
pip install pytest && pytest tests/ -v
```

55/55 tests passing as of this build (up from 27 in the initial pass),
covering the crawler (incl. SSRF protection, redirect chains/loops),
technical audit (22 checks), internal linking, schema validation, the
priority formula (now driven by configurable business goals), historical
page snapshots/diffing, and the full QA/approve/apply/rollback
change-management flow with idempotency — all against a real HTTP server
(`tests/fixtures/fixture_site.py`), not mocks. See `docs/CHANGELOG.md` for
what changed in each pass.

## Security

Also see `docs/AUDIT.md` for the full security audit this pass performed.
Headline item: the crawler now has real **SSRF protection**
(`seo_os/security/url_safety.py`) — every fetch and every redirect hop
resolves DNS and blocks loopback/private/link-local/reserved targets
(including cloud metadata endpoints like `169.254.169.254`) by default,
with DNS-rebinding covered since the check runs on the resolved IP, not
the hostname string. `SEO_OS_ALLOW_PRIVATE_TARGETS=1` / `--allow-private-targets`
opts in explicitly when you're intentionally crawling an internal/staging
target.

## Known limitations

- No live network access was available while building this, so GSC/GA4/
  Ahrefs/Semrush/PageSpeed integrations are wired but unverified against
  real APIs, and only a local fixture site (not a live production website)
  was used for end-to-end testing.
- Keyword intent classification and internal-link relevance are
  transparent keyword-overlap heuristics, not a semantic/embedding model —
  they're intentionally labeled lower-confidence and flagged for human
  review rather than presented as certain.
- Content creation/optimization, competitor intelligence, SERP
  intelligence, local SEO, programmatic SEO, backlink strategy, and
  experiment-tracking agents are not implemented (see `docs/ROADMAP.md`).
- `apply_action` advances the change-management record but does not push
  changes to a live CMS — see "Change management" above.
- No JavaScript rendering (Playwright/browser provider) — crawler sees
  only server-rendered HTML.
- Optional browser-based rendering, REST API + auth/RBAC, web dashboard,
  job queue/workers, and scheduling are not implemented — all require
  either a browser runtime, a persistent server process, or infrastructure
  this sandboxed session doesn't have a way to test against realistically.

## Recommended next steps

See `docs/ROADMAP.md` for a prioritized list — it uses this same system's
own priority formula to rank what to build next.
