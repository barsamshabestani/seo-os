"""
Central configuration for the SEO Operating System.

All secrets/credentials are read from environment variables. Nothing is
ever hard-coded. If a credential is missing, the relevant provider must
raise ProviderNotConfigured rather than fabricate data.
"""
from __future__ import annotations
import os
from dataclasses import dataclass, field


class ProviderNotConfigured(RuntimeError):
    """Raised when a provider is used without the credentials it needs."""


@dataclass
class CrawlConfig:
    max_pages: int = int(os.environ.get("SEO_OS_MAX_PAGES", "500"))
    max_depth: int = int(os.environ.get("SEO_OS_MAX_DEPTH", "10"))
    concurrency: int = int(os.environ.get("SEO_OS_CONCURRENCY", "4"))
    per_host_min_interval_seconds: float = float(os.environ.get("SEO_OS_PER_HOST_DELAY", "0.0"))
    request_delay_seconds: float = float(os.environ.get("SEO_OS_DELAY", "0.0"))
    user_agent: str = os.environ.get(
        "SEO_OS_USER_AGENT", "SEO-OS-Bot/1.0 (+https://example.invalid/seo-os)"
    )
    timeout_seconds: float = float(os.environ.get("SEO_OS_TIMEOUT", "10"))
    respect_robots: bool = os.environ.get("SEO_OS_RESPECT_ROBOTS", "1") != "0"
    max_response_bytes: int = int(os.environ.get("SEO_OS_MAX_RESPONSE_BYTES", str(20 * 1024 * 1024)))
    max_retries: int = int(os.environ.get("SEO_OS_MAX_RETRIES", "2"))
    # SSRF policy: by default, private/loopback/link-local targets are refused.
    # Set SEO_OS_ALLOW_PRIVATE_TARGETS=1 for intentional internal/staging
    # crawls (e.g. this project's own local fixture-site tests).
    allow_private_targets: bool = os.environ.get("SEO_OS_ALLOW_PRIVATE_TARGETS", "0") == "1"


@dataclass
class RiskConfig:
    """Which action categories require explicit human approval."""
    low_risk_auto_apply: bool = os.environ.get("SEO_OS_AUTO_LOW_RISK", "0") == "1"
    high_risk_requires_approval: bool = True
    medium_risk_requires_approval: bool = os.environ.get(
        "SEO_OS_MEDIUM_REQUIRES_APPROVAL", "1"
    ) != "0"


@dataclass
class AppConfig:
    db_path: str = os.environ.get("SEO_OS_DB", "./data/seo_os.sqlite3")
    log_dir: str = os.environ.get("SEO_OS_LOG_DIR", "./logs")
    crawl: CrawlConfig = field(default_factory=CrawlConfig)
    risk: RiskConfig = field(default_factory=RiskConfig)

    # External provider credentials (all optional; providers degrade
    # gracefully to "unavailable" when unset instead of inventing data).
    gsc_service_account_json: str | None = os.environ.get("GSC_SERVICE_ACCOUNT_JSON")
    ga4_property_id: str | None = os.environ.get("GA4_PROPERTY_ID")
    ahrefs_api_key: str | None = os.environ.get("AHREFS_API_KEY")
    semrush_api_key: str | None = os.environ.get("SEMRUSH_API_KEY")
    pagespeed_api_key: str | None = os.environ.get("PAGESPEED_API_KEY")
    bing_webmaster_api_key: str | None = os.environ.get("BING_WEBMASTER_API_KEY")


CONFIG = AppConfig()
