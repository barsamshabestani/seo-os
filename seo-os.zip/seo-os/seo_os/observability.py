"""
Structured logging (Phase 28). Every log line is a single JSON object so
it's machine-parseable by any log aggregator without a custom parser.

This supplements, not replaces, the `agent_runs` DB table (agents/base.py):
the DB table is the durable, queryable record; this module is for
real-time operational visibility (stdout/file) during a run, including
things that happen outside an Agent.run() context (CLI invocations, DB
migrations, provider errors).

Secret redaction: any field whose key matches a sensitive-looking pattern
(key, token, secret, password, credential, authorization) has its value
replaced before serialization -- this is the concrete implementation of
"never log sensitive data" (Phase 27).
"""
from __future__ import annotations
import json
import logging
import os
import re
import sys
import time
import uuid
from contextvars import ContextVar

_SENSITIVE_KEY_PATTERN = re.compile(r"(key|token|secret|password|credential|authorization)", re.IGNORECASE)

_request_id: ContextVar[str] = ContextVar("request_id", default="")


def new_request_id() -> str:
    """Call once per top-level operation (a CLI command, an API request, a
    scheduled job run) so every log line and agent_runs row emitted during
    it can be correlated."""
    rid = uuid.uuid4().hex[:16]
    _request_id.set(rid)
    return rid


def current_request_id() -> str:
    return _request_id.get()


def _redact(obj):
    if isinstance(obj, dict):
        return {
            k: ("***REDACTED***" if _SENSITIVE_KEY_PATTERN.search(str(k)) else _redact(v))
            for k, v in obj.items()
        }
    if isinstance(obj, (list, tuple)):
        return [_redact(v) for v in obj]
    return obj


class JSONFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created)),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "request_id": current_request_id(),
        }
        extra = getattr(record, "fields", None)
        if extra:
            payload.update(_redact(extra))
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


def get_logger(name: str = "seo_os") -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger  # already configured (avoid duplicate handlers on repeat calls)
    logger.setLevel(os.environ.get("SEO_OS_LOG_LEVEL", "INFO"))
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(JSONFormatter())
    logger.addHandler(handler)
    logger.propagate = False
    return logger


def log_event(logger: logging.Logger, level: str, message: str, **fields):
    """Convenience wrapper: log_event(logger, 'info', 'crawl started',
    site_id=1, agent='site_crawler_agent') emits one structured JSON line."""
    getattr(logger, level.lower())(message, extra={"fields": fields})
