"""
The SEO Knowledge Graph, persisted in SQLite.

This is intentionally relational rather than a bespoke graph database:
SQLite is zero-config, transactional, inspectable with any SQL client,
and perfectly capable of expressing the graph via foreign keys/junction
tables at the scale a single-site SEO OS operates at. Every table maps
to a node or edge type described in the project spec (section 5).

All writes go through this module so every agent shares one consistent
model of the site instead of re-deriving it independently.
"""
from __future__ import annotations
import json
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterable, Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS sites (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    root_url TEXT UNIQUE NOT NULL,
    name TEXT,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS crawl_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    site_id INTEGER NOT NULL REFERENCES sites(id),
    started_at REAL NOT NULL,
    finished_at REAL,
    pages_crawled INTEGER DEFAULT 0,
    status TEXT DEFAULT 'running'
);

-- Node: URL / Page
CREATE TABLE IF NOT EXISTS pages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    site_id INTEGER NOT NULL REFERENCES sites(id),
    crawl_run_id INTEGER REFERENCES crawl_runs(id),
    url TEXT NOT NULL,
    normalized_url TEXT NOT NULL,
    status_code INTEGER,
    content_type TEXT,
    canonical_url TEXT,
    is_indexable INTEGER,
    noindex INTEGER DEFAULT 0,
    title TEXT,
    meta_description TEXT,
    h1 TEXT,
    word_count INTEGER,
    content_hash TEXT,
    template_hint TEXT,
    redirect_target TEXT,
    depth INTEGER,
    discovered_via TEXT,
    fetched_at REAL,
    raw_headings TEXT,      -- JSON list of {level, text}
    structured_data TEXT,   -- JSON list of parsed JSON-LD blocks
    hreflang TEXT,          -- JSON list of {lang, url}
    images TEXT,            -- JSON list of {src, alt, has_dimensions}
    redirect_chain TEXT,    -- JSON list of {url, status_code} hops before the final response
    x_robots_tag TEXT,      -- raw X-Robots-Tag response header, if present
    response_truncated INTEGER DEFAULT 0,  -- response exceeded max_response_bytes
    html_size_bytes INTEGER,  -- raw response body size in bytes
    pagination TEXT,        -- JSON {"next": url|null, "prev": url|null} from rel=next/prev
    UNIQUE(site_id, normalized_url)
);

-- Historical snapshot: one immutable row per page per crawl_run, so a
-- page's previous SEO state is never lost when it's re-crawled (the
-- `pages` table above stays a fast "current state" table; this is the
-- append-only history behind it).
CREATE TABLE IF NOT EXISTS page_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    site_id INTEGER NOT NULL REFERENCES sites(id),
    page_id INTEGER NOT NULL REFERENCES pages(id),
    crawl_run_id INTEGER NOT NULL REFERENCES crawl_runs(id),
    normalized_url TEXT NOT NULL,
    status_code INTEGER,
    canonical_url TEXT,
    is_indexable INTEGER,
    noindex INTEGER,
    title TEXT,
    meta_description TEXT,
    h1 TEXT,
    word_count INTEGER,
    content_hash TEXT,
    html_size_bytes INTEGER,
    snapshot_at REAL NOT NULL,
    UNIQUE(page_id, crawl_run_id)
);
CREATE INDEX IF NOT EXISTS idx_page_snapshots_page ON page_snapshots(page_id, snapshot_at);
CREATE TABLE IF NOT EXISTS links (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    site_id INTEGER NOT NULL REFERENCES sites(id),
    source_page_id INTEGER NOT NULL REFERENCES pages(id),
    target_url TEXT NOT NULL,
    target_page_id INTEGER REFERENCES pages(id),
    anchor_text TEXT,
    rel TEXT,
    is_internal INTEGER,
    UNIQUE(source_page_id, target_url, anchor_text)
);

-- Node: Keyword
CREATE TABLE IF NOT EXISTS keywords (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    site_id INTEGER NOT NULL REFERENCES sites(id),
    keyword TEXT NOT NULL,
    intent TEXT,                 -- informational/commercial/transactional/navigational/unknown
    cluster TEXT,
    search_volume INTEGER,       -- NULL unless from a real provider
    search_volume_source TEXT,   -- provider name, or NULL
    difficulty REAL,
    difficulty_source TEXT,
    notes TEXT,
    created_at REAL NOT NULL,
    UNIQUE(site_id, keyword)
);

-- Edge: keyword <-> page mapping (targeting or cannibalization candidate)
CREATE TABLE IF NOT EXISTS keyword_page_map (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    keyword_id INTEGER NOT NULL REFERENCES keywords(id),
    page_id INTEGER NOT NULL REFERENCES pages(id),
    relevance_score REAL,
    match_reason TEXT,
    UNIQUE(keyword_id, page_id)
);

-- Node: Issue / Opportunity produced by any agent
CREATE TABLE IF NOT EXISTS issues (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    site_id INTEGER NOT NULL REFERENCES sites(id),
    crawl_run_id INTEGER REFERENCES crawl_runs(id),
    agent TEXT NOT NULL,
    issue_type TEXT NOT NULL,
    severity TEXT NOT NULL,         -- critical/high/medium/low
    confidence REAL NOT NULL,       -- 0-1
    title TEXT NOT NULL,
    evidence TEXT,                  -- JSON
    affected_page_ids TEXT,         -- JSON list of page ids
    business_impact TEXT,
    seo_impact TEXT,
    recommended_fix TEXT,
    implementation_effort TEXT,     -- low/medium/high
    risk_level TEXT,                -- low/medium/high
    priority_score REAL,
    status TEXT DEFAULT 'open',     -- open/approved/rejected/applied/rolled_back
    created_at REAL NOT NULL
);

-- Change management: proposed/applied actions with approval + rollback
CREATE TABLE IF NOT EXISTS actions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    site_id INTEGER NOT NULL REFERENCES sites(id),
    issue_id INTEGER REFERENCES issues(id),
    action_type TEXT NOT NULL,
    description TEXT NOT NULL,
    risk_level TEXT NOT NULL,
    before_state TEXT,             -- JSON snapshot
    after_state TEXT,              -- JSON snapshot (proposed or applied)
    idempotency_key TEXT,          -- dedupe key; same key = same logical change, don't re-propose
    status TEXT DEFAULT 'proposed', -- proposed/approved/rejected/applied/rolled_back
    created_at REAL NOT NULL,
    decided_at REAL,
    decided_by TEXT,
    applied_at REAL,
    rolled_back_at REAL,
    UNIQUE(site_id, idempotency_key)
);

-- Experiments
CREATE TABLE IF NOT EXISTS experiments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    site_id INTEGER NOT NULL REFERENCES sites(id),
    name TEXT NOT NULL,
    hypothesis TEXT,
    baseline TEXT,          -- JSON
    change_description TEXT,
    expected_result TEXT,
    success_metric TEXT,
    start_at REAL,
    end_at REAL,
    result TEXT,             -- JSON
    confidence TEXT,
    decision TEXT,
    status TEXT DEFAULT 'planned'
);

-- Agent execution log (observability)
CREATE TABLE IF NOT EXISTS agent_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    site_id INTEGER,
    agent TEXT NOT NULL,
    task TEXT NOT NULL,
    input_summary TEXT,
    decision_summary TEXT,
    confidence REAL,
    tools_used TEXT,
    result_summary TEXT,
    error TEXT,
    started_at REAL NOT NULL,
    finished_at REAL,
    duration_seconds REAL
);

-- Long-term memory: recommendations already made + outcome, business rules
CREATE TABLE IF NOT EXISTS memory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    site_id INTEGER NOT NULL REFERENCES sites(id),
    kind TEXT NOT NULL,     -- recommendation/failure/success/business_rule/brand_rule/competitor
    key TEXT NOT NULL,
    value TEXT NOT NULL,    -- JSON
    created_at REAL NOT NULL,
    UNIQUE(site_id, kind, key)
);

-- Business context supplied by the user
CREATE TABLE IF NOT EXISTS business_goals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    site_id INTEGER NOT NULL REFERENCES sites(id),
    kind TEXT NOT NULL,      -- high_value_product/service/location/audience/conversion_event
    label TEXT NOT NULL,
    weight REAL DEFAULT 1.0,
    notes TEXT
);
"""


class DB:
    def __init__(self, path: str):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON;")
        self.conn.executescript(SCHEMA)
        self.conn.commit()
        self._migrate()

    def _migrate(self):
        """Lightweight forward migration for DBs created by an older version
        of this schema: add any column that's in the current SCHEMA's CREATE
        TABLE but missing from an existing on-disk table. SQLite has no
        'ADD COLUMN IF NOT EXISTS', so this diffs PRAGMA table_info against
        the columns each table is supposed to have."""
        expected_columns = {
            "pages": [
                ("hreflang", "TEXT"), ("images", "TEXT"), ("redirect_chain", "TEXT"),
                ("x_robots_tag", "TEXT"), ("response_truncated", "INTEGER DEFAULT 0"),
                ("html_size_bytes", "INTEGER"), ("pagination", "TEXT"),
            ],
            "actions": [
                ("idempotency_key", "TEXT"),
            ],
        }
        for table, columns in expected_columns.items():
            existing = {row["name"] for row in self.conn.execute(f"PRAGMA table_info({table})")}
            for col_name, col_type in columns:
                if col_name not in existing:
                    self.conn.execute(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_type}")
        self.conn.commit()

    @contextmanager
    def tx(self):
        try:
            yield self.conn
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

    # ---- sites -----------------------------------------------------
    def get_or_create_site(self, root_url: str, name: Optional[str] = None) -> int:
        cur = self.conn.execute("SELECT id FROM sites WHERE root_url = ?", (root_url,))
        row = cur.fetchone()
        if row:
            return row["id"]
        with self.tx() as c:
            cur = c.execute(
                "INSERT INTO sites (root_url, name, created_at) VALUES (?,?,?)",
                (root_url, name or root_url, time.time()),
            )
            return cur.lastrowid

    # ---- crawl runs --------------------------------------------------
    def start_crawl_run(self, site_id: int) -> int:
        with self.tx() as c:
            cur = c.execute(
                "INSERT INTO crawl_runs (site_id, started_at) VALUES (?,?)",
                (site_id, time.time()),
            )
            return cur.lastrowid

    def finish_crawl_run(self, run_id: int, pages_crawled: int, status: str = "completed"):
        with self.tx() as c:
            c.execute(
                "UPDATE crawl_runs SET finished_at=?, pages_crawled=?, status=? WHERE id=?",
                (time.time(), pages_crawled, status, run_id),
            )

    # ---- pages ---------------------------------------------------------
    def upsert_page(self, site_id: int, crawl_run_id: int, page: dict) -> int:
        fields = [
            "url", "normalized_url", "status_code", "content_type", "canonical_url",
            "is_indexable", "noindex", "title", "meta_description", "h1", "word_count",
            "content_hash", "template_hint", "redirect_target", "depth", "discovered_via",
            "fetched_at", "raw_headings", "structured_data",
            "hreflang", "images", "redirect_chain", "x_robots_tag", "response_truncated",
            "html_size_bytes", "pagination",
        ]
        values = [page.get(f) for f in fields]
        with self.tx() as c:
            existing = c.execute(
                "SELECT id FROM pages WHERE site_id=? AND normalized_url=?",
                (site_id, page["normalized_url"]),
            ).fetchone()
            if existing:
                set_clause = ", ".join(f"{f}=?" for f in fields)
                c.execute(
                    f"UPDATE pages SET {set_clause}, crawl_run_id=? WHERE id=?",
                    values + [crawl_run_id, existing["id"]],
                )
                page_id = existing["id"]
            else:
                cols = ", ".join(["site_id", "crawl_run_id"] + fields)
                qs = ", ".join(["?"] * (2 + len(fields)))
                cur = c.execute(
                    f"INSERT INTO pages ({cols}) VALUES ({qs})",
                    [site_id, crawl_run_id] + values,
                )
                page_id = cur.lastrowid

            # Append-only historical snapshot -- this is what preserves the
            # page's previous SEO state instead of losing it on every
            # re-crawl (the `pages` row above is a fast "current state" view).
            c.execute(
                """INSERT OR IGNORE INTO page_snapshots
                   (site_id, page_id, crawl_run_id, normalized_url, status_code,
                    canonical_url, is_indexable, noindex, title, meta_description, h1,
                    word_count, content_hash, html_size_bytes, snapshot_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    site_id, page_id, crawl_run_id, page["normalized_url"], page.get("status_code"),
                    page.get("canonical_url"), page.get("is_indexable"), page.get("noindex"),
                    page.get("title"), page.get("meta_description"), page.get("h1"),
                    page.get("word_count"), page.get("content_hash"), page.get("html_size_bytes"),
                    time.time(),
                ),
            )
            return page_id

    def get_pages(self, site_id: int) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM pages WHERE site_id=? ORDER BY id", (site_id,)
        ).fetchall()

    def get_page_by_url(self, site_id: int, normalized_url: str) -> Optional[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM pages WHERE site_id=? AND normalized_url=?",
            (site_id, normalized_url),
        ).fetchone()

    def get_page_snapshots(self, site_id: int, page_id: int) -> list[sqlite3.Row]:
        """Full history for one page, oldest first."""
        return self.conn.execute(
            "SELECT * FROM page_snapshots WHERE site_id=? AND page_id=? ORDER BY snapshot_at ASC",
            (site_id, page_id),
        ).fetchall()

    def get_changed_pages(self, site_id: int, from_run_id: int, to_run_id: int) -> list[dict]:
        """Diffs page_snapshots between two crawl runs: which pages changed
        title/status/canonical/indexability/word_count, and how. Returns
        only pages present in both runs with at least one tracked field
        different -- this is what makes the system historical rather than
        point-in-time (Phase 1)."""
        from_snaps = {
            r["page_id"]: r for r in self.conn.execute(
                "SELECT * FROM page_snapshots WHERE site_id=? AND crawl_run_id=?",
                (site_id, from_run_id),
            ).fetchall()
        }
        to_snaps = {
            r["page_id"]: r for r in self.conn.execute(
                "SELECT * FROM page_snapshots WHERE site_id=? AND crawl_run_id=?",
                (site_id, to_run_id),
            ).fetchall()
        }
        tracked_fields = ["status_code", "title", "canonical_url", "is_indexable",
                          "noindex", "word_count", "content_hash"]
        changes = []
        for page_id, before in from_snaps.items():
            after = to_snaps.get(page_id)
            if not after:
                continue
            diffs = {
                f: {"before": before[f], "after": after[f]}
                for f in tracked_fields if before[f] != after[f]
            }
            if diffs:
                changes.append({"page_id": page_id, "url": before["normalized_url"], "changes": diffs})
        return changes

    def get_latest_two_crawl_runs(self, site_id: int) -> tuple[Optional[int], Optional[int]]:
        rows = self.conn.execute(
            "SELECT id FROM crawl_runs WHERE site_id=? AND status='completed' ORDER BY id DESC LIMIT 2",
            (site_id,),
        ).fetchall()
        if len(rows) < 2:
            return (None, rows[0]["id"] if rows else None)
        return (rows[1]["id"], rows[0]["id"])

    # ---- business goals -----------------------------------------------
    VALID_GOAL_KINDS = ("high_value_product", "high_value_service", "target_location",
                        "target_audience", "conversion_event")

    def add_business_goal(self, site_id: int, kind: str, label: str, weight: float = 1.0,
                          notes: str = "") -> int:
        if kind not in self.VALID_GOAL_KINDS:
            raise ValueError(f"kind must be one of {self.VALID_GOAL_KINDS}, got {kind!r}")
        with self.tx() as c:
            cur = c.execute(
                "INSERT INTO business_goals (site_id, kind, label, weight, notes) VALUES (?,?,?,?,?)",
                (site_id, kind, label, weight, notes),
            )
            return cur.lastrowid

    def list_business_goals(self, site_id: int) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM business_goals WHERE site_id=? ORDER BY weight DESC, id", (site_id,)
        ).fetchall()

    def update_business_goal(self, goal_id: int, **fields):
        allowed = {"kind", "label", "weight", "notes"}
        set_fields = {k: v for k, v in fields.items() if k in allowed and v is not None}
        if not set_fields:
            return
        set_clause = ", ".join(f"{k}=?" for k in set_fields)
        with self.tx() as c:
            c.execute(f"UPDATE business_goals SET {set_clause} WHERE id=?",
                      list(set_fields.values()) + [goal_id])

    def remove_business_goal(self, goal_id: int):
        with self.tx() as c:
            c.execute("DELETE FROM business_goals WHERE id=?", (goal_id,))

    # ---- links -----------------------------------------------------
    def add_link(self, site_id: int, source_page_id: int, target_url: str,
                 target_page_id: Optional[int], anchor_text: str, rel: str, is_internal: bool):
        with self.tx() as c:
            c.execute(
                """INSERT OR IGNORE INTO links
                   (site_id, source_page_id, target_url, target_page_id, anchor_text, rel, is_internal)
                   VALUES (?,?,?,?,?,?,?)""",
                (site_id, source_page_id, target_url, target_page_id, anchor_text, rel, int(is_internal)),
            )

    def get_links(self, site_id: int) -> list[sqlite3.Row]:
        return self.conn.execute("SELECT * FROM links WHERE site_id=?", (site_id,)).fetchall()

    def update_link_target(self, link_id: int, target_page_id: int):
        with self.tx() as c:
            c.execute("UPDATE links SET target_page_id=? WHERE id=?", (target_page_id, link_id))

    # ---- issues -----------------------------------------------------
    def add_issue(self, site_id: int, crawl_run_id: Optional[int], issue: dict) -> int:
        with self.tx() as c:
            cur = c.execute(
                """INSERT INTO issues
                (site_id, crawl_run_id, agent, issue_type, severity, confidence, title,
                 evidence, affected_page_ids, business_impact, seo_impact,
                 recommended_fix, implementation_effort, risk_level, priority_score,
                 created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    site_id, crawl_run_id, issue["agent"], issue["issue_type"],
                    issue["severity"], issue["confidence"], issue["title"],
                    json.dumps(issue.get("evidence", {})),
                    json.dumps(issue.get("affected_page_ids", [])),
                    issue.get("business_impact", ""), issue.get("seo_impact", ""),
                    issue.get("recommended_fix", ""), issue.get("implementation_effort", "medium"),
                    issue.get("risk_level", "low"), issue.get("priority_score", 0.0),
                    time.time(),
                ),
            )
            return cur.lastrowid

    def get_issues(self, site_id: int, crawl_run_id: Optional[int] = None) -> list[sqlite3.Row]:
        if crawl_run_id:
            return self.conn.execute(
                "SELECT * FROM issues WHERE site_id=? AND crawl_run_id=? ORDER BY priority_score DESC",
                (site_id, crawl_run_id),
            ).fetchall()
        return self.conn.execute(
            "SELECT * FROM issues WHERE site_id=? ORDER BY priority_score DESC", (site_id,)
        ).fetchall()

    def update_issue_priority_score(self, issue_id: int, new_score: float, business_impact_note: str = None):
        with self.tx() as c:
            if business_impact_note is not None:
                c.execute("UPDATE issues SET priority_score=?, business_impact=? WHERE id=?",
                          (new_score, business_impact_note, issue_id))
            else:
                c.execute("UPDATE issues SET priority_score=? WHERE id=?", (new_score, issue_id))

    # ---- actions (change management) --------------------------------
    def propose_action(self, site_id: int, action: dict) -> int:
        """If action['idempotency_key'] is set and an action with that key
        already exists for this site, returns the existing action's id
        instead of creating a duplicate (Phase 22: never propose/execute the
        same logical change twice). Pass no key to always create a new row."""
        idem_key = action.get("idempotency_key")
        if idem_key:
            existing = self.conn.execute(
                "SELECT id FROM actions WHERE site_id=? AND idempotency_key=?",
                (site_id, idem_key),
            ).fetchone()
            if existing:
                return existing["id"]
        with self.tx() as c:
            cur = c.execute(
                """INSERT INTO actions
                (site_id, issue_id, action_type, description, risk_level, before_state,
                 after_state, idempotency_key, status, created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (
                    site_id, action.get("issue_id"), action["action_type"], action["description"],
                    action["risk_level"], json.dumps(action.get("before_state", {})),
                    json.dumps(action.get("after_state", {})), idem_key, "proposed", time.time(),
                ),
            )
            return cur.lastrowid

    def decide_action(self, action_id: int, status: str, decided_by: str = "user"):
        with self.tx() as c:
            c.execute(
                "UPDATE actions SET status=?, decided_at=?, decided_by=? WHERE id=?",
                (status, time.time(), decided_by, action_id),
            )

    def apply_action(self, action_id: int):
        with self.tx() as c:
            c.execute(
                "UPDATE actions SET status='applied', applied_at=? WHERE id=?",
                (time.time(), action_id),
            )

    def rollback_action(self, action_id: int):
        with self.tx() as c:
            c.execute(
                "UPDATE actions SET status='rolled_back', rolled_back_at=? WHERE id=?",
                (time.time(), action_id),
            )

    def get_actions(self, site_id: int, status: Optional[str] = None) -> list[sqlite3.Row]:
        if status:
            return self.conn.execute(
                "SELECT * FROM actions WHERE site_id=? AND status=? ORDER BY id DESC",
                (site_id, status),
            ).fetchall()
        return self.conn.execute(
            "SELECT * FROM actions WHERE site_id=? ORDER BY id DESC", (site_id,)
        ).fetchall()

    # ---- agent run logging (observability) ---------------------------
    def log_agent_run(self, entry: dict) -> int:
        with self.tx() as c:
            cur = c.execute(
                """INSERT INTO agent_runs
                (site_id, agent, task, input_summary, decision_summary, confidence,
                 tools_used, result_summary, error, started_at, finished_at, duration_seconds)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    entry.get("site_id"), entry["agent"], entry["task"],
                    entry.get("input_summary", ""), entry.get("decision_summary", ""),
                    entry.get("confidence"), entry.get("tools_used", ""),
                    entry.get("result_summary", ""), entry.get("error"),
                    entry["started_at"], entry.get("finished_at"), entry.get("duration_seconds"),
                ),
            )
            return cur.lastrowid

    # ---- memory -------------------------------------------------------
    def remember(self, site_id: int, kind: str, key: str, value: Any):
        with self.tx() as c:
            c.execute(
                """INSERT INTO memory (site_id, kind, key, value, created_at)
                   VALUES (?,?,?,?,?)
                   ON CONFLICT(site_id, kind, key) DO UPDATE SET value=excluded.value""",
                (site_id, kind, key, json.dumps(value), time.time()),
            )

    def recall(self, site_id: int, kind: str, key: Optional[str] = None):
        if key:
            row = self.conn.execute(
                "SELECT value FROM memory WHERE site_id=? AND kind=? AND key=?",
                (site_id, kind, key),
            ).fetchone()
            return json.loads(row["value"]) if row else None
        rows = self.conn.execute(
            "SELECT key, value FROM memory WHERE site_id=? AND kind=?", (site_id, kind)
        ).fetchall()
        return {r["key"]: json.loads(r["value"]) for r in rows}

    def close(self):
        self.conn.close()
