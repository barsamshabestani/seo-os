from __future__ import annotations
import time
import urllib.robotparser as robotparser
from dataclasses import dataclass, field
from urllib.parse import urljoin, urlsplit
import requests

from .base import CrawlerProvider, FetchResult
from ..security.url_safety import SSRFPolicy, validate_url_safety, UnsafeURLError


@dataclass
class RedirectHop:
    url: str
    status_code: int


@dataclass
class SafeFetchResult(FetchResult):
    """Extends the base FetchResult with data the audit found the original
    implementation was silently discarding: the full redirect chain (for
    loop/length detection), X-Robots-Tag, and whether the body was
    truncated for exceeding the configured size limit."""
    redirect_chain: list[RedirectHop] = field(default_factory=list)
    x_robots_tag: str | None = None
    truncated: bool = False


class RequestsCrawlerProvider(CrawlerProvider):
    """Real HTTP(S) crawler with SSRF protection, manual (visible, capped)
    redirect following, response-size limits, and retry/backoff. Points at
    whatever base URL the caller gives it -- a live site or a local test
    server -- nothing environment-specific is baked in."""

    def __init__(self, user_agent: str, timeout: float = 10.0,
                 max_response_bytes: int = 20 * 1024 * 1024, max_retries: int = 2,
                 ssrf_policy: SSRFPolicy | None = None):
        self.user_agent = user_agent
        self.timeout = timeout
        self.max_response_bytes = max_response_bytes
        self.max_retries = max_retries
        self.ssrf_policy = ssrf_policy or SSRFPolicy()
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": user_agent})
        self._robots_cache: dict[str, robotparser.RobotFileParser] = {}

    def _get_with_limit(self, url: str) -> requests.Response:
        """A single, non-redirect-following GET; body is streamed and size
        capped by the caller so a multi-GB response can't be fully buffered
        before we notice it's too big."""
        return self.session.get(url, timeout=self.timeout, allow_redirects=False, stream=True)

    def fetch(self, url: str) -> SafeFetchResult:
        """Follows redirects manually (capped at ssrf_policy.max_redirect_hops)
        so every hop can be SSRF-checked and the full chain recorded --
        `requests`' built-in allow_redirects=True does neither."""
        start = time.time()
        chain: list[RedirectHop] = []
        current_url = url
        seen_urls: set[str] = set()
        attempt = 0

        while True:
            try:
                validate_url_safety(current_url, self.ssrf_policy)
            except UnsafeURLError as e:
                return SafeFetchResult(
                    url=url, final_url=current_url, status_code=0, headers={}, text=None,
                    content_type="", elapsed_seconds=time.time() - start,
                    error=f"blocked by SSRF policy: {e}", redirect_chain=chain,
                )

            if current_url in seen_urls:
                return SafeFetchResult(
                    url=url, final_url=current_url, status_code=0, headers={}, text=None,
                    content_type="", elapsed_seconds=time.time() - start,
                    error=f"redirect loop detected at {current_url}", redirect_chain=chain,
                )
            seen_urls.add(current_url)

            if len(chain) >= self.ssrf_policy.max_redirect_hops:
                return SafeFetchResult(
                    url=url, final_url=current_url, status_code=0, headers={}, text=None,
                    content_type="", elapsed_seconds=time.time() - start,
                    error=f"exceeded max redirect hops ({self.ssrf_policy.max_redirect_hops})",
                    redirect_chain=chain,
                )

            try:
                resp = self._get_with_limit(current_url)
            except requests.RequestException as e:
                if attempt < self.max_retries:
                    attempt += 1
                    time.sleep(min(2 ** attempt * 0.1, 2.0))  # capped exponential backoff
                    continue
                return SafeFetchResult(
                    url=url, final_url=current_url, status_code=0, headers={}, text=None,
                    content_type="", elapsed_seconds=time.time() - start, error=str(e),
                    redirect_chain=chain,
                )

            if resp.is_redirect or resp.status_code in (301, 302, 303, 307, 308):
                location = resp.headers.get("Location")
                resp.close()
                if not location:
                    break  # marked redirect status but no Location -- treat as final
                chain.append(RedirectHop(url=current_url, status_code=resp.status_code))
                current_url = urljoin(current_url, location)
                attempt = 0
                continue

            # Terminal response -- read it with the size cap enforced.
            content_type = resp.headers.get("Content-Type", "")
            x_robots = resp.headers.get("X-Robots-Tag")
            truncated = False
            body_bytes = b""
            try:
                for chunk in resp.iter_content(chunk_size=65536):
                    body_bytes += chunk
                    if len(body_bytes) > self.max_response_bytes:
                        truncated = True
                        break
            finally:
                resp.close()

            text = None
            if "text" in content_type or "html" in content_type or "xml" in content_type:
                encoding = resp.encoding or "utf-8"
                try:
                    text = body_bytes.decode(encoding, errors="replace")
                except (LookupError, TypeError):
                    text = body_bytes.decode("utf-8", errors="replace")

            return SafeFetchResult(
                url=url, final_url=current_url, status_code=resp.status_code,
                headers=dict(resp.headers), text=text, content_type=content_type,
                elapsed_seconds=time.time() - start, redirect_chain=chain,
                x_robots_tag=x_robots, truncated=truncated,
            )

    def _robots_for(self, base_url: str) -> robotparser.RobotFileParser:
        parts = urlsplit(base_url)
        origin = f"{parts.scheme}://{parts.netloc}"
        if origin in self._robots_cache:
            return self._robots_cache[origin]
        rp = robotparser.RobotFileParser()
        robots_url = urljoin(origin, "/robots.txt")
        result = self.fetch(robots_url)
        if result.status_code == 200 and result.text:
            rp.parse(result.text.splitlines())
        else:
            rp.parse([])  # no robots.txt (or blocked/error) -> allow all
        self._robots_cache[origin] = rp
        return rp

    def can_fetch(self, url: str) -> bool:
        rp = self._robots_for(url)
        try:
            return rp.can_fetch(self.user_agent, url)
        except Exception:
            return True

    def get_robots_txt(self, base_url: str) -> str | None:
        parts = urlsplit(base_url)
        origin = f"{parts.scheme}://{parts.netloc}"
        result = self.fetch(urljoin(origin, "/robots.txt"))
        return result.text if result.status_code == 200 else None

    def get_sitemap_urls(self, base_url: str) -> list[str]:
        """Sitemap URLs referenced by robots.txt, plus the conventional
        /sitemap.xml path as a fallback probe. Does not fetch/parse the
        sitemaps themselves -- see CrawlerAgent._discover_sitemap_pages for
        recursive sitemap-index handling."""
        parts = urlsplit(base_url)
        origin = f"{parts.scheme}://{parts.netloc}"
        sitemaps = []
        robots = self.get_robots_txt(origin)
        if robots:
            for line in robots.splitlines():
                if line.lower().startswith("sitemap:"):
                    raw = line.split(":", 1)[1].strip()
                    sitemaps.append(urljoin(origin, raw))
        if not sitemaps:
            probe_url = urljoin(origin, "/sitemap.xml")
            r = self.fetch(probe_url)
            if r.status_code == 200:
                sitemaps.append(probe_url)
        return sitemaps
