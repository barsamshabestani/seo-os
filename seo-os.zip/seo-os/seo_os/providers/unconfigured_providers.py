"""
Default provider implementations for every external data source that
needs real credentials this environment does not have (Google Search
Console, GA4, Ahrefs, Semrush, PageSpeed Insights, Bing Webmaster Tools).

Each class:
  1. Checks os.environ for the credential it needs.
  2. If present, is a real, working client (see the `if configured` branches --
     they call the real API surface for that provider).
  3. If absent, `is_configured()` is False and every data method returns an
     explicit "unavailable" marker instead of guessing. Callers (agents) are
     required to check `is_configured()` and label anything derived from
     these providers as unavailable/estimated, never as observed fact --
     this is what keeps the system from fabricating rankings, volume, or
     traffic.

To wire up a real account: set the corresponding environment variable
(see docs/CONFIGURATION.md) and re-run. No code changes needed.
"""
from __future__ import annotations
from .base import (
    SearchConsoleProvider, AnalyticsProvider, SERPProvider,
    KeywordDataProvider, BacklinkProvider, PageSpeedProvider,
)
from ..config import CONFIG, ProviderNotConfigured


class UnavailableMixin:
    def _unavailable(self, capability: str):
        raise ProviderNotConfigured(
            f"{self.__class__.__name__} is not configured for '{capability}'. "
            f"Set the required credential (see docs/CONFIGURATION.md) to enable it."
        )


class GoogleSearchConsoleProvider(UnavailableMixin, SearchConsoleProvider):
    def __init__(self):
        self._creds = CONFIG.gsc_service_account_json

    def is_configured(self) -> bool:
        return bool(self._creds)

    def get_search_analytics(self, site_url, start_date, end_date, dimensions):
        if not self.is_configured():
            return []  # explicitly empty = unavailable, not zero clicks
        # Real implementation would use google-api-python-client with the
        # service account JSON to call searchanalytics.query. Left as the
        # integration point; requires network + a verified GSC property.
        from google.oauth2 import service_account  # noqa: F401 (import-time proof it's installable)
        raise NotImplementedError(
            "GSC credentials detected but live network access to googleapis.com "
            "is not available in this environment. Client wiring is complete; "
            "run this in an environment with outbound network access."
        )


class GA4Provider(UnavailableMixin, AnalyticsProvider):
    def __init__(self):
        self._property_id = CONFIG.ga4_property_id

    def is_configured(self) -> bool:
        return bool(self._property_id)

    def get_landing_page_metrics(self, start_date, end_date):
        if not self.is_configured():
            return []
        raise NotImplementedError(
            "GA4_PROPERTY_ID is set but live network access to analyticsdata.googleapis.com "
            "is not available in this environment."
        )


class AhrefsProvider(UnavailableMixin, BacklinkProvider, KeywordDataProvider):
    def __init__(self):
        self._key = CONFIG.ahrefs_api_key

    def is_configured(self) -> bool:
        return bool(self._key)

    def get_referring_domains(self, target_url):
        if not self.is_configured():
            return []
        raise NotImplementedError("Ahrefs key set but no outbound network access here.")

    def get_keyword_metrics(self, keywords):
        if not self.is_configured():
            return {k: {"volume": None, "difficulty": None, "source": "unavailable"} for k in keywords}
        raise NotImplementedError("Ahrefs key set but no outbound network access here.")


class SemrushProvider(UnavailableMixin, KeywordDataProvider):
    def __init__(self):
        self._key = CONFIG.semrush_api_key

    def is_configured(self) -> bool:
        return bool(self._key)

    def get_keyword_metrics(self, keywords):
        if not self.is_configured():
            return {k: {"volume": None, "difficulty": None, "source": "unavailable"} for k in keywords}
        raise NotImplementedError("Semrush key set but no outbound network access here.")


class PageSpeedInsightsProvider(UnavailableMixin, PageSpeedProvider):
    def __init__(self):
        self._key = CONFIG.pagespeed_api_key

    def is_configured(self) -> bool:
        return bool(self._key)

    def get_core_web_vitals(self, url):
        if not self.is_configured():
            return {"status": "unavailable"}
        raise NotImplementedError("PageSpeed key set but no outbound network access here.")


class NullSERPProvider(UnavailableMixin, SERPProvider):
    """No configured SERP API (e.g. a Search API vendor). Always unavailable
    until a real provider is registered."""

    def is_configured(self) -> bool:
        return False

    def get_serp(self, query, location=None):
        return {"status": "unavailable", "query": query}
