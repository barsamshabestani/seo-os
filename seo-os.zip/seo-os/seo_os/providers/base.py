"""
Vendor-independent provider interfaces (section 14 of the spec).

Every external capability the system might use is expressed as an ABC.
Concrete implementations live alongside this file. Swapping GSC for
Bing Webmaster Tools, or Ahrefs for Semrush, means writing one new class
that implements the relevant interface -- nothing else in the codebase
changes.

Providers must NEVER fabricate data. If credentials are missing or a
capability isn't implemented yet, `is_configured()` returns False and
callers must treat all of that provider's data as unavailable rather
than substituting invented numbers.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional


@dataclass
class FetchResult:
    url: str
    final_url: str
    status_code: int
    headers: dict
    text: Optional[str]
    content_type: str
    elapsed_seconds: float
    error: Optional[str] = None


class CrawlerProvider(ABC):
    @abstractmethod
    def fetch(self, url: str) -> FetchResult: ...

    @abstractmethod
    def get_robots_txt(self, base_url: str) -> Optional[str]: ...

    @abstractmethod
    def get_sitemap_urls(self, base_url: str) -> list[str]: ...


class SearchConsoleProvider(ABC):
    """Google Search Console: clicks, impressions, CTR, position by query/page."""

    @abstractmethod
    def is_configured(self) -> bool: ...

    @abstractmethod
    def get_search_analytics(self, site_url: str, start_date: str, end_date: str,
                              dimensions: list[str]) -> list[dict]: ...


class AnalyticsProvider(ABC):
    """GA4 or equivalent: sessions, conversions, engagement by landing page."""

    @abstractmethod
    def is_configured(self) -> bool: ...

    @abstractmethod
    def get_landing_page_metrics(self, start_date: str, end_date: str) -> list[dict]: ...


class SERPProvider(ABC):
    """Live SERP data (ranking positions, SERP features) for a query."""

    @abstractmethod
    def is_configured(self) -> bool: ...

    @abstractmethod
    def get_serp(self, query: str, location: Optional[str] = None) -> dict: ...


class KeywordDataProvider(ABC):
    """Search volume / keyword difficulty (Ahrefs, Semrush, GSC-derived, etc.)."""

    @abstractmethod
    def is_configured(self) -> bool: ...

    @abstractmethod
    def get_keyword_metrics(self, keywords: list[str]) -> dict[str, dict]: ...


class BacklinkProvider(ABC):
    @abstractmethod
    def is_configured(self) -> bool: ...

    @abstractmethod
    def get_referring_domains(self, target_url: str) -> list[dict]: ...


class PageSpeedProvider(ABC):
    @abstractmethod
    def is_configured(self) -> bool: ...

    @abstractmethod
    def get_core_web_vitals(self, url: str) -> dict: ...


class LLMProvider(ABC):
    """Abstraction over the LLM used for content generation / analysis tasks."""

    @abstractmethod
    def complete(self, system: str, prompt: str, **kwargs) -> str: ...
