from __future__ import annotations
import argparse
import json
import sys

from .db import DB
from .config import CONFIG
from .agents.orchestrator import Orchestrator
from .agents.crawler_agent import CrawlerAgent
from .agents.technical_seo_agent import TechnicalSeoAgent
from .agents.internal_linking_agent import InternalLinkingAgent
from .agents.schema_agent import SchemaAgent
from .agents.keyword_agent import KeywordIntelligenceAgent
from .reporting.report import render_markdown, render_html


def _db() -> DB:
    return DB(CONFIG.db_path)


def cmd_audit(args):
    db = _db()
    site_id = db.get_or_create_site(args.url)
    orch = Orchestrator(db, site_id)
    crawl_cfg = _crawl_config_from_args(args)
    result = orch.run_full_audit(args.url, brand_terms=args.brand and args.brand.split(",") or None,
                                  crawl_config=crawl_cfg)
    print(json.dumps(result, indent=2))


def cmd_crawl(args):
    db = _db()
    site_id = db.get_or_create_site(args.url)
    crawler = CrawlerAgent(db, site_id, _crawl_config_from_args(args))
    run_id = crawler.crawl(args.url)
    print(f"crawl_run_id={run_id}")


def _crawl_config_from_args(args):
    from dataclasses import replace
    cfg = CONFIG.crawl
    if getattr(args, "allow_private_targets", False):
        cfg = replace(cfg, allow_private_targets=True)
    return cfg


def cmd_technical(args):
    db = _db()
    site_id = db.get_or_create_site(args.url)
    run_id = args.crawl_run_id or _latest_crawl_run(db, site_id)
    ids = TechnicalSeoAgent(db, site_id).audit(run_id)
    print(f"issues_created={len(ids)}")


def cmd_internal_links(args):
    db = _db()
    site_id = db.get_or_create_site(args.url)
    run_id = args.crawl_run_id or _latest_crawl_run(db, site_id)
    ids = InternalLinkingAgent(db, site_id).analyze(run_id)
    print(f"issues_created={len(ids)}")


def cmd_schema(args):
    db = _db()
    site_id = db.get_or_create_site(args.url)
    run_id = args.crawl_run_id or _latest_crawl_run(db, site_id)
    ids = SchemaAgent(db, site_id).audit(run_id)
    print(f"issues_created={len(ids)}")


def cmd_keywords(args):
    db = _db()
    site_id = db.get_or_create_site(args.url)
    run_id = args.crawl_run_id or _latest_crawl_run(db, site_id)
    ids = KeywordIntelligenceAgent(db, site_id).analyze(
        run_id, brand_terms=args.brand and args.brand.split(",") or None
    )
    print(f"issues_created={len(ids)}")


def cmd_opportunities(args):
    db = _db()
    site_id = db.get_or_create_site(args.url)
    issues = db.get_issues(site_id)
    for i in sorted(issues, key=lambda x: -(x["priority_score"] or 0))[:args.limit]:
        print(f"[{i['priority_score']:>5.1f}] ({i['severity']:>8}) {i['title']}")


def cmd_report(args):
    db = _db()
    site_id = db.get_or_create_site(args.url)
    if args.format == "html":
        out = render_html(db, site_id, args.url)
    else:
        out = render_markdown(db, site_id, args.url)
    if args.out:
        with open(args.out, "w") as f:
            f.write(out)
        print(f"Wrote {args.out}")
    else:
        print(out)


def cmd_plan(args):
    db = _db()
    site_id = db.get_or_create_site(args.url)
    actions = db.get_actions(site_id, status="proposed")
    print(f"{len(actions)} action(s) proposed, awaiting approval:\n")
    for a in actions:
        print(f"  #{a['id']:<4} [{a['risk_level']:>6}] {a['description']}")


def cmd_approve(args):
    db = _db()
    site_id = db.get_or_create_site(args.url)
    Orchestrator(db, site_id).approve_action(args.action_id)
    print(f"Approved action {args.action_id}")


def cmd_reject(args):
    db = _db()
    site_id = db.get_or_create_site(args.url)
    Orchestrator(db, site_id).reject_action(args.action_id)
    print(f"Rejected action {args.action_id}")


def cmd_apply(args):
    db = _db()
    site_id = db.get_or_create_site(args.url)
    Orchestrator(db, site_id).apply_action(args.action_id)
    print(f"Applied action {args.action_id}")


def cmd_rollback(args):
    db = _db()
    site_id = db.get_or_create_site(args.url)
    Orchestrator(db, site_id).rollback_action(args.action_id)
    print(f"Rolled back action {args.action_id}")


def cmd_goals_list(args):
    db = _db()
    site_id = db.get_or_create_site(args.url)
    goals = db.list_business_goals(site_id)
    if not goals:
        print("No business goals configured. Add one with: seo goals add <url> --kind ... --label ... --weight ...")
        return
    for g in goals:
        print(f"  #{g['id']:<4} [{g['kind']:<20}] weight={g['weight']:<5} {g['label']}"
              + (f"  ({g['notes']})" if g["notes"] else ""))


def cmd_goals_add(args):
    db = _db()
    site_id = db.get_or_create_site(args.url)
    try:
        goal_id = db.add_business_goal(site_id, args.kind, args.label, args.weight, args.notes or "")
    except ValueError as e:
        raise SystemExit(str(e))
    print(f"Added business goal #{goal_id}: [{args.kind}] {args.label} (weight={args.weight})")


def cmd_goals_update(args):
    db = _db()
    db.update_business_goal(args.goal_id, kind=args.kind, label=args.label,
                             weight=args.weight, notes=args.notes)
    print(f"Updated business goal #{args.goal_id}")


def cmd_goals_remove(args):
    db = _db()
    db.remove_business_goal(args.goal_id)
    print(f"Removed business goal #{args.goal_id}")


def cmd_history(args):
    db = _db()
    site_id = db.get_or_create_site(args.url)
    from .agents.crawler_agent import normalize_url
    page = db.get_page_by_url(site_id, normalize_url(args.page_url))
    if not page:
        raise SystemExit(f"No crawled page found matching {args.page_url!r}. Run `seo crawl` first.")
    snapshots = db.get_page_snapshots(site_id, page["id"])
    if not snapshots:
        print("No history yet -- this page has only been crawled once.")
        return
    print(f"History for {page['url']} ({len(snapshots)} snapshot(s)):\n")
    for s in snapshots:
        import datetime
        ts = datetime.datetime.fromtimestamp(s["snapshot_at"]).isoformat(timespec="seconds")
        print(f"  [{ts}] run={s['crawl_run_id']} status={s['status_code']} "
              f"indexable={bool(s['is_indexable'])} words={s['word_count']} title={s['title']!r}")


def cmd_changes(args):
    db = _db()
    site_id = db.get_or_create_site(args.url)
    from_run, to_run = (args.from_run, args.to_run) if args.from_run and args.to_run \
        else db.get_latest_two_crawl_runs(site_id)
    if not from_run or not to_run:
        print("Need at least two completed crawl runs to compare. Run `seo crawl` again after a change.")
        return
    changes = db.get_changed_pages(site_id, from_run, to_run)
    print(f"Comparing crawl run {from_run} -> {to_run}: {len(changes)} page(s) changed\n")
    for c in changes[:args.limit]:
        print(f"  {c['url']}")
        for field, delta in c["changes"].items():
            print(f"      {field}: {delta['before']!r} -> {delta['after']!r}")


def _latest_crawl_run(db: DB, site_id: int) -> int:
    row = db.conn.execute(
        "SELECT id FROM crawl_runs WHERE site_id=? ORDER BY id DESC LIMIT 1", (site_id,)
    ).fetchone()
    if not row:
        raise SystemExit("No crawl run found. Run `seo crawl <url>` first.")
    return row["id"]


def build_parser():
    p = argparse.ArgumentParser(prog="seo", description="Autonomous SEO Intelligence & Growth OS")
    sub = p.add_subparsers(dest="command", required=True)

    def add(name, fn, extra=None):
        sp = sub.add_parser(name)
        sp.add_argument("url")
        if extra:
            extra(sp)
        sp.set_defaults(func=fn)
        return sp

    add("audit", cmd_audit, lambda sp: (sp.add_argument("--brand", default=None),
                                         sp.add_argument("--allow-private-targets", action="store_true",
                                                          dest="allow_private_targets",
                                                          help="Allow crawling localhost/private-network "
                                                               "targets (staging/internal use only)")))
    add("crawl", cmd_crawl, lambda sp: sp.add_argument("--allow-private-targets", action="store_true",
                                                         dest="allow_private_targets"))
    add("technical", cmd_technical, lambda sp: sp.add_argument("--crawl-run-id", type=int, dest="crawl_run_id"))
    add("internal-links", cmd_internal_links, lambda sp: sp.add_argument("--crawl-run-id", type=int, dest="crawl_run_id"))
    add("schema", cmd_schema, lambda sp: sp.add_argument("--crawl-run-id", type=int, dest="crawl_run_id"))
    def _keywords_args(sp):
        sp.add_argument("--crawl-run-id", type=int, dest="crawl_run_id")
        sp.add_argument("--brand", default=None)

    add("keywords", cmd_keywords, _keywords_args)
    add("opportunities", cmd_opportunities, lambda sp: sp.add_argument("--limit", type=int, default=20))
    add("report", cmd_report, lambda sp: (sp.add_argument("--format", choices=["md", "html"], default="md"),
                                           sp.add_argument("--out", default=None)))
    add("plan", cmd_plan)
    add("approve", cmd_approve, lambda sp: sp.add_argument("action_id", type=int))
    add("reject", cmd_reject, lambda sp: sp.add_argument("action_id", type=int))
    add("apply", cmd_apply, lambda sp: sp.add_argument("action_id", type=int))
    add("rollback", cmd_rollback, lambda sp: sp.add_argument("action_id", type=int))

    health_sp = sub.add_parser("health")
    health_sp.set_defaults(func=cmd_health)

    goals_sp = sub.add_parser("goals")
    goals_sub = goals_sp.add_subparsers(dest="goals_command", required=True)

    goals_list_sp = goals_sub.add_parser("list")
    goals_list_sp.add_argument("url")
    goals_list_sp.set_defaults(func=cmd_goals_list)

    goals_add_sp = goals_sub.add_parser("add")
    goals_add_sp.add_argument("url")
    goals_add_sp.add_argument("--kind", required=True, choices=list(DB.VALID_GOAL_KINDS))
    goals_add_sp.add_argument("--label", required=True,
                               help="Text matched (case-insensitive, substring) against page URLs, "
                                    "e.g. a product slug or location name")
    goals_add_sp.add_argument("--weight", type=float, default=1.0)
    goals_add_sp.add_argument("--notes", default=None)
    goals_add_sp.set_defaults(func=cmd_goals_add)

    goals_update_sp = goals_sub.add_parser("update")
    goals_update_sp.add_argument("url")
    goals_update_sp.add_argument("goal_id", type=int)
    goals_update_sp.add_argument("--kind", default=None, choices=list(DB.VALID_GOAL_KINDS))
    goals_update_sp.add_argument("--label", default=None)
    goals_update_sp.add_argument("--weight", type=float, default=None)
    goals_update_sp.add_argument("--notes", default=None)
    goals_update_sp.set_defaults(func=cmd_goals_update)

    goals_remove_sp = goals_sub.add_parser("remove")
    goals_remove_sp.add_argument("url")
    goals_remove_sp.add_argument("goal_id", type=int)
    goals_remove_sp.set_defaults(func=cmd_goals_remove)

    add("history", cmd_history, lambda sp: sp.add_argument("page_url"))
    add("changes", cmd_changes, lambda sp: (sp.add_argument("--from-run", type=int, dest="from_run", default=None),
                                             sp.add_argument("--to-run", type=int, dest="to_run", default=None),
                                             sp.add_argument("--limit", type=int, default=25)))

    return p


def cmd_health(args):
    """Basic health check (Phase 28): DB reachable, config sane, provider
    configuration status. No network calls -- safe to run anywhere."""
    from .providers.unconfigured_providers import (
        GoogleSearchConsoleProvider, GA4Provider, AhrefsProvider, SemrushProvider,
        PageSpeedInsightsProvider,
    )
    report = {"db": "unknown", "providers": {}}
    try:
        db = _db()
        db.conn.execute("SELECT 1")
        report["db"] = "ok"
        report["db_path"] = CONFIG.db_path
    except Exception as e:
        report["db"] = f"error: {e}"

    for name, cls in [
        ("google_search_console", GoogleSearchConsoleProvider), ("ga4", GA4Provider),
        ("ahrefs", AhrefsProvider), ("semrush", SemrushProvider),
        ("pagespeed_insights", PageSpeedInsightsProvider),
    ]:
        try:
            report["providers"][name] = "configured" if cls().is_configured() else "unavailable"
        except Exception as e:
            report["providers"][name] = f"error: {e}"

    print(json.dumps(report, indent=2))


def main(argv=None):
    from .observability import new_request_id
    new_request_id()
    parser = build_parser()
    args = parser.parse_args(argv)
    if hasattr(args, "url"):
        _validate_target_url(args.url)
    args.func(args)


def _validate_target_url(url: str):
    from urllib.parse import urlsplit
    parts = urlsplit(url)
    if parts.scheme not in ("http", "https") or not parts.netloc:
        raise SystemExit(
            f"Invalid URL: {url!r}. Expected an absolute http:// or https:// URL, "
            f"e.g. https://example.com/"
        )


if __name__ == "__main__":
    main()
