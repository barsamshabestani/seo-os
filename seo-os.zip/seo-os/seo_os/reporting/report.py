from __future__ import annotations
import json
from datetime import datetime

from ..db import DB

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}


def _gather(db: DB, site_id: int) -> dict:
    pages = db.get_pages(site_id)
    issues = db.get_issues(site_id)
    actions = db.get_actions(site_id)
    indexable = [p for p in pages if p["is_indexable"]]
    broken = [p for p in pages if p["status_code"] and p["status_code"] >= 400]
    by_severity = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    for i in issues:
        by_severity[i["severity"]] = by_severity.get(i["severity"], 0) + 1
    awaiting = [a for a in actions if a["status"] == "proposed"]
    return {
        "pages": pages, "issues": issues, "actions": actions,
        "indexable": indexable, "broken": broken, "by_severity": by_severity,
        "awaiting_approval": awaiting,
    }


def render_markdown(db: DB, site_id: int, site_root_url: str) -> str:
    d = _gather(db, site_id)
    lines = [
        f"# SEO Report -- {site_root_url}",
        f"_Generated {datetime.now().isoformat(timespec='seconds')}_",
        "",
        "## Site Health",
        f"- Pages crawled: **{len(d['pages'])}**",
        f"- Indexable pages: **{len(d['indexable'])}**",
        f"- Broken pages (4xx/5xx): **{len(d['broken'])}**",
        f"- Open issues: **{len(d['issues'])}** "
        f"(critical={d['by_severity']['critical']}, high={d['by_severity']['high']}, "
        f"medium={d['by_severity']['medium']}, low={d['by_severity']['low']})",
        f"- Actions awaiting approval: **{len(d['awaiting_approval'])}**",
        "",
        "## Top Prioritized Issues",
        "",
        "| Score | Severity | Confidence | Issue | Agent |",
        "|---|---|---|---|---|",
    ]
    ranked = sorted(d["issues"], key=lambda i: (-(i["priority_score"] or 0)))
    for i in ranked[:25]:
        lines.append(
            f"| {i['priority_score']:.1f} | {i['severity']} | {i['confidence']:.2f} | "
            f"{i['title']} | {i['agent']} |"
        )
    lines.append("")
    lines.append("## Issue Detail")
    for i in ranked[:25]:
        lines += [
            f"### {i['title']}",
            f"- **Type:** {i['issue_type']}  |  **Agent:** {i['agent']}  |  **Priority score:** {i['priority_score']}",
            f"- **Severity:** {i['severity']}  |  **Confidence:** {i['confidence']}  |  "
            f"**Effort:** {i['implementation_effort']}  |  **Risk:** {i['risk_level']}",
            f"- **Business impact:** {i['business_impact']}",
            f"- **SEO impact:** {i['seo_impact']}",
            f"- **Recommended fix:** {i['recommended_fix']}",
            "",
        ]
    lines.append("## Actions Awaiting Approval")
    for a in d["awaiting_approval"][:25]:
        lines.append(f"- [{a['risk_level'].upper()}] (#{a['id']}) {a['description']}")
    return "\n".join(lines)


def render_html(db: DB, site_id: int, site_root_url: str) -> str:
    d = _gather(db, site_id)
    ranked = sorted(d["issues"], key=lambda i: (-(i["priority_score"] or 0)))

    def esc(s):
        return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    sev_color = {"critical": "#b91c1c", "high": "#c2410c", "medium": "#a16207", "low": "#4d7c0f"}
    risk_color = {"high": "#b91c1c", "medium": "#c2410c", "low": "#15803d"}

    issue_rows = "\n".join(
        f"""<tr>
            <td class="score">{i['priority_score']:.1f}</td>
            <td><span class="pill" style="background:{sev_color.get(i['severity'],'#666')}">{esc(i['severity'])}</span></td>
            <td>{i['confidence']:.2f}</td>
            <td>{esc(i['title'])}</td>
            <td>{esc(i['agent'])}</td>
            <td>{esc(i['recommended_fix'])[:140]}</td>
        </tr>"""
        for i in ranked
    )

    action_rows = "\n".join(
        f"""<tr>
            <td><span class="pill" style="background:{risk_color.get(a['risk_level'],'#666')}">{esc(a['risk_level'])}</span></td>
            <td>{esc(a['description'])}</td>
            <td>{esc(a['status'])}</td>
        </tr>"""
        for a in d["actions"]
    )

    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<title>SEO Report -- {esc(site_root_url)}</title>
<style>
  body {{ font-family: -apple-system, Segoe UI, Roboto, sans-serif; margin: 0; padding: 32px;
          background: #f8fafc; color: #0f172a; }}
  h1 {{ font-size: 22px; margin-bottom: 4px; }}
  .muted {{ color: #64748b; font-size: 13px; margin-bottom: 24px; }}
  .cards {{ display: flex; gap: 16px; flex-wrap: wrap; margin-bottom: 32px; }}
  .card {{ background: white; border: 1px solid #e2e8f0; border-radius: 10px; padding: 16px 20px;
           min-width: 140px; }}
  .card .num {{ font-size: 26px; font-weight: 700; }}
  .card .label {{ font-size: 12px; color: #64748b; text-transform: uppercase; letter-spacing: .04em; }}
  table {{ width: 100%; border-collapse: collapse; background: white; border-radius: 10px;
           overflow: hidden; box-shadow: 0 1px 2px rgba(0,0,0,.04); margin-bottom: 32px; }}
  th, td {{ text-align: left; padding: 10px 12px; border-bottom: 1px solid #eef2f7; font-size: 13px; }}
  th {{ background: #f1f5f9; font-size: 11px; text-transform: uppercase; color: #64748b; }}
  .score {{ font-weight: 700; }}
  .pill {{ color: white; border-radius: 999px; padding: 2px 10px; font-size: 11px; text-transform: capitalize; }}
  h2 {{ font-size: 16px; margin-top: 36px; }}
</style></head>
<body>
  <h1>SEO Report -- {esc(site_root_url)}</h1>
  <div class="muted">Generated {datetime.now().isoformat(timespec='seconds')}</div>

  <div class="cards">
    <div class="card"><div class="num">{len(d['pages'])}</div><div class="label">Pages crawled</div></div>
    <div class="card"><div class="num">{len(d['indexable'])}</div><div class="label">Indexable</div></div>
    <div class="card"><div class="num">{len(d['broken'])}</div><div class="label">Broken pages</div></div>
    <div class="card"><div class="num">{len(d['issues'])}</div><div class="label">Open issues</div></div>
    <div class="card"><div class="num">{len(d['awaiting_approval'])}</div><div class="label">Awaiting approval</div></div>
  </div>

  <h2>Prioritized Issues</h2>
  <table>
    <tr><th>Score</th><th>Severity</th><th>Confidence</th><th>Issue</th><th>Agent</th><th>Fix</th></tr>
    {issue_rows}
  </table>

  <h2>Actions (Change Management)</h2>
  <table>
    <tr><th>Risk</th><th>Description</th><th>Status</th></tr>
    {action_rows}
  </table>
</body></html>"""
