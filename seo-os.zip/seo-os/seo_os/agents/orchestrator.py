from __future__ import annotations
import json
from ..db import DB
from ..config import CONFIG
from .crawler_agent import CrawlerAgent
from .technical_seo_agent import TechnicalSeoAgent
from .internal_linking_agent import InternalLinkingAgent
from .schema_agent import SchemaAgent
from .keyword_agent import KeywordIntelligenceAgent
from .qa_agent import QAAgent
from .priority_engine import PriorityInputs, score

# Risk classification for auto-generated issue types (section 7). This is
# the single source of truth the orchestrator uses to decide whether a
# resulting action can be auto-applied or must wait for a human.
RISK_BY_ISSUE_TYPE = {
    "broken_page": "medium",             # fixing usually means a redirect -> medium
    "redirect_present": "low",
    "missing_title": "low",
    "duplicate_title": "low",
    "missing_meta_description": "low",
    "missing_h1": "low",
    "thin_content": "medium",
    "duplicate_content": "high",         # touches canonicalization
    "orphan_page": "low",
    "broken_internal_link": "low",
    "parameter_urls": "medium",          # touches canonicalization/robots
    "deep_crawl_depth": "low",
    "internal_link_opportunity": "low",
    "orphan_page_needs_links": "low",
    "invalid_structured_data": "low",
    "missing_structured_data_opportunity": "low",
    "keyword_cannibalization_candidate": "high",  # touches which page targets what / possible merges
    "weak_topical_structure": "low",
    # Phase 4 expansion (this pass):
    "title_length_issue": "low",
    "missing_image_alt_text": "low",
    "missing_image_dimensions": "low",
    "hreflang_issue": "medium",       # touches international targeting
    "canonical_loop": "high",          # touches canonicalization
    "canonical_points_to_invalid_target": "high",  # touches canonicalization
    "long_redirect_chain": "medium",   # touches redirect rules
    "url_hygiene": "medium",           # fixing often means adding redirects
    "large_html_size": "low",
    "pagination_missing_canonical": "low",
}


class Orchestrator:
    """Coordinates all agents end-to-end: crawl -> technical audit ->
    internal linking -> schema -> keywords -> prioritize -> propose
    change-managed actions -> (QA + approval gate) -> report. Prevents
    duplicate work by keying everything off one crawl_run_id per pass."""

    def __init__(self, db: DB, site_id: int):
        self.db = db
        self.site_id = site_id

    def run_full_audit(self, start_url: str, brand_terms: list[str] | None = None,
                        crawl_config=None) -> dict:
        crawler = CrawlerAgent(self.db, self.site_id, crawl_config or CONFIG.crawl)
        crawl_run_id = crawler.crawl(start_url)

        technical = TechnicalSeoAgent(self.db, self.site_id)
        technical_ids = technical.audit(crawl_run_id)

        linking = InternalLinkingAgent(self.db, self.site_id)
        linking_ids = linking.analyze(crawl_run_id)

        schema = SchemaAgent(self.db, self.site_id)
        schema_ids = schema.audit(crawl_run_id)

        keywords = KeywordIntelligenceAgent(self.db, self.site_id)
        keyword_ids = keywords.analyze(crawl_run_id, brand_terms=brand_terms)

        all_issue_ids = technical_ids + linking_ids + schema_ids + keyword_ids
        self._apply_business_goal_weighting(crawl_run_id)
        actions_created = self._propose_actions_from_issues(crawl_run_id)

        return {
            "crawl_run_id": crawl_run_id,
            "issue_count": len(all_issue_ids),
            "actions_proposed": actions_created,
        }

    def _apply_business_goal_weighting(self, crawl_run_id: int):
        """Phase 2: make the priority engine actually use business_goals
        instead of only each agent's hard-coded business_value default.

        For every open issue, checks whether any of its affected pages'
        URLs contain any business-goal label (case-insensitive substring
        match -- deliberately simple and explainable, not a black box).
        If so, the issue's priority_score is recomputed with a business
        value boosted proportionally to the matched goal's weight, and
        business_impact gets an explicit note of which goal drove the
        change (so it never looks like an unexplained number).

        This is intentionally conservative: it can only ever raise
        priority for pages that match a configured goal, never invent an
        impact for goals the operator didn't define."""
        import json as _json
        goals = self.db.list_business_goals(self.site_id)
        if not goals:
            return  # nothing configured -- leave agents' defaults as-is (documented behavior)

        pages_by_id = {p["id"]: p for p in self.db.get_pages(self.site_id)}
        issues = self.db.get_issues(self.site_id, crawl_run_id)

        for issue in issues:
            affected_ids = _json.loads(issue["affected_page_ids"] or "[]")
            if not affected_ids:
                continue
            affected_urls = [pages_by_id[pid]["url"].lower() for pid in affected_ids if pid in pages_by_id]
            if not affected_urls:
                continue

            matched_goals = [
                g for g in goals
                if any(g["label"].lower() in url for url in affected_urls)
            ]
            if not matched_goals:
                continue

            best = max(matched_goals, key=lambda g: g["weight"])
            # weight is operator-defined, typically ~0.1-2.0; clamp so a
            # single goal can't blow the formula's 0-100 scale out of range.
            business_value_multiplier = max(0.5, min(2.0, best["weight"]))

            inputs = PriorityInputs(
                impact=issue["severity"], confidence=issue["confidence"],
                business_value="high" if business_value_multiplier >= 1.0 else "medium",
                urgency="high", effort=issue["implementation_effort"], risk=issue["risk_level"],
                affected_url_count=len(affected_ids),
            )
            new_score = round(score(inputs) * business_value_multiplier, 1)
            new_score = min(new_score, 100.0)
            note = (
                f"{issue['business_impact']} [Boosted: affects pages matching business goal "
                f"'{best['label']}' ({best['kind']}, weight={best['weight']})]"
            )
            self.db.update_issue_priority_score(issue["id"], new_score, note)

    def _propose_actions_from_issues(self, crawl_run_id: int) -> int:
        """Turn open issues into change-managed, risk-classified actions
        (section 7/8) rather than leaving the person to translate a report
        into a to-do list by hand. Idempotency key is derived from the issue
        type + the sorted set of affected pages, so re-running an audit that
        rediscovers the same problem updates/reuses the same action instead
        of piling up duplicates (Phase 22)."""
        import hashlib
        issues = self.db.get_issues(self.site_id, crawl_run_id)
        count = 0
        for issue in issues:
            risk = RISK_BY_ISSUE_TYPE.get(issue["issue_type"], "medium")
            affected = json.loads(issue["affected_page_ids"] or "[]")
            key_material = f"{issue['issue_type']}:{sorted(affected)}"
            idem_key = hashlib.sha256(key_material.encode()).hexdigest()[:32]
            action_id = self.db.propose_action(self.site_id, {
                "issue_id": issue["id"],
                "action_type": f"resolve:{issue['issue_type']}",
                "description": issue["title"],
                "risk_level": risk,
                "before_state": {"issue_id": issue["id"], "issue_type": issue["issue_type"]},
                "after_state": {"recommended_fix": issue["recommended_fix"]},
                "idempotency_key": idem_key,
            })
            count += 1
            if risk == "low" and CONFIG.risk.low_risk_auto_apply:
                # Even in auto-apply mode, run QA and log the decision --
                # never apply silently.
                qa = QAAgent(self.db, self.site_id)
                self.db.decide_action(action_id, "approved", decided_by="auto_low_risk_policy")
        return count

    def approve_action(self, action_id: int, decided_by: str = "user"):
        self.db.decide_action(action_id, "approved", decided_by=decided_by)

    def reject_action(self, action_id: int, decided_by: str = "user"):
        self.db.decide_action(action_id, "rejected", decided_by=decided_by)

    def apply_action(self, action_id: int):
        """Marks an approved action as applied. Actually mutating the live
        site is intentionally NOT done here -- this system produces
        previewable, approvable, rollback-able change records; wiring an
        action to a real CMS write is a CMSProvider implementation detail
        the operator plugs in for their own stack."""
        action = next((a for a in self.db.get_actions(self.site_id) if a["id"] == action_id), None)
        if not action:
            raise ValueError(f"No such action {action_id}")
        if action["status"] != "approved":
            raise ValueError(f"Action {action_id} is '{action['status']}', not approved; cannot apply.")
        self.db.apply_action(action_id)

    def rollback_action(self, action_id: int):
        self.db.rollback_action(action_id)
