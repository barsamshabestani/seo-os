from __future__ import annotations
from dataclasses import dataclass

# Qualitative -> numeric anchors. Kept centralized so the whole system scores
# consistently and the mapping can be tuned in one place (section 4: "the
# exact formula can be improved after testing").
IMPACT_SCALE = {"critical": 1.0, "high": 0.75, "medium": 0.45, "low": 0.2}
EFFORT_SCALE = {"low": 0.2, "medium": 0.5, "high": 0.9}
RISK_SCALE = {"low": 0.15, "medium": 0.45, "high": 0.85}
URGENCY_SCALE = {"high": 1.0, "medium": 0.6, "low": 0.3}
BUSINESS_VALUE_SCALE = {"critical": 1.0, "high": 0.8, "medium": 0.5, "low": 0.25}


@dataclass
class PriorityInputs:
    impact: str              # critical/high/medium/low - expected SEO impact
    confidence: float        # 0-1
    business_value: str = "medium"
    urgency: str = "medium"
    effort: str = "medium"
    risk: str = "low"
    affected_url_count: int = 1


def score(inputs: PriorityInputs) -> float:
    """
    Priority Score =
        (Impact * Confidence * BusinessValue * Urgency * ReachMultiplier)
        / (Effort * (1 + Risk))

    - ReachMultiplier gives issues that touch many URLs proportionally more
      weight, damped with a log-ish curve so one 10,000-URL issue doesn't
      permanently dominate the backlog over everything else.
    - Effort and Risk sit in the denominator: expensive or risky work needs
      more expected payoff to justify the same rank.
    Output is scaled 0-100 for readability in reports.
    """
    impact = IMPACT_SCALE.get(inputs.impact, 0.45)
    business_value = BUSINESS_VALUE_SCALE.get(inputs.business_value, 0.5)
    urgency = URGENCY_SCALE.get(inputs.urgency, 0.6)
    effort = EFFORT_SCALE.get(inputs.effort, 0.5)
    risk = RISK_SCALE.get(inputs.risk, 0.15)
    confidence = max(0.05, min(1.0, inputs.confidence))

    reach_multiplier = 1.0 + min(1.0, (inputs.affected_url_count - 1) * 0.05)

    numerator = impact * confidence * business_value * urgency * reach_multiplier
    denominator = max(0.05, effort) * (1 + risk)
    raw = numerator / denominator
    return round(min(raw, 5.0) * 20, 1)  # normalize to ~0-100


def explain(inputs: PriorityInputs, computed_score: float) -> str:
    return (
        f"score={computed_score}: impact={inputs.impact}, confidence={inputs.confidence:.2f}, "
        f"business_value={inputs.business_value}, urgency={inputs.urgency}, "
        f"effort={inputs.effort}, risk={inputs.risk}, affected_urls={inputs.affected_url_count}. "
        f"Higher impact/confidence/business-value/urgency raise the score; higher "
        f"effort/risk lower it; more affected URLs raise it with diminishing returns."
    )
