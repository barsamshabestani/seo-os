from __future__ import annotations
import json
import re
from collections import Counter, defaultdict

from .base import Agent
from .priority_engine import PriorityInputs, score

STOPWORDS = set("""a an the and or of to in on for with is are was were be been being this that these those
it its as at by from into over under about your you our we they he she i not no yes can will would should
how what when where why who which
""".split())

COMMERCIAL_SIGNALS = {"buy", "price", "pricing", "cost", "cheap", "deal", "discount",
                       "coupon", "order", "shop", "service", "services", "near", "quote", "hire"}
INFORMATIONAL_SIGNALS = {"how", "what", "why", "guide", "tutorial", "tips", "learn",
                          "vs", "compare", "comparison", "best", "review", "meaning"}
TRANSACTIONAL_SIGNALS = {"buy", "order", "subscribe", "signup", "sign-up", "download", "book", "checkout"}
NAVIGATIONAL_SIGNALS = set()  # brand terms would go here if the caller supplies a brand list


def classify_intent(phrase: str, brand_terms: set[str] | None = None) -> str:
    tokens = set(re.findall(r"[a-z0-9\-]+", phrase.lower()))
    brand_terms = brand_terms or set()
    if tokens & brand_terms:
        return "navigational"
    if tokens & TRANSACTIONAL_SIGNALS:
        return "transactional"
    if tokens & COMMERCIAL_SIGNALS:
        return "commercial"
    if tokens & INFORMATIONAL_SIGNALS:
        return "informational"
    return "unknown"


def _phrase_candidates(text: str) -> Counter:
    words = [w for w in re.findall(r"[a-z0-9]+", (text or "").lower()) if w not in STOPWORDS and len(w) > 2]
    grams = Counter()
    for n in (2, 3):
        for i in range(len(words) - n + 1):
            grams[" ".join(words[i:i + n])] += 1
    return grams


class KeywordIntelligenceAgent(Agent):
    """Derives candidate keywords/topics from on-page content actually
    crawled (titles, H1s, headings), classifies intent heuristically, and
    detects cannibalization (multiple indexable pages that look like they're
    targeting the same phrase). Search volume/difficulty are pulled from a
    KeywordDataProvider ONLY if one is configured; otherwise every keyword
    is explicitly marked volume=None/source='unavailable' rather than guessed."""

    name = "keyword_intelligence_agent"

    def __init__(self, db, site_id, keyword_data_provider=None):
        super().__init__(db, site_id)
        self.keyword_data_provider = keyword_data_provider

    def analyze(self, crawl_run_id: int, brand_terms: list[str] | None = None) -> list[int]:
        with self.run("keyword_analysis", input_summary=f"crawl_run={crawl_run_id}") as state:
            pages = [p for p in self.db.get_pages(self.site_id)
                     if p["crawl_run_id"] == crawl_run_id and p["status_code"] == 200]
            brand_set = {b.lower() for b in (brand_terms or [])}
            issue_ids = []

            phrase_to_pages: dict[str, list] = defaultdict(list)
            for p in pages:
                headings = json.loads(p["raw_headings"] or "[]")
                text = " ".join(filter(None, [p["title"], p["h1"]] + [h["text"] for h in headings]))
                grams = _phrase_candidates(text)
                for phrase, count in grams.items():
                    if count >= 1:
                        phrase_to_pages[phrase].append(p)

            # Persist top candidate keywords into the knowledge graph, mapped to pages.
            saved = 0
            for phrase, plist in phrase_to_pages.items():
                if len(plist) == 0:
                    continue
                intent = classify_intent(phrase, brand_set)
                metrics = {"volume": None, "difficulty": None, "source": "unavailable"}
                if self.keyword_data_provider and self.keyword_data_provider.is_configured():
                    try:
                        result = self.keyword_data_provider.get_keyword_metrics([phrase])
                        metrics = result.get(phrase, metrics)
                    except NotImplementedError:
                        pass
                with self.db.tx() as c:
                    c.execute(
                        """INSERT INTO keywords (site_id, keyword, intent, cluster, search_volume,
                           search_volume_source, difficulty, difficulty_source, notes, created_at)
                           VALUES (?,?,?,?,?,?,?,?,?, strftime('%s','now'))
                           ON CONFLICT(site_id, keyword) DO UPDATE SET intent=excluded.intent""",
                        (self.site_id, phrase, intent, None, metrics.get("volume"),
                         metrics.get("source"), metrics.get("difficulty"), metrics.get("source"), ""),
                    )
                kw_row = self.db.conn.execute(
                    "SELECT id FROM keywords WHERE site_id=? AND keyword=?", (self.site_id, phrase)
                ).fetchone()
                for p in plist:
                    self.db.conn.execute(
                        """INSERT OR IGNORE INTO keyword_page_map (keyword_id, page_id, relevance_score, match_reason)
                           VALUES (?,?,?,?)""",
                        (kw_row["id"], p["id"], 1.0, "title/h1/heading n-gram match"),
                    )
                self.db.conn.commit()
                saved += 1

            # --- Cannibalization: 2+ pages independently strongly matching the same phrase ---
            cannibal = {ph: ps for ph, ps in phrase_to_pages.items() if len(set(p["id"] for p in ps)) > 1}
            if cannibal:
                examples = [{"phrase": ph, "urls": list({p["url"] for p in ps})}
                            for ph, ps in list(cannibal.items())[:15]]
                inputs = PriorityInputs(impact="medium", confidence=0.55, business_value="medium",
                                         urgency="medium", effort="medium", risk="low",
                                         affected_url_count=sum(len(set(p["id"] for p in ps)) for ps in cannibal.values()))
                iid = self.db.add_issue(self.site_id, crawl_run_id, {
                    "agent": self.name, "issue_type": "keyword_cannibalization_candidate",
                    "severity": "medium", "confidence": 0.55,
                    "title": f"{len(cannibal)} phrase(s) appear as a primary heading/title theme on "
                              f"multiple different pages",
                    "evidence": {"examples": examples},
                    "affected_page_ids": [], "business_impact": "Splits ranking signal; may cause the "
                    "wrong page to rank, or both to underperform.",
                    "seo_impact": "This is a heuristic from on-page text overlap, not live ranking "
                                   "data -- confirm with Search Console query data before consolidating.",
                    "recommended_fix": "Pick one primary page per intent; differentiate or merge the "
                                        "others, and adjust internal links/canonical accordingly.",
                    "implementation_effort": "medium", "risk_level": "medium",
                    "priority_score": score(inputs),
                })
                issue_ids.append(iid)

            # --- Content gap signal: pages with very few candidate phrases (thin topical coverage) ---
            weak_pages = [p for p in pages if len(json.loads(p["raw_headings"] or "[]")) <= 1]
            if weak_pages:
                inputs = PriorityInputs(impact="low", confidence=0.4, business_value="low",
                                         urgency="low", effort="medium", risk="low",
                                         affected_url_count=len(weak_pages))
                iid = self.db.add_issue(self.site_id, crawl_run_id, {
                    "agent": self.name, "issue_type": "weak_topical_structure",
                    "severity": "low", "confidence": 0.4,
                    "title": f"{len(weak_pages)} page(s) have 0-1 headings, limiting topical/keyword coverage",
                    "evidence": {"examples": [p["url"] for p in weak_pages[:20]]},
                    "affected_page_ids": [p["id"] for p in weak_pages],
                    "business_impact": "Thin heading structure correlates with narrower topical coverage.",
                    "seo_impact": "Low confidence heuristic; a human editorial review is needed to "
                                   "confirm whether more subtopics genuinely belong on the page.",
                    "recommended_fix": "Review page for missing subtopics/questions the target "
                                        "audience would expect answered on this page.",
                    "implementation_effort": "medium", "risk_level": "low",
                    "priority_score": score(inputs),
                })
                issue_ids.append(iid)

            state["decision"] = f"Extracted {saved} candidate keyword phrases; {len(cannibal)} cannibalization signals."
            state["confidence"] = 0.5
            state["result"] = state["decision"]
            return issue_ids
