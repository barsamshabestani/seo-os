from __future__ import annotations
import re
from collections import Counter, defaultdict

from .base import Agent
from .priority_engine import PriorityInputs, score

STOPWORDS = set("""a an the and or of to in on for with is are was were be been being this that these those
it its as at by from into over under about your you our we they he she i not no yes can will would should
""".split())


def _tokenize(text: str) -> set[str]:
    words = re.findall(r"[a-z0-9]+", (text or "").lower())
    return {w for w in words if w not in STOPWORDS and len(w) > 2}


class InternalLinkingAgent(Agent):
    """Builds relevance-based internal linking suggestions from the URL
    graph: finds authority hubs (most inlinks), underlinked pages, orphan
    pages, and candidate source->target pairs based on topical overlap
    between titles/H1/headings (no external tools required)."""

    name = "internal_linking_agent"

    def analyze(self, crawl_run_id: int) -> list[int]:
        with self.run("internal_linking_analysis", input_summary=f"crawl_run={crawl_run_id}") as state:
            pages = [p for p in self.db.get_pages(self.site_id)
                     if p["crawl_run_id"] == crawl_run_id and p["status_code"] == 200]
            links = [l for l in self.db.get_links(self.site_id) if l["is_internal"]]
            issue_ids = []

            inlinks = Counter()
            for l in links:
                if l["target_page_id"]:
                    inlinks[l["target_page_id"]] += 1

            # Build a lightweight topical fingerprint per page from title+h1+headings.
            fingerprints: dict[int, set[str]] = {}
            for p in pages:
                text = " ".join(filter(None, [p["title"], p["h1"]]))
                fingerprints[p["id"]] = _tokenize(text)

            median_inlinks = sorted(inlinks.values())[len(inlinks) // 2] if inlinks else 0
            underlinked = [
                p for p in pages
                if inlinks.get(p["id"], 0) <= max(1, median_inlinks // 3)
                and p["depth"] not in (0,)
            ]

            suggestions = []
            linked_pairs = {(l["source_page_id"], l["target_page_id"]) for l in links if l["target_page_id"]}
            for target in underlinked[:30]:
                target_fp = fingerprints.get(target["id"], set())
                if not target_fp:
                    continue
                candidates = []
                for source in pages:
                    if source["id"] == target["id"]:
                        continue
                    if (source["id"], target["id"]) in linked_pairs:
                        continue
                    overlap = target_fp & fingerprints.get(source["id"], set())
                    if len(overlap) >= 2:
                        candidates.append((source, len(overlap), overlap))
                candidates.sort(key=lambda t: -t[1])
                for source, overlap_size, overlap in candidates[:2]:
                    suggestions.append({
                        "target_url": target["url"], "target_id": target["id"],
                        "source_url": source["url"], "source_id": source["id"],
                        "shared_terms": sorted(overlap),
                        "suggested_anchor": target["h1"] or target["title"] or target["url"],
                    })

            if suggestions:
                inputs = PriorityInputs(
                    impact="medium", confidence=0.6, business_value="medium",
                    urgency="medium", effort="low", risk="low",
                    affected_url_count=len({s["target_id"] for s in suggestions}),
                )
                iid = self.db.add_issue(self.site_id, crawl_run_id, {
                    "agent": self.name, "issue_type": "internal_link_opportunity",
                    "severity": "medium", "confidence": 0.6,
                    "title": f"{len(suggestions)} internal linking opportunit(y/ies) found "
                              f"for {len({s['target_id'] for s in suggestions})} underlinked page(s)",
                    "evidence": {"suggestions": suggestions[:50]},
                    "affected_page_ids": list({s["target_id"] for s in suggestions}),
                    "business_impact": "Better internal linking passes authority to pages that "
                                        "need it and helps users/crawlers find related content.",
                    "seo_impact": "Topical relevance was estimated from title/H1 keyword overlap "
                                   "(a heuristic, not a semantic model) -- confidence is moderate; "
                                   "human review before adding links is recommended.",
                    "recommended_fix": "Add a contextual link from each suggested source page to "
                                        "the target, using the suggested (or a more natural) anchor text.",
                    "implementation_effort": "low", "risk_level": "low",
                    "priority_score": score(inputs),
                })
                issue_ids.append(iid)

            # Orphan detection is duplicated intentionally here at the linking
            # layer (vs. technical_seo_agent) because this agent can additionally
            # recommend *which* pages should link to the orphan.
            orphans = [p for p in pages if inlinks.get(p["id"], 0) == 0 and (p["depth"] or 0) > 0]
            if orphans:
                orphan_suggestions = []
                for o in orphans[:20]:
                    fp = fingerprints.get(o["id"], set())
                    best = max(
                        (s for s in pages if s["id"] != o["id"]),
                        key=lambda s: len(fp & fingerprints.get(s["id"], set())),
                        default=None,
                    )
                    if best:
                        orphan_suggestions.append({"orphan_url": o["url"], "suggested_source": best["url"]})
                inputs = PriorityInputs(
                    impact="medium", confidence=0.85, business_value="medium",
                    urgency="medium", effort="low", risk="low",
                    affected_url_count=len(orphans),
                )
                iid = self.db.add_issue(self.site_id, crawl_run_id, {
                    "agent": self.name, "issue_type": "orphan_page_needs_links",
                    "severity": "medium", "confidence": 0.85,
                    "title": f"{len(orphans)} orphan page(s) need at least one internal link",
                    "evidence": {"suggestions": orphan_suggestions},
                    "affected_page_ids": [o["id"] for o in orphans],
                    "business_impact": "Orphan pages accrue almost no internal authority.",
                    "seo_impact": "Zero internal inlinks strongly limits discoverability and ranking potential.",
                    "recommended_fix": "Link to each orphan from the most topically related page found.",
                    "implementation_effort": "low", "risk_level": "low",
                    "priority_score": score(inputs),
                })
                issue_ids.append(iid)

            state["decision"] = (
                f"{len(suggestions)} link suggestions, {len(orphans)} orphans found "
                f"across {len(pages)} pages."
            )
            state["confidence"] = 0.7
            state["result"] = state["decision"]
            return issue_ids
