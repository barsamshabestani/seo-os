from __future__ import annotations
import time
import traceback
from contextlib import contextmanager

from ..db import DB
from ..observability import get_logger, log_event, current_request_id

_log = get_logger()


class Agent:
    name = "base_agent"

    def __init__(self, db: DB, site_id: int):
        self.db = db
        self.site_id = site_id

    @contextmanager
    def run(self, task: str, input_summary: str = "", tools_used: str = ""):
        """Wrap agent work with a timed, logged execution record (section 16:
        every agent execution logs timestamp/agent/task/input/decision/
        confidence/tools/result/errors/duration). Writes both to the durable
        `agent_runs` DB table and to structured stdout/stderr logging
        (Phase 28), correlated by the current request_id."""
        state = {"decision": "", "confidence": None, "result": "", "error": None}
        started = time.time()
        log_event(_log, "info", f"{self.name}.{task} started",
                  site_id=self.site_id, agent=self.name, task=task, input_summary=input_summary)
        try:
            yield state
        except Exception as e:
            state["error"] = f"{e}\n{traceback.format_exc()}"
            log_event(_log, "error", f"{self.name}.{task} failed",
                      site_id=self.site_id, agent=self.name, task=task, error=str(e))
            raise
        finally:
            finished = time.time()
            duration = finished - started
            self.db.log_agent_run({
                "site_id": self.site_id,
                "agent": self.name,
                "task": task,
                "input_summary": input_summary,
                "decision_summary": state["decision"],
                "confidence": state["confidence"],
                "tools_used": tools_used,
                "result_summary": state["result"],
                "error": state["error"],
                "started_at": started,
                "finished_at": finished,
                "duration_seconds": duration,
            })
            if not state["error"]:
                log_event(_log, "info", f"{self.name}.{task} finished",
                          site_id=self.site_id, agent=self.name, task=task,
                          duration_seconds=round(duration, 3), confidence=state["confidence"],
                          result_summary=state["result"])
