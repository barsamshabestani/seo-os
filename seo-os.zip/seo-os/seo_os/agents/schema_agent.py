from __future__ import annotations
import json

from .base import Agent
from .priority_engine import PriorityInputs, score

REQUIRED_FIELDS = {
    "Article": ["headline", "author", "datePublished"],
    "BlogPosting": ["headline", "author", "datePublished"],
    "Product": ["name"],
    "LocalBusiness": ["name", "address"],
    "Organization": ["name"],
    "FAQPage": ["mainEntity"],
    "BreadcrumbList": ["itemListElement"],
    "WebSite": ["name", "url"],
    "Service": ["name"],
    "Event": ["name", "startDate", "location"],
    "Review": ["itemReviewed", "reviewRating", "author"],
}

# Never suggest Review/AggregateRating: they require real, legitimately
# collected reviews and fabricating or auto-generating them is exactly the
# kind of deceptive structured data the project explicitly forbids.
SAFE_TO_SUGGEST = {"Article", "BlogPosting", "BreadcrumbList", "WebSite", "WebPage",
                    "Organization", "Service", "FAQPage", "Product", "LocalBusiness"}


class SchemaAgent(Agent):
    """Detects existing JSON-LD, validates required fields are present, and
    flags pages that look like good candidates for structured data they
    don't have yet -- based on on-page signals only, never inventing
    review/rating data."""

    name = "schema_agent"

    def audit(self, crawl_run_id: int) -> list[int]:
        with self.run("schema_audit", input_summary=f"crawl_run={crawl_run_id}") as state:
            pages = [p for p in self.db.get_pages(self.site_id)
                     if p["crawl_run_id"] == crawl_run_id and p["status_code"] == 200]
            issue_ids = []

            invalid = []
            missing_candidates = []

            for p in pages:
                blocks = json.loads(p["structured_data"] or "[]")
                types_present = set()
                for block in blocks:
                    t = block.get("@type")
                    types = t if isinstance(t, list) else [t] if t else []
                    for typ in types:
                        types_present.add(typ)
                        required = REQUIRED_FIELDS.get(typ)
                        if required:
                            missing_fields = [f for f in required if f not in block]
                            if missing_fields:
                                invalid.append({"url": p["url"], "type": typ, "missing": missing_fields})

                # Heuristic candidate detection from on-page signals, not invented data.
                headings = json.loads(p["raw_headings"] or "[]")
                has_faq_pattern = any(h["text"].strip().endswith("?") for h in headings)
                if has_faq_pattern and "FAQPage" not in types_present:
                    missing_candidates.append({"url": p["url"], "suggest": "FAQPage",
                                                "reason": "Page has multiple heading(s) phrased as questions."})
                if not types_present and p["word_count"] and p["word_count"] > 300 and p["h1"]:
                    missing_candidates.append({"url": p["url"], "suggest": "Article/BlogPosting",
                                                "reason": "Long-form content with no structured data at all."})

            if invalid:
                inputs = PriorityInputs(impact="medium", confidence=0.9, business_value="medium",
                                         urgency="medium", effort="low", risk="low",
                                         affected_url_count=len(invalid))
                iid = self.db.add_issue(self.site_id, crawl_run_id, {
                    "agent": self.name, "issue_type": "invalid_structured_data",
                    "severity": "medium", "confidence": 0.9,
                    "title": f"{len(invalid)} structured data block(s) are missing required fields",
                    "evidence": {"examples": invalid[:20]},
                    "affected_page_ids": [], "business_impact": "Invalid schema may be ignored or "
                    "cause rich result eligibility to be lost.",
                    "seo_impact": "Search engines require the listed fields to grant many rich results.",
                    "recommended_fix": "Add the missing required field(s) to each JSON-LD block; "
                                        "validate with Google's Rich Results Test before publishing.",
                    "implementation_effort": "low", "risk_level": "low",
                    "priority_score": score(inputs),
                })
                issue_ids.append(iid)

            if missing_candidates:
                safe = [m for m in missing_candidates if m["suggest"].split("/")[0] in SAFE_TO_SUGGEST]
                inputs = PriorityInputs(impact="low", confidence=0.5, business_value="low",
                                         urgency="low", effort="low", risk="low",
                                         affected_url_count=len(safe))
                iid = self.db.add_issue(self.site_id, crawl_run_id, {
                    "agent": self.name, "issue_type": "missing_structured_data_opportunity",
                    "severity": "low", "confidence": 0.5,
                    "title": f"{len(safe)} page(s) look like good candidates for structured data",
                    "evidence": {"candidates": safe[:30]},
                    "affected_page_ids": [], "business_impact": "May unlock rich results / better SERP presence.",
                    "seo_impact": "Heuristic only (based on headings/word count), needs human "
                                   "confirmation of the actual page type before adding schema.",
                    "recommended_fix": "Confirm page type, then add the corresponding JSON-LD block "
                                        "with real, accurate values only.",
                    "implementation_effort": "low", "risk_level": "low",
                    "priority_score": score(inputs),
                })
                issue_ids.append(iid)

            state["decision"] = f"{len(invalid)} invalid, {len(missing_candidates)} opportunities found."
            state["confidence"] = 0.7
            state["result"] = state["decision"]
            return issue_ids
