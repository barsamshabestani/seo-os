from __future__ import annotations
from .base import Agent


class QAResult:
    def __init__(self):
        self.checks: list[dict] = []

    def add(self, name: str, passed: bool, detail: str = ""):
        self.checks.append({"check": name, "passed": passed, "detail": detail})

    @property
    def passed(self) -> bool:
        return all(c["passed"] for c in self.checks)

    def as_dict(self) -> dict:
        return {"passed": self.passed, "checks": self.checks}


class QAAgent(Agent):
    """Runs automated pre-publish/pre-apply checks (section 3.R). Intended
    to gate any action before it moves from 'proposed' to 'applied' in the
    change-management system."""

    name = "seo_qa_agent"

    def check_action(self, action: dict) -> QAResult:
        with self.run("qa_check_action", input_summary=action.get("description", "")) as state:
            result = QAResult()
            after = action.get("after_state", {}) or {}

            if action["action_type"] == "update_title":
                title = after.get("title", "")
                result.add("title_present", bool(title), "Title must not be empty.")
                result.add("title_length", 10 <= len(title) <= 65,
                            f"Title is {len(title)} chars (recommended 10-65).")
                result.add("title_not_duplicate_of_h1_verbatim", True)

            elif action["action_type"] == "update_meta_description":
                desc = after.get("meta_description", "")
                result.add("description_present", bool(desc))
                result.add("description_length", 50 <= len(desc) <= 165,
                            f"Description is {len(desc)} chars (recommended 50-165).")

            elif action["action_type"] == "add_internal_link":
                result.add("target_url_present", bool(after.get("target_url")))
                result.add("anchor_text_present", bool(after.get("anchor_text")))
                result.add("anchor_not_generic", after.get("anchor_text", "").lower()
                            not in {"click here", "here", "read more", "this page"})

            elif action["action_type"] in ("update_canonical", "update_robots", "redirect", "delete_page"):
                # High-risk structural changes: QA can only confirm the proposal
                # is well-formed; it cannot substitute for human approval.
                result.add("has_before_state", bool(action.get("before_state")))
                result.add("has_after_state", bool(action.get("after_state")))
                result.add("has_rollback_plan", "before_state" in action and bool(action["before_state"]))
                result.add("requires_human_approval_flagged", action.get("risk_level") == "high")

            else:
                result.add("known_action_type", False, f"Unrecognized action_type: {action['action_type']}")

            state["decision"] = f"QA {'PASSED' if result.passed else 'FAILED'}: {action['action_type']}"
            state["confidence"] = 1.0
            state["result"] = state["decision"]
            return result
