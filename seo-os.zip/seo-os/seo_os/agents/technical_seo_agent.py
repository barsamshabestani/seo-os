from __future__ import annotations
import json
from collections import defaultdict

from .base import Agent
from .priority_engine import PriorityInputs, score
from .crawler_agent import normalize_url


class TechnicalSeoAgent(Agent):
    """Rule-based technical SEO auditor. Every finding is derived from data
    actually observed in the current crawl -- nothing here is guessed."""

    name = "technical_seo_agent"

    THIN_CONTENT_WORDS = 150

    def audit(self, crawl_run_id: int) -> list[int]:
        with self.run("technical_audit", input_summary=f"crawl_run={crawl_run_id}") as state:
            pages = [p for p in self.db.get_pages(self.site_id) if p["crawl_run_id"] == crawl_run_id]
            links = self.db.get_links(self.site_id)
            issue_ids: list[int] = []

            def emit(issue_type, severity, confidence, title, evidence, affected_ids,
                      business_impact, seo_impact, fix, effort, risk, urgency="medium",
                      business_value="medium"):
                inputs = PriorityInputs(
                    impact=severity, confidence=confidence, business_value=business_value,
                    urgency=urgency, effort=effort, risk=risk,
                    affected_url_count=max(1, len(affected_ids)),
                )
                pscore = score(inputs)
                iid = self.db.add_issue(self.site_id, crawl_run_id, {
                    "agent": self.name, "issue_type": issue_type, "severity": severity,
                    "confidence": confidence, "title": title, "evidence": evidence,
                    "affected_page_ids": affected_ids, "business_impact": business_impact,
                    "seo_impact": seo_impact, "recommended_fix": fix,
                    "implementation_effort": effort, "risk_level": risk,
                    "priority_score": pscore,
                })
                issue_ids.append(iid)

            # --- Broken pages (4xx/5xx or fetch errors) ---------------------
            broken = [p for p in pages if p["status_code"] == 0 or p["status_code"] >= 400]
            if broken:
                emit(
                    "broken_page", "high", 1.0,
                    f"{len(broken)} page(s) return an error status",
                    {"examples": [{"url": p["url"], "status": p["status_code"]} for p in broken[:20]]},
                    [p["id"] for p in broken],
                    "Users and search engines hit dead ends; wasted crawl budget.",
                    "Broken pages cannot rank and waste crawl budget on the rest of the site.",
                    "Fix the underlying resource, or 301-redirect to the best live equivalent; "
                    "remove/update any internal links pointing at these URLs.",
                    effort="medium", risk="low", urgency="high", business_value="high",
                )

            # --- Redirects (still crawlable but not the final destination) --
            redirected = [p for p in pages if p["redirect_target"] and p["status_code"] < 400]
            if redirected:
                emit(
                    "redirect_present", "low", 1.0,
                    f"{len(redirected)} URL(s) redirect to a different final URL",
                    {"examples": [{"from": p["url"], "to": p["redirect_target"]} for p in redirected[:20]]},
                    [p["id"] for p in redirected],
                    "Minor: extra hop costs a little speed/crawl budget.",
                    "Internal links should point directly at the final URL, not through a redirect.",
                    "Update internal links that point at the pre-redirect URL to point at the "
                    "final destination directly.",
                    effort="low", risk="low", urgency="low",
                )

            # --- Missing / duplicate titles -----------------------------
            no_title = [p for p in pages if p["status_code"] == 200 and not p["title"]]
            if no_title:
                emit(
                    "missing_title", "high", 1.0, f"{len(no_title)} indexable page(s) missing a <title>",
                    {"examples": [p["url"] for p in no_title[:20]]}, [p["id"] for p in no_title],
                    "Title is the primary click-through driver in search results.",
                    "Pages without a title tag are far less likely to rank or earn clicks.",
                    "Write a unique, descriptive 50-60 character title for each page.",
                    effort="low", risk="low", urgency="high", business_value="high",
                )

            titles = defaultdict(list)
            for p in pages:
                if p["title"] and p["status_code"] == 200:
                    titles[p["title"].strip().lower()].append(p)
            dup_titles = {t: ps for t, ps in titles.items() if len(ps) > 1}
            if dup_titles:
                affected = [p["id"] for ps in dup_titles.values() for p in ps]
                emit(
                    "duplicate_title", "medium", 1.0,
                    f"{len(dup_titles)} title(s) duplicated across {len(affected)} pages",
                    {"examples": [{"title": t, "urls": [p["url"] for p in ps]} for t, ps in list(dup_titles.items())[:10]]},
                    affected,
                    "Confuses users comparing search results; can trigger cannibalization.",
                    "Duplicate titles make it harder for Google to tell pages apart in the SERP.",
                    "Differentiate each title around that page's specific topic/intent.",
                    effort="low", risk="low", urgency="medium",
                )

            # --- Missing / duplicate meta descriptions ----------------------
            no_desc = [p for p in pages if p["status_code"] == 200 and not p["meta_description"]]
            if no_desc:
                emit(
                    "missing_meta_description", "low", 1.0,
                    f"{len(no_desc)} page(s) missing a meta description",
                    {"examples": [p["url"] for p in no_desc[:20]]}, [p["id"] for p in no_desc],
                    "Google may auto-generate a snippet instead, which converts worse on average.",
                    "Meta description doesn't directly affect rankings but strongly affects CTR.",
                    "Write a unique 140-160 character description with a clear value proposition.",
                    effort="low", risk="low", urgency="low",
                )

            # --- Missing / multiple H1 ------------------------------------
            no_h1 = [p for p in pages if p["status_code"] == 200 and not p["h1"]]
            if no_h1:
                emit(
                    "missing_h1", "medium", 0.9, f"{len(no_h1)} page(s) missing an H1",
                    {"examples": [p["url"] for p in no_h1[:20]]}, [p["id"] for p in no_h1],
                    "Weaker topical signal and accessibility issue for screen readers.",
                    "H1 reinforces the page's primary topic to search engines and users.",
                    "Add a single, descriptive H1 that reflects the page's primary topic.",
                    effort="low", risk="low", urgency="medium",
                )

            # --- Thin content -------------------------------------------
            thin = [
                p for p in pages
                if p["status_code"] == 200 and p["word_count"] is not None
                and 0 < p["word_count"] < self.THIN_CONTENT_WORDS
            ]
            if thin:
                emit(
                    "thin_content", "medium", 0.8,
                    f"{len(thin)} page(s) have under {self.THIN_CONTENT_WORDS} words of body content",
                    {"examples": [{"url": p["url"], "words": p["word_count"]} for p in thin[:20]]},
                    [p["id"] for p in thin],
                    "Thin pages rarely satisfy search intent and can drag down site-wide quality signals.",
                    "Low word count alone isn't disqualifying, but often correlates with low information "
                    "gain; treat as a prompt to review, not an automatic rewrite.",
                    "Review each page: merge into a stronger page, expand with genuinely useful "
                    "information, or noindex if it serves no independent purpose.",
                    effort="high", risk="low", urgency="low",
                )

            # --- Exact duplicate content (same content hash) -----------------
            by_hash = defaultdict(list)
            for p in pages:
                if p["content_hash"] and p["status_code"] == 200:
                    by_hash[p["content_hash"]].append(p)
            dup_content = {h: ps for h, ps in by_hash.items() if len(ps) > 1}
            if dup_content:
                affected = [p["id"] for ps in dup_content.values() for p in ps]
                emit(
                    "duplicate_content", "high", 1.0,
                    f"{len(dup_content)} group(s) of pages have byte-identical body content",
                    {"examples": [[p["url"] for p in ps] for ps in list(dup_content.values())[:10]]},
                    affected,
                    "Splits ranking signals and risks Google choosing the wrong canonical.",
                    "Duplicate content forces search engines to pick one version, often unpredictably.",
                    "Canonicalize to one version (rel=canonical or 301) and differentiate or remove the rest.",
                    effort="medium", risk="medium", urgency="high", business_value="high",
                )

            # --- Orphan pages (0 internal inlinks, excluding the seed) --------
            inlink_counts = defaultdict(int)
            for l in links:
                if l["is_internal"] and l["target_page_id"]:
                    inlink_counts[l["target_page_id"]] += 1
            min_depth = min((p["depth"] for p in pages if p["depth"] is not None), default=0)
            orphans = [
                p for p in pages
                if p["status_code"] == 200 and inlink_counts.get(p["id"], 0) == 0
                and p["depth"] != min_depth
            ]
            if orphans:
                emit(
                    "orphan_page", "medium", 0.85,
                    f"{len(orphans)} page(s) have no discovered internal links pointing at them",
                    {"examples": [p["url"] for p in orphans[:20]],
                     "note": "Discovered via sitemap/seed but not linked from crawled pages."},
                    [p["id"] for p in orphans],
                    "Orphan pages get little to no authority from internal linking.",
                    "Pages with no internal inlinks are harder to discover and rank.",
                    "Add contextual internal links from relevant hub/cluster pages.",
                    effort="low", risk="low", urgency="medium",
                )

            # --- Broken internal links -----------------------------------
            page_by_id = {p["id"]: p for p in pages}
            broken_internal = [
                l for l in links
                if l["is_internal"] and l["target_page_id"]
                and l["target_page_id"] in page_by_id
                and page_by_id[l["target_page_id"]]["status_code"] >= 400
            ]
            if broken_internal:
                affected = list({l["source_page_id"] for l in broken_internal})
                emit(
                    "broken_internal_link", "medium", 1.0,
                    f"{len(broken_internal)} internal link(s) point at broken pages",
                    {"examples": [{"from_page_id": l["source_page_id"], "target_url": l["target_url"]}
                                  for l in broken_internal[:20]]},
                    affected,
                    "Broken links degrade UX and waste crawl budget/link equity.",
                    "Internal links to broken pages pass no value and hurt crawl efficiency.",
                    "Update or remove the link, or fix/redirect the target page.",
                    effort="low", risk="low", urgency="medium",
                )

            # --- Parameterized / potentially duplicate URLs -------------------
            param_pages = [p for p in pages if "?" in (p["url"] or "") and p["status_code"] == 200]
            if param_pages:
                emit(
                    "parameter_urls", "low", 0.7,
                    f"{len(param_pages)} indexable URL(s) contain query parameters",
                    {"examples": [p["url"] for p in param_pages[:20]]}, [p["id"] for p in param_pages],
                    "Parameter variants can fragment ranking signals if not canonicalized.",
                    "Confirm each parameterized URL either canonicalizes to a clean URL or is "
                    "genuinely a distinct, intentional page.",
                    "Add rel=canonical to the clean URL, or block low-value parameter combinations "
                    "via robots rules if they add no unique value.",
                    effort="low", risk="low", urgency="low",
                )

            # --- Crawl depth ----------------------------------------------
            deep = [p for p in pages if p["status_code"] == 200 and (p["depth"] or 0) >= 4]
            if deep:
                emit(
                    "deep_crawl_depth", "low", 0.75,
                    f"{len(deep)} page(s) are 4+ clicks from the homepage",
                    {"examples": [{"url": p["url"], "depth": p["depth"]} for p in deep[:20]]},
                    [p["id"] for p in deep],
                    "Deep pages get less authority and are found/re-crawled less often.",
                    "Flatter architectures generally crawl and rank more efficiently.",
                    "Add links from higher-level hub/category pages to bring depth down to 3 or less.",
                    effort="medium", risk="low", urgency="low",
                )

            # --- Title too long / too short (Phase 4: metadata granularity) ---
            bad_length_titles = [
                p for p in pages if p["status_code"] == 200 and p["title"]
                and (len(p["title"]) > 60 or len(p["title"]) < 10)
            ]
            if bad_length_titles:
                emit(
                    "title_length_issue", "low", 1.0,
                    f"{len(bad_length_titles)} title(s) are outside the ~10-60 character sweet spot",
                    {"examples": [{"url": p["url"], "title": p["title"], "length": len(p["title"])}
                                  for p in bad_length_titles[:20]]},
                    [p["id"] for p in bad_length_titles],
                    "Titles outside this range are commonly truncated or padded oddly in the SERP.",
                    "Google typically displays roughly the first ~50-60 characters of a title.",
                    "Rewrite to land in the 10-60 character range while keeping it descriptive.",
                    effort="low", risk="low", urgency="low",
                )

            # --- Image SEO: missing alt text, missing dimensions -------------
            missing_alt_pages = []
            missing_dims_pages = []
            for p in pages:
                if p["status_code"] != 200:
                    continue
                images = json.loads(p["images"] or "[]")
                if any(not img.get("has_alt") for img in images):
                    missing_alt_pages.append((p, [i for i in images if not i.get("has_alt")]))
                if any(not img.get("has_dimensions") for img in images):
                    missing_dims_pages.append(p)
            if missing_alt_pages:
                emit(
                    "missing_image_alt_text", "medium", 1.0,
                    f"{len(missing_alt_pages)} page(s) have image(s) with missing/empty alt text",
                    {"examples": [{"url": p["url"], "missing_alt_count": len(imgs)}
                                  for p, imgs in missing_alt_pages[:20]]},
                    [p["id"] for p, _ in missing_alt_pages],
                    "Alt text is an accessibility requirement and an image-search ranking signal.",
                    "Search engines rely heavily on alt text to understand image content.",
                    "Add descriptive alt text to every meaningful image (empty alt=\"\" is fine "
                    "only for purely decorative images).",
                    effort="medium", risk="low", urgency="low",
                )
            if missing_dims_pages:
                emit(
                    "missing_image_dimensions", "low", 0.9,
                    f"{len(missing_dims_pages)} page(s) have image(s) missing width/height attributes",
                    {"examples": [p["url"] for p in missing_dims_pages[:20]]},
                    [p["id"] for p in missing_dims_pages],
                    "Missing dimensions cause layout shift (hurts Cumulative Layout Shift).",
                    "Explicit width/height lets the browser reserve space before the image loads.",
                    "Add width/height attributes (or aspect-ratio CSS) to image tags.",
                    effort="low", risk="low", urgency="low",
                )

            # --- hreflang validation --------------------------------------
            hreflang_issues = []
            for p in pages:
                if p["status_code"] != 200:
                    continue
                tags = json.loads(p["hreflang"] or "[]")
                if not tags:
                    continue
                self_ref = any(normalize_url(t["url"]) == p["normalized_url"] for t in tags)
                if not self_ref:
                    hreflang_issues.append({"url": p["url"], "problem": "missing self-referencing hreflang"})
                langs = [t["lang"] for t in tags]
                if len(langs) != len(set(langs)):
                    hreflang_issues.append({"url": p["url"], "problem": "duplicate hreflang language codes"})
            if hreflang_issues:
                emit(
                    "hreflang_issue", "medium", 0.8,
                    f"{len(hreflang_issues)} hreflang problem(s) found",
                    {"examples": hreflang_issues[:20]},
                    [], "Incorrect hreflang can serve the wrong language/region version in search results.",
                    "Each hreflang set should include a self-referencing entry and no duplicate "
                    "language codes; return links (reciprocal hreflang) should also be verified.",
                    "Fix the hreflang annotations flagged above; confirm reciprocal return links exist.",
                    effort="medium", risk="low", urgency="low",
                )

            # --- Canonical pointing at a non-indexable/broken/redirected target ---
            url_to_page = {p["normalized_url"]: p for p in pages}
            bad_canonical = []
            canonical_loop = []
            for p in pages:
                if p["status_code"] != 200 or not p["canonical_url"]:
                    continue
                target_norm = normalize_url(p["canonical_url"])
                if target_norm == p["normalized_url"]:
                    continue  # self-canonical, fine
                target_page = url_to_page.get(target_norm)
                if not target_page:
                    continue  # canonical points outside the crawled set; can't verify here
                if target_page["status_code"] >= 400:
                    bad_canonical.append({"url": p["url"], "canonical": p["canonical_url"],
                                           "problem": f"target returns {target_page['status_code']}"})
                elif target_page["redirect_target"]:
                    bad_canonical.append({"url": p["url"], "canonical": p["canonical_url"],
                                           "problem": "target is itself a redirect"})
                elif target_page["noindex"]:
                    bad_canonical.append({"url": p["url"], "canonical": p["canonical_url"],
                                           "problem": "target is noindex"})
                # Loop: A canonicalizes to B, and B canonicalizes back to A.
                if target_page["canonical_url"] and normalize_url(target_page["canonical_url"]) == p["normalized_url"]:
                    canonical_loop.append({"url": p["url"], "canonical": p["canonical_url"]})
            if bad_canonical:
                emit(
                    "canonical_points_to_invalid_target", "high", 0.95,
                    f"{len(bad_canonical)} page(s) canonicalize to a broken/redirected/noindex URL",
                    {"examples": bad_canonical[:20]}, [],
                    "Breaks the canonicalization signal entirely -- search engines may ignore it "
                    "or index the wrong (or no) version.",
                    "A canonical target must itself be a 200, indexable, non-redirecting URL.",
                    "Point the canonical tag directly at the final, indexable URL.",
                    effort="low", risk="low", urgency="high", business_value="high",
                )
            if canonical_loop:
                emit(
                    "canonical_loop", "high", 1.0,
                    f"{len(canonical_loop)} canonical loop(s) detected (A -> B -> A)",
                    {"examples": canonical_loop[:20]}, [],
                    "A canonical loop gives search engines no clear signal of which URL is authoritative.",
                    "Neither page in the loop can be reliably treated as canonical.",
                    "Pick one URL as canonical and have the other point to it (not vice versa).",
                    effort="low", risk="low", urgency="high", business_value="high",
                )

            # --- Long redirect chains (distinct from single-hop redirect_present) ---
            long_chains = []
            for p in pages:
                chain = json.loads(p["redirect_chain"] or "[]")
                if len(chain) >= 2:
                    long_chains.append({"start_url": chain[0]["url"], "hops": len(chain), "final": p["url"]})
            if long_chains:
                emit(
                    "long_redirect_chain", "medium", 1.0,
                    f"{len(long_chains)} URL(s) redirect through 2+ hops before reaching their final destination",
                    {"examples": long_chains[:20]}, [],
                    "Each extra hop adds latency and a small amount of link-equity dilution.",
                    "Search engines follow redirect chains but prefer a direct single hop.",
                    "Update the starting link/redirect rule to point straight at the final URL.",
                    effort="low", risk="low", urgency="low",
                )

            # --- URL hygiene: uppercase, unsafe characters, excessive length ---
            hygiene_issues = []
            for p in pages:
                if p["status_code"] != 200:
                    continue
                from urllib.parse import urlsplit as _us
                path = _us(p["url"]).path
                problems = []
                if path != path.lower():
                    problems.append("uppercase characters in path")
                if len(p["url"]) > 115:
                    problems.append(f"URL is {len(p['url'])} characters (recommended under ~115)")
                if any(ch in path for ch in [" ", '"', "<", ">", "{", "}", "|", "^", "`"]):
                    problems.append("unsafe characters in path")
                if problems:
                    hygiene_issues.append({"url": p["url"], "problems": problems})
            if hygiene_issues:
                emit(
                    "url_hygiene", "low", 1.0,
                    f"{len(hygiene_issues)} URL(s) have hygiene issues (case, length, or unsafe characters)",
                    {"examples": hygiene_issues[:20]}, [],
                    "Inconsistent-case or unsafe-character URLs risk duplicate indexing and broken links.",
                    "Clean, consistent, lowercase, ASCII-safe URLs are more reliable to crawl, share, and link to.",
                    "Standardize on lowercase paths with URL-safe characters (redirect old variants once changed).",
                    effort="medium", risk="medium", urgency="low",
                )

            # --- Large HTML / DOM complexity proxy ---------------------------
            LARGE_HTML_BYTES = 1_000_000  # ~1MB is a common "investigate DOM bloat" threshold
            large_html = [
                p for p in pages if p["status_code"] == 200 and p["html_size_bytes"]
                and p["html_size_bytes"] > LARGE_HTML_BYTES
            ]
            if large_html:
                emit(
                    "large_html_size", "low", 0.9,
                    f"{len(large_html)} page(s) have an unusually large HTML response "
                    f"(over {LARGE_HTML_BYTES // 1000}KB)",
                    {"examples": [{"url": p["url"], "size_kb": round(p["html_size_bytes"] / 1000)}
                                  for p in large_html[:20]]},
                    [p["id"] for p in large_html],
                    "Large HTML often means DOM bloat, which slows rendering and parsing.",
                    "Response size is a rough proxy for DOM complexity, not a direct ranking "
                    "factor -- treat as a prompt to investigate, not a confirmed problem.",
                    "Review the page for unnecessary markup, inline data, or repeated boilerplate "
                    "that could be trimmed or moved to external assets.",
                    effort="medium", risk="low", urgency="low",
                )

            # --- Pagination without a self-referencing canonical --------------
            paginated_missing_canonical = []
            for p in pages:
                if p["status_code"] != 200:
                    continue
                pagination = json.loads(p["pagination"] or "{}")
                if pagination and not p["canonical_url"]:
                    paginated_missing_canonical.append(p)
            if paginated_missing_canonical:
                emit(
                    "pagination_missing_canonical", "low", 0.7,
                    f"{len(paginated_missing_canonical)} paginated page(s) (rel=next/prev) have "
                    f"no canonical tag",
                    {"examples": [p["url"] for p in paginated_missing_canonical[:20]]},
                    [p["id"] for p in paginated_missing_canonical],
                    "Ambiguous canonicalization across a paginated series can split ranking signals.",
                    "Each page in a paginated series should self-canonicalize (canonicalizing every "
                    "page to page 1 is generally NOT recommended by Google's current guidance).",
                    "Add a self-referencing canonical tag to each page in the series.",
                    effort="low", risk="low", urgency="low",
                )

            state["decision"] = f"Generated {len(issue_ids)} technical issue group(s) from {len(pages)} pages."
            state["confidence"] = 0.95
            state["result"] = state["decision"]
            return issue_ids
