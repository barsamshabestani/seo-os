from __future__ import annotations
import hashlib
import json
import threading
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urljoin, urlsplit, urlunsplit

from bs4 import BeautifulSoup

from .base import Agent
from ..providers.http_crawler import RequestsCrawlerProvider, SafeFetchResult, RedirectHop
from ..config import CrawlConfig
from ..security.url_safety import SSRFPolicy

MAX_SITEMAP_RECURSION = 5


def normalize_url(url: str) -> str:
    """Strip fragment, sort/keep query as-is but drop trailing slash
    inconsistencies, lowercase scheme/host. This is the canonical key used
    to dedupe the URL graph."""
    parts = urlsplit(url)
    scheme = parts.scheme.lower()
    netloc = parts.netloc.lower()
    path = parts.path or "/"
    if len(path) > 1 and path.endswith("/"):
        path = path[:-1]
    return urlunsplit((scheme, netloc, path, parts.query, ""))


class _PerHostThrottle:
    """Minimal per-host rate limiter: blocks the calling thread until at
    least `min_interval` seconds have passed since the last request to that
    host. Thread-safe so it's safe to share across the crawl's thread pool."""

    def __init__(self, min_interval: float):
        self.min_interval = min_interval
        self._last_request: dict[str, float] = {}
        self._lock = threading.Lock()

    def wait(self, host: str):
        if self.min_interval <= 0:
            return
        with self._lock:
            last = self._last_request.get(host, 0.0)
            now = time.time()
            wait_for = self.min_interval - (now - last)
            if wait_for > 0:
                time.sleep(wait_for)
            self._last_request[host] = time.time()


class CrawlerAgent(Agent):
    """Crawls a website breadth-first, level by level, fetching each
    level's URLs concurrently (bounded by CrawlConfig.concurrency) while
    keeping all graph/DB mutations single-threaded for safety. Respects
    robots.txt, applies SSRF protection to every fetch (including every
    redirect hop), tracks full redirect chains, and discovers pages via
    both link-following and (recursive) sitemap parsing."""

    name = "site_crawler_agent"

    def __init__(self, db, site_id, crawl_config: CrawlConfig | None = None):
        super().__init__(db, site_id)
        self.cfg = crawl_config or CrawlConfig()
        ssrf_policy = SSRFPolicy(
            allow_private_networks=self.cfg.allow_private_targets,
            allow_localhost=self.cfg.allow_private_targets,
        )
        self.provider = RequestsCrawlerProvider(
            self.cfg.user_agent, self.cfg.timeout_seconds,
            max_response_bytes=self.cfg.max_response_bytes,
            max_retries=self.cfg.max_retries, ssrf_policy=ssrf_policy,
        )
        self.throttle = _PerHostThrottle(self.cfg.per_host_min_interval_seconds)

    def crawl(self, start_url: str) -> int:
        with self.run("crawl_site", input_summary=start_url) as state:
            run_id = self.db.start_crawl_run(self.site_id)
            origin = f"{urlsplit(start_url).scheme}://{urlsplit(start_url).netloc}"
            origin_host = urlsplit(origin).netloc.lower()

            seen: set[str] = set()
            # Level-synchronized BFS: process one full depth level at a time
            # so we can fetch it concurrently, then decide the next level.
            current_level: list[tuple[str, int, str]] = [(start_url, 0, "seed")]
            seen.add(normalize_url(start_url))

            for sm_url in self.provider.get_sitemap_urls(start_url):
                for loc in self._discover_sitemap_urls(sm_url, depth=0):
                    n = normalize_url(loc)
                    if n not in seen:
                        seen.add(n)
                        current_level.append((loc, 1, "sitemap"))

            pages_crawled = 0
            skipped_robots = 0
            broken = 0
            next_level: list[tuple[str, int, str]] = []

            while current_level and pages_crawled < self.cfg.max_pages:
                budget = self.cfg.max_pages - pages_crawled
                batch = current_level[:budget]
                to_fetch = []
                for url, depth, discovered_via in batch:
                    if depth > self.cfg.max_depth:
                        continue
                    if self.cfg.respect_robots and not self.provider.can_fetch(url):
                        skipped_robots += 1
                        continue
                    to_fetch.append((url, depth, discovered_via))

                fetch_results = self._fetch_concurrently(to_fetch)

                for (url, depth, discovered_via), result in zip(to_fetch, fetch_results):
                    page_id, links_found, is_error = self._process_page(
                        run_id, url, depth, discovered_via, result, origin, norm_seen=seen
                    )
                    pages_crawled += 1
                    if is_error:
                        broken += 1
                    for target, anchor, rel, is_internal, target_norm in links_found:
                        if is_internal and target_norm not in seen and "nofollow" not in rel:
                            seen.add(target_norm)
                            next_level.append((target, depth + 1, url))

                current_level = next_level
                next_level = []

            self._resolve_link_targets()
            self.db.finish_crawl_run(run_id, pages_crawled)
            state["decision"] = (
                f"Crawled {pages_crawled} pages (skipped {skipped_robots} via robots.txt, "
                f"{broken} fetch errors), concurrency={self.cfg.concurrency}."
            )
            state["confidence"] = 1.0  # this is observed data, not a model guess
            state["result"] = state["decision"]
            return run_id

    def _fetch_concurrently(self, batch: list[tuple[str, int, str]]) -> list[SafeFetchResult]:
        if not batch:
            return []
        if self.cfg.concurrency <= 1 or len(batch) == 1:
            return [self._throttled_fetch(url) for url, _, _ in batch]
        with ThreadPoolExecutor(max_workers=self.cfg.concurrency) as pool:
            return list(pool.map(lambda item: self._throttled_fetch(item[0]), batch))

    def _throttled_fetch(self, url: str) -> SafeFetchResult:
        host = urlsplit(url).netloc.lower()
        self.throttle.wait(host)
        return self.provider.fetch(url)

    def _process_page(self, run_id, url, depth, discovered_via, result: SafeFetchResult,
                       origin, norm_seen: set[str]):
        norm = normalize_url(url)
        redirect_chain = [{"url": h.url, "status_code": h.status_code} for h in result.redirect_chain]
        page_record = {
            "url": url, "normalized_url": norm, "status_code": result.status_code,
            "content_type": result.content_type, "canonical_url": None,
            "is_indexable": None, "noindex": 0, "title": None,
            "meta_description": None, "h1": None, "word_count": None,
            "content_hash": None, "template_hint": None,
            "redirect_target": result.final_url if result.final_url != url else None,
            "depth": depth, "discovered_via": discovered_via,
            "fetched_at": time.time(), "raw_headings": "[]", "structured_data": "[]",
            "hreflang": "[]", "images": "[]", "redirect_chain": json.dumps(redirect_chain),
            "x_robots_tag": result.x_robots_tag,
            "response_truncated": int(result.truncated),
            "html_size_bytes": len(result.text.encode("utf-8")) if result.text else None,
            "pagination": "{}",
        }

        links_found: list[tuple[str, str, str, bool, str | None]] = []
        is_error = bool(result.error)

        x_robots_noindex = bool(result.x_robots_tag and "noindex" in result.x_robots_tag.lower())

        if result.text and "html" in (result.content_type or ""):
            soup = BeautifulSoup(result.text, "html.parser")

            title_tag = soup.find("title")
            page_record["title"] = title_tag.get_text(strip=True) if title_tag else None

            meta_desc = soup.find("meta", attrs={"name": "description"})
            page_record["meta_description"] = meta_desc.get("content", "").strip() if meta_desc else None

            h1 = soup.find("h1")
            page_record["h1"] = h1.get_text(strip=True) if h1 else None

            headings = [
                {"level": tag.name, "text": tag.get_text(strip=True)}
                for tag in soup.find_all(["h1", "h2", "h3", "h4"])
            ]
            page_record["raw_headings"] = json.dumps(headings)

            canonical_tag = soup.find("link", rel=lambda v: v and "canonical" in v)
            page_record["canonical_url"] = (
                urljoin(url, canonical_tag["href"]) if canonical_tag and canonical_tag.get("href") else None
            )

            robots_meta = soup.find("meta", attrs={"name": "robots"})
            meta_noindex = bool(robots_meta and "noindex" in robots_meta.get("content", "").lower())
            noindex = meta_noindex or x_robots_noindex
            page_record["noindex"] = int(noindex)
            page_record["is_indexable"] = int(
                result.status_code == 200 and not noindex and
                (not page_record["canonical_url"] or normalize_url(page_record["canonical_url"]) == norm)
            )

            body = soup.find("body")
            text_content = body.get_text(" ", strip=True) if body else soup.get_text(" ", strip=True)
            page_record["word_count"] = len(text_content.split())
            page_record["content_hash"] = hashlib.sha256(text_content.encode("utf-8")).hexdigest()

            ld_blocks = []
            for script in soup.find_all("script", type="application/ld+json"):
                try:
                    ld_blocks.append(json.loads(script.string or "{}"))
                except (json.JSONDecodeError, TypeError):
                    pass
            page_record["structured_data"] = json.dumps(ld_blocks)

            hreflang_links = [
                {"lang": tag.get("hreflang"), "url": urljoin(url, tag.get("href"))}
                for tag in soup.find_all("link", rel="alternate")
                if tag.get("hreflang") and tag.get("href")
            ]
            page_record["hreflang"] = json.dumps(hreflang_links)

            pagination = {}
            next_tag = soup.find("link", rel="next")
            prev_tag = soup.find("link", rel="prev")
            if next_tag and next_tag.get("href"):
                pagination["next"] = urljoin(url, next_tag["href"])
            if prev_tag and prev_tag.get("href"):
                pagination["prev"] = urljoin(url, prev_tag["href"])
            page_record["pagination"] = json.dumps(pagination)

            images = [
                {
                    "src": urljoin(url, img.get("src")) if img.get("src") else None,
                    "alt": img.get("alt"),
                    "has_alt": img.get("alt") is not None and img.get("alt").strip() != "",
                    "has_dimensions": bool(img.get("width") and img.get("height")),
                }
                for img in soup.find_all("img")
                if img.get("src")
            ]
            page_record["images"] = json.dumps(images)

            for a in soup.find_all("a", href=True):
                href = a["href"].strip()
                if not href or href.startswith(("mailto:", "tel:", "javascript:", "#")):
                    continue
                target = urljoin(url, href)
                anchor = a.get_text(strip=True)
                rel = " ".join(a.get("rel", []))
                target_parts = urlsplit(target)
                is_internal = target_parts.netloc.lower() in ("", urlsplit(origin).netloc.lower())
                target_norm = normalize_url(target) if is_internal else None
                links_found.append((target, anchor, rel, is_internal, target_norm))

        page_id = self.db.upsert_page(self.site_id, run_id, page_record)

        for target, anchor, rel, is_internal, target_norm in links_found:
            target_page_id = None
            if is_internal:
                existing = self.db.get_page_by_url(self.site_id, target_norm)
                target_page_id = existing["id"] if existing else None
            self.db.add_link(self.site_id, page_id, target, target_page_id, anchor, rel, is_internal)

        return page_id, links_found, is_error

    def _discover_sitemap_urls(self, sitemap_url: str, depth: int) -> list[str]:
        """Fetches a sitemap and returns page URLs. Recurses into sitemap
        indexes (<sitemapindex><sitemap><loc>...) up to MAX_SITEMAP_RECURSION
        levels, since large sites commonly split sitemaps this way."""
        if depth > MAX_SITEMAP_RECURSION:
            return []
        result = self.provider.fetch(sitemap_url)
        if not result.text:
            return []
        try:
            soup = BeautifulSoup(result.text, "xml")
        except Exception:
            soup = BeautifulSoup(result.text, "html.parser")

        if soup.find("sitemapindex"):
            urls = []
            for loc in soup.find_all("loc"):
                child_url = loc.get_text(strip=True)
                urls.extend(self._discover_sitemap_urls(child_url, depth + 1))
            return urls
        return [loc.get_text(strip=True) for loc in soup.find_all("loc")]

    def _resolve_link_targets(self):
        """Second pass: match internal links whose target page was discovered
        later in the BFS to their now-known page id, using the same
        normalization the crawler used to dedupe pages."""
        pages = self.db.get_pages(self.site_id)
        url_to_id = {p["normalized_url"]: p["id"] for p in pages}
        links = self.db.get_links(self.site_id)
        for link in links:
            if link["is_internal"] and link["target_page_id"] is None:
                norm = normalize_url(link["target_url"])
                pid = url_to_id.get(norm)
                if pid:
                    self.db.update_link_target(link["id"], pid)
