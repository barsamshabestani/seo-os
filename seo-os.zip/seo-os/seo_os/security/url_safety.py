"""
Security-critical URL safety checks (Phase 27 / Phase 2 of the audit).

The crawler follows links and redirect targets that come from arbitrary,
untrusted remote HTML. Without this module, an attacker who controls
content on the target site (or a redirect chain) could point the crawler
at:
  - cloud metadata endpoints (169.254.169.254 -- AWS/GCP/Azure credential theft)
  - localhost / the crawler's own host
  - RFC1918 private ranges (internal network scanning)
  - link-local / multicast / reserved ranges

This is a real SSRF vector, not a hypothetical one, and it's the single
highest-severity gap this project's own security-audit brief calls out.
Every fetch AND every redirect hop must be checked here before a request
is made.
"""
from __future__ import annotations
import ipaddress
import socket
from dataclasses import dataclass
from urllib.parse import urlsplit

ALLOWED_SCHEMES = {"http", "https"}


class UnsafeURLError(ValueError):
    """Raised when a URL fails SSRF/safety validation. Callers must treat
    this the same as a fetch failure -- never silently skip the check."""


@dataclass
class SSRFPolicy:
    allow_private_networks: bool = False   # True only for intentional internal/staging targets
    allow_localhost: bool = False
    allowed_hosts: frozenset[str] | None = None   # if set, only these hosts (allowlist mode)
    blocked_hosts: frozenset[str] = frozenset()
    max_redirect_hops: int = 10


def _is_disallowed_ip(ip_str: str, policy: SSRFPolicy) -> str | None:
    """Returns a reason string if the IP should be blocked, else None."""
    try:
        ip = ipaddress.ip_address(ip_str)
    except ValueError:
        return "unparseable IP address"

    if ip.is_multicast:
        return "multicast address"
    if ip.is_reserved:
        return "reserved address range"
    if ip.is_unspecified:
        return "unspecified address (0.0.0.0)"
    if ip.is_link_local:
        # Covers 169.254.0.0/16 (AWS/GCP/Azure metadata lives at 169.254.169.254)
        return "link-local address (blocks cloud metadata endpoints)"
    if ip.is_loopback and not policy.allow_localhost:
        return "loopback address"
    if ip.is_private and not policy.allow_private_networks:
        return "private network address (RFC1918/RFC4193)"
    return None


def validate_url_safety(url: str, policy: SSRFPolicy | None = None) -> None:
    """Raises UnsafeURLError if the URL must not be fetched. Resolves the
    hostname to its actual IP(s) -- checking the hostname string alone is
    not sufficient, since 'evil.com' can resolve to 127.0.0.1 (DNS
    rebinding) just as easily as a literal IP in the URL can."""
    policy = policy or SSRFPolicy()
    parts = urlsplit(url)

    if parts.scheme.lower() not in ALLOWED_SCHEMES:
        raise UnsafeURLError(f"Disallowed URL scheme: {parts.scheme!r}")

    host = parts.hostname
    if not host:
        raise UnsafeURLError("URL has no hostname")

    host_lower = host.lower()
    if host_lower in policy.blocked_hosts:
        raise UnsafeURLError(f"Host is explicitly blocked: {host}")

    if policy.allowed_hosts is not None and host_lower not in policy.allowed_hosts:
        raise UnsafeURLError(f"Host not in allowlist: {host}")

    if host_lower in ("localhost", "localhost.localdomain") and not policy.allow_localhost:
        raise UnsafeURLError("Refusing to fetch 'localhost'")

    # Resolve DNS ourselves and check every returned address -- this is the
    # step that defeats DNS-rebinding attacks (a hostname that looks public
    # but resolves to a private/loopback/link-local IP).
    try:
        addr_infos = socket.getaddrinfo(host, None)
    except socket.gaierror as e:
        raise UnsafeURLError(f"DNS resolution failed for {host}: {e}")

    for family, _, _, _, sockaddr in addr_infos:
        ip_str = sockaddr[0]
        reason = _is_disallowed_ip(ip_str, policy)
        if reason:
            raise UnsafeURLError(f"Host {host} resolves to {ip_str}, which is blocked ({reason})")


def is_safe_url(url: str, policy: SSRFPolicy | None = None) -> bool:
    try:
        validate_url_safety(url, policy)
        return True
    except UnsafeURLError:
        return False
