# Changelog

## Pass 3 — Historical data + business goals (this session)

Scoped from a 34-phase request; most phases (REST API+auth, web dashboard,
job queue/scheduler, live GSC/GA4/SERP/competitor/CMS integrations,
Playwright rendering, semantic/embedding clustering) genuinely need live
network access, a browser runtime, or persistent server infrastructure
this sandboxed session doesn't have a way to build *and verify* honestly.
What was actually buildable and tested here:

### Phase 1 slice — real historical data model
**The gap:** `upsert_page` only ever `UPDATE`d the `pages` row for a URL —
every re-crawl silently discarded the previous SEO state. The system was
point-in-time despite having a `crawl_runs` table that implied otherwise.

**The fix:** new `page_snapshots` table, append-only (`INSERT`, never
`UPDATE`), one row per page per crawl run. `pages` stays the fast
"current state" table (unchanged behavior for every existing reader);
`page_snapshots` is the history behind it. New DB methods:
`get_page_snapshots`, `get_changed_pages` (diffs two runs' snapshots on
status/title/canonical/indexability/word_count/content_hash),
`get_latest_two_crawl_runs`. New CLI: `seo history <url> <page_url>`,
`seo changes <url> [--from-run N --to-run M]`.

Also captured as new page-level data (feeding two new technical checks):
`html_size_bytes`, `pagination` (rel=next/prev).

### Phase 2 — business goals actually drive priority
**The gap:** `business_goals` table existed since pass 1 but nothing read
from it — every issue's `business_value` was a hard-coded per-issue-type
default.

**The fix:** `seo goals list/add/update/remove` CLI commands (validated
against `DB.VALID_GOAL_KINDS`), and
`Orchestrator._apply_business_goal_weighting`, which runs after issue
generation: for every issue, if any affected page's URL matches a
configured goal's label (case-insensitive substring — deliberately simple
and explainable), the issue's `priority_score` is recomputed with a
goal-weight-driven boost, and `business_impact` gets an explicit
`[Boosted: ...]` note naming which goal did it. Verified end-to-end: a
`duplicate_title` issue affecting `/services` went from priority 13.5 to
64.8 after adding a `high_value_service` goal labeled "services" — see
`docs/CHANGELOG.md` history for the exact reproduction. With zero goals
configured, behavior is provably unchanged (dedicated test).

### Phase 3 slice — two new technical checks
`large_html_size` (response body over ~1MB, a DOM-bloat proxy) and
`pagination_missing_canonical` (rel=next/prev page with no self-canonical)
— both backed by the newly captured `html_size_bytes`/`pagination` fields,
not guessed.

### Tests
45 → **55** tests. New: `test_historical_snapshots.py` (5),
`test_business_goals.py` (4), plus new assertions in
`test_technical_seo.py`. Fixture site gained a 3-page pagination series
(`/blog/page/1..3`) to exercise the new pagination check.

### What did NOT change
Everything in Pass 2's "what was already real" state was preserved. No
existing CLI command, DB method signature, or agent behavior was removed
or broken — confirmed by all 45 prior tests still passing unmodified
alongside the 10 new ones.

### Explicitly still out of scope (from the 34-phase request)
JavaScript/Playwright rendering, live GSC/GA4/SERP/competitor/PageSpeed/
backlink data, semantic embeddings, AI content generation, WordPress/CMS
write integration, REST API, authentication/RBAC, web dashboard, job
queue/workers, scheduler, alerting, cost tracking, caching layer,
multi-tenant isolation, plugin marketplace. Each needs live network,
a browser binary, real credentials, or a persistent server process this
sandbox cannot provide or verify against — building them further here
would mean shipping untested code, which this project's own rules (Phase 0
of every pass so far) explicitly reject. See `docs/ROADMAP.md`.

## Pass 2 — Production hardening audit (this session)

Full audit in `docs/AUDIT.md`. Summary of what changed:

### Security (Phase 27 / Phase 2)
- **New: SSRF protection** (`seo_os/security/url_safety.py`). Every fetch
  and every redirect hop now resolves DNS and checks the actual IP against
  loopback/private/link-local/reserved/multicast ranges before connecting
  — this defeats both literal-IP SSRF (`http://169.254.169.254/`) and
  DNS-rebinding SSRF (a hostname that resolves to a private IP). Default
  policy blocks all of these; `SEO_OS_ALLOW_PRIVATE_TARGETS=1` (or CLI
  `--allow-private-targets`) opts in explicitly for internal/staging use.
- Response size cap (`SEO_OS_MAX_RESPONSE_BYTES`, default 20MB) enforced
  while streaming, so a huge response can't be fully buffered first.
- CLI now validates `<url>` is an absolute http(s) URL before use.
- Structured logging redacts any field whose key looks like a secret
  (`key`, `token`, `secret`, `password`, `credential`, `authorization`).

### Crawler (Phase 2)
- Manual redirect following (previously delegated to `requests`'
  `allow_redirects=True`, which hid the chain): now every hop is recorded,
  SSRF-checked individually, and loops are detected instead of hanging.
- Concurrent crawling: level-synchronized BFS now fetches each depth level
  with a thread pool (`SEO_OS_CONCURRENCY`, previously defined but unused).
- Per-host rate limiting (`SEO_OS_PER_HOST_DELAY`).
- Retry with capped exponential backoff on transient fetch errors
  (`SEO_OS_MAX_RETRIES`).
- Sitemap-index recursion: `<sitemapindex>` files are now followed into
  their child sitemaps (previously only a single sitemap file was read).
- New data captured per page: `hreflang`, `images` (src/alt/dimensions),
  `redirect_chain`, `x_robots_tag`, `response_truncated`. `X-Robots-Tag:
  noindex` is now merged into indexability the same way `<meta
  name=robots>` already was.
- DB schema migration support added (`DB._migrate`) so existing on-disk
  databases pick up new columns without needing to be deleted.

### Technical SEO Agent (Phase 4)
Eight new checks, all backed by data now actually captured (never guessed):
`title_length_issue`, `missing_image_alt_text`, `missing_image_dimensions`,
`hreflang_issue`, `canonical_loop`, `canonical_points_to_invalid_target`,
`long_redirect_chain`, `url_hygiene`.

### Change management (Phase 22)
- **Idempotency keys** on actions: `Orchestrator._propose_actions_from_issues`
  now derives a stable key from `(issue_type, affected_page_ids)`, so
  re-running an audit against an unchanged site reuses the same action
  instead of creating a duplicate every time. Verified with a dedicated
  test (`test_rerunning_audit_does_not_duplicate_actions`).

### Observability (Phase 28)
- New `seo_os/observability.py`: structured JSON logging with a
  per-invocation `request_id` that correlates every log line (and, via the
  existing `agent_runs` DB table, every agent execution) back to one CLI
  run. Wired into `Agent.run()` and `cli.main()`.
- New `seo health` command: checks DB connectivity and reports each
  external provider's configuration status (no network calls).

### Tests
27 → **45** tests, all still passing against a real local HTTP server (no
mocks). New: `test_ssrf_protection.py` (9 tests), `test_redirect_handling.py`
(3 tests), plus new assertions in `test_technical_seo.py` and
`test_qa_and_change_management.py` for the new checks and idempotency.

Fixture site (`tests/fixtures/fixture_site.py`) gained 10 new routes to
exercise the above: a 3-hop redirect chain, a redirect loop, a canonical
loop, a canonical pointing at a broken page, an images page with
missing-alt/missing-dimensions cases, a broken-hreflang page, and an
uppercase-path URL.

**Fixed along the way:** the fixture Flask dev server needed
`threaded=True` — without it, the new concurrent crawler's parallel
requests weren't served correctly and two fixture pages silently never
got crawled. Found via a failing new test, not assumed.

### What did NOT change
Everything marked REAL in `docs/AUDIT.md`'s "what was already real"
table was preserved, not rewritten, per this pass's brief. Providers
needing live network/credentials (GSC, GA4, Ahrefs, Semrush, PageSpeed,
SERP, competitor, CMS, AI content, dashboard, API+auth) remain out of
scope for the reason stated in `docs/AUDIT.md` — building them further
here would mean shipping untested code or fabricating results.

## Pass 1 — Initial build
See `docs/AUDIT.md` "what was already real and working" table, and the
original `docs/ROADMAP.md` for what pass 1 covered.
