# Architecture

## Data flow

```
CrawlerAgent  ──▶  pages, links (Knowledge Graph)
                         │
        ┌────────────────┼────────────────┬───────────────┐
        ▼                ▼                ▼               ▼
TechnicalSeoAgent  InternalLinkingAgent  SchemaAgent  KeywordIntelligenceAgent
        │                │                │               │
        └────────────────┴────────────────┴───────────────┘
                         ▼
                     issues (scored by priority_engine)
                         ▼
                Orchestrator._propose_actions_from_issues
                         ▼
                     actions (proposed → approved → applied → rolled_back)
                         ▼
                  reporting/report.py (Markdown / HTML)
```

Every agent call is wrapped in `Agent.run()` (see `agents/base.py`), which
writes a row to `agent_runs` with timestamp, task, input/decision/result
summaries, confidence, and duration — the observability layer the spec
calls for in section 16.

## Database schema (SQLite)

Full DDL lives in `seo_os/db.py::SCHEMA`. Summary:

| Table | Represents |
|---|---|
| `sites` | A site being managed |
| `crawl_runs` | One crawl pass; everything downstream keys off `crawl_run_id` so re-running an audit doesn't blend stale and fresh findings |
| `pages` | Node: a URL. Status, canonical, indexability, title/meta/H1/headings, word count, content hash, JSON-LD, depth |
| `links` | Edge: page → URL, with anchor text, rel, resolved target page (when internal) |
| `keywords` | Node: a candidate keyword phrase, with intent classification and (if a real provider is configured) volume/difficulty |
| `keyword_page_map` | Edge: keyword ↔ page, with a relevance score and reason |
| `issues` | A finding from any agent: severity, confidence, evidence (JSON), affected pages, business/SEO impact, recommended fix, effort, risk, priority score |
| `actions` | A change-managed action derived from an issue: risk level, before/after state, approval status, timestamps — this is the rollback mechanism |
| `experiments` | Hypothesis/baseline/change/result/decision records (schema in place; no experiment-running agent built yet) |
| `agent_runs` | Observability log for every agent execution |
| `memory` | Long-term memory: recommendations made, failures, successes, business/brand rules, keyed by `(site_id, kind, key)` |
| `business_goals` | User-supplied business context: high-value products/services/locations/audiences/conversion events, with a weight |

### Why relational instead of a graph database

At the scale this operates at (one organization's site + its competitors),
a graph database adds an operational dependency without adding real
capability: SQL joins across `pages`/`links`/`keywords`/`issues` answer the
graph questions the spec lists just fine, e.g.:

**"Which pages have no dedicated page for an important topic?"**
— covered by `keyword_intelligence_agent`'s cannibalization detector
(phrases with 2+ matching pages) combined with a business-goals check for
phrases with *zero* matching pages (not yet automated — see ROADMAP).

**"Which high-value pages are poorly internally linked?"**
```sql
SELECT p.url, COUNT(l.id) AS inlinks
FROM pages p
LEFT JOIN links l ON l.target_page_id = p.id AND l.is_internal = 1
WHERE p.site_id = ?
GROUP BY p.id
ORDER BY inlinks ASC
LIMIT 20;
```

**"Which pages compete for the same intent?"** — `internal_linking_agent`
and `keyword_agent` both compute this via title/H1/heading token overlap;
raw form:
```sql
SELECT k.keyword, GROUP_CONCAT(p.url, ' | ') AS competing_pages
FROM keyword_page_map m
JOIN keywords k ON k.id = m.keyword_id
JOIN pages p ON p.id = m.page_id
WHERE k.site_id = ?
GROUP BY k.id
HAVING COUNT(DISTINCT m.page_id) > 1;
```

**"Which pages lost visibility and why might that have happened?"** —
requires historical Search Console position data, which needs a configured
`SearchConsoleProvider`; the `experiments`/`agent_runs` tables plus repeat
`crawl_runs` give the "what changed on the page between then and now" half
of the answer already (diff `pages` rows across `crawl_run_id`s by
`content_hash`, `title`, `canonical_url`, `status_code`).

## Provider abstraction

`providers/base.py` defines interfaces; nothing in `agents/` imports a
concrete provider class directly except through dependency injection
(e.g. `KeywordIntelligenceAgent(db, site_id, keyword_data_provider=...)`).
Swapping Ahrefs for Semrush, or adding a new SERP API vendor, means adding
one new class in `providers/` that implements the relevant interface.

## Extending with a new agent

1. Subclass `agents.base.Agent`, set `name`.
2. Wrap your logic in `with self.run("task_name", ...) as state:` so it's
   automatically logged.
3. Call `self.db.add_issue(...)` for each finding, using
   `priority_engine.score()` for `priority_score` so it sorts consistently
   with everything else in the backlog.
4. Register risk classification for any new `issue_type` in
   `orchestrator.RISK_BY_ISSUE_TYPE`.
5. Add the agent to `Orchestrator.run_full_audit` (or leave it
   CLI/standalone-only if it's meant to run on a different cadence, e.g. a
   weekly competitor scan).
