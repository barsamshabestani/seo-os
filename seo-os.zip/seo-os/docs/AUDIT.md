# Implementation Matrix (Phase 0 Audit)

Audited before any Phase 1+ changes in this pass. Status legend:
**REAL** = working, tested code. **STUB** = interface exists, no working
backend (by design — needs credentials/network this sandbox doesn't have).
**MISSING** = not present at all. **GAP** = present but with a real,
fixable weakness found during this audit.

## What was already real and working (preserved, not rewritten)

| Area | File | Status |
|---|---|---|
| SQLite knowledge graph schema | `db.py` | REAL |
| Sequential BFS crawler | `agents/crawler_agent.py` | REAL, but see GAPs below |
| Technical SEO rules (10 checks) | `agents/technical_seo_agent.py` | REAL |
| Internal linking heuristics | `agents/internal_linking_agent.py` | REAL |
| Schema validation | `agents/schema_agent.py` | REAL |
| Keyword heuristics (no fake volume) | `agents/keyword_agent.py` | REAL |
| Priority formula | `agents/priority_engine.py` | REAL |
| Change management (propose/approve/apply/rollback) | `agents/orchestrator.py`, `db.py` | REAL, but no idempotency guard (GAP) |
| QA pre-apply checks | `agents/qa_agent.py` | REAL |
| CLI | `cli.py` | REAL |
| Reporting (MD/HTML) | `reporting/report.py` | REAL |
| Agent observability logging | `agents/base.py` | REAL |
| GSC/GA4/Ahrefs/Semrush/PSI providers | `providers/unconfigured_providers.py` | STUB by design — real client wiring, `NotImplementedError` on the actual network call. Correctly gated, not fabricating data. Left as-is; still needs a networked environment to finish. |
| Tests | `tests/` | REAL — 27/27 passing against a live local HTTP server, no mocks |

## Gaps found in this audit (fixed in this pass — see CHANGELOG.md)

| Gap | Severity | Where |
|---|---|---|
| **No SSRF protection.** The crawler will happily fetch `http://169.254.169.254/`, `http://localhost/`, `http://10.0.0.1/`, or follow a redirect into a private network, with no allowlist or IP check. | **Critical (security)** | `providers/http_crawler.py` |
| Redirects fully auto-followed by `requests` (`allow_redirects=True`): no visibility into the chain, no loop detection, no per-hop status codes | High | `providers/http_crawler.py` |
| Fully sequential crawl — no concurrency, despite `SEO_OS_CONCURRENCY` existing in config and doing nothing | Medium (performance) | `agents/crawler_agent.py` |
| No per-host rate limiting / backoff — a crawl of two sites hits both at unlimited speed | Medium | `agents/crawler_agent.py` |
| Sitemap parsing reads one file only — no sitemap-index recursion | Medium | `agents/crawler_agent.py` |
| No `X-Robots-Tag` HTTP header handling (only `<meta name=robots>`) | Medium | `agents/crawler_agent.py` |
| No hreflang extraction/validation | Medium | `agents/crawler_agent.py`, `technical_seo_agent.py` |
| No image extraction → no missing-alt / broken-image checks | Medium | `agents/crawler_agent.py`, `technical_seo_agent.py` |
| No canonical-loop / canonical-to-redirected / canonical-to-noindex detection | Medium | `technical_seo_agent.py` |
| No URL hygiene checks (uppercase, unsafe chars, excessive length, `www`/non-`www` and `http`/`https` duplication) | Low–Medium | `technical_seo_agent.py` |
| No mixed-content (HTTP resource on HTTPS page) check | Medium (security-adjacent SEO) | `technical_seo_agent.py` |
| No title-length / heading-hierarchy granularity (only missing/duplicate, not "too long") | Low | `technical_seo_agent.py` |
| Actions have no idempotency key — re-running an audit that finds the "same" issue again creates a duplicate action rather than recognizing it | Medium | `db.py`, `orchestrator.py` |
| No max-response-size limit on fetch — a crawler pointed at a multi-GB file would buffer it all | Medium (resource-exhaustion) | `providers/http_crawler.py` |
| CLI never validates that `<url>` is actually a URL before handing it to the crawler | Low | `cli.py` |

## Explicitly out of scope for this pass (confirmed still true after audit)

These require live network access and/or paid API credentials this sandbox
does not have, so building them further than the existing provider
interfaces would mean either (a) shipping untested code claiming to work,
or (b) fabricating results — both against this project's own rules.
Unchanged from the prior `docs/ROADMAP.md`: JS rendering (Playwright),
Search Console/GA4/PageSpeed live calls, SERP/competitor/backlink
providers, AI content generation, semantic embeddings, CMS write
integration, web dashboard, REST API + auth/RBAC, job queue/workers,
scheduling. See `docs/ROADMAP.md` (updated) for the current prioritized
list including where this pass's crawler/technical upgrades change the
calculus (e.g. concurrent crawling was previously #3, now done).
