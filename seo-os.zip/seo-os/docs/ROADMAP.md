# Roadmap

Ordered roughly by impact/effort, the way the priority engine would rank
them if these were issues in the backlog. Updated after the production-
hardening pass — see `docs/CHANGELOG.md` for what moved from "planned" to
"done" (concurrent crawling, per-host rate limiting, sitemap-index
recursion, SSRF protection, and action idempotency are no longer on this
list; they're shipped).

## High priority (unlocks the most value for least effort)

1. **Wire a real KeywordDataProvider in a networked environment.** The
   Ahrefs/Semrush client classes exist and are gated correctly; they just
   need `AHREFS_API_KEY`/`SEMRUSH_API_KEY` plus outbound network to
   `apiv2.ahrefs.com` / Semrush's API, which this sandbox doesn't have.
   This upgrades every keyword-related issue's confidence immediately.
2. **www/non-www and http/https duplicate-origin detection.** The crawler
   currently only crawls the single origin it's pointed at; detecting
   "the same site is also fully duplicated at the http:// or non-www
   variant" needs a second, bounded crawl of those variants and a content-
   hash diff — straightforward to add now that redirect-chain tracking
   exists to confirm whether they already redirect correctly.
4. **Soft-404 detection** — pages that return HTTP 200 but are actually
   "not found" pages (common on misconfigured CMSs). Heuristic: compare a
   known-404 page's content/title pattern against suspiciously similar
   200-status pages.

## Medium priority (real capability, needs live data, a browser, or an LLM call)

5. **JavaScript rendering** via a `BrowserProvider` (Playwright) — the
   interface boundary is clear (swap `RequestsCrawlerProvider` for a
   `PlaywrightCrawlerProvider` implementing the same `CrawlerProvider`
   ABC), but needs a Chromium binary this sandbox doesn't have installed
   and cost/latency tradeoffs to design (render everything vs. only pages
   that look JS-dependent).
6. **SERP Intelligence Agent** — needs a `SERPProvider` (SerpApi,
   DataForSEO, etc.); interface is defined, no implementation yet since it
   requires a paid API and outbound network.
7. **Competitor Intelligence Agent** — crawl a competitor's site with the
   same `CrawlerAgent` (it already works on any URL, and now does so
   safely thanks to SSRF protection) and diff its `pages`/`keywords`
   against the primary site's. This is mostly *composition* of what
   already exists, not new infrastructure — a good first "real" agent to
   add next.
8. **Content Creation / Optimization Agents** — need an `LLMProvider`
   implementation (interface defined in `providers/base.py`) plus strict
   grounding in the Information Gain framing from the spec (what's
   missing vs. competitors, not just "write more words"). Should reuse
   `keyword_agent`'s cannibalization check before proposing new pages.
9. **Analytics Agent** (GSC + GA4 historical trend analysis) — client
   wiring exists; needs live credentials + network, then a "statistical
   significance" layer before it's allowed to say a change "caused"
   anything (ties into the Experiment Agent below).
10. **SEO Experiment Agent** — the `experiments` table exists; needs an
    agent that opens/closes experiments and evaluates them against GSC
    data with a real significance test (not just "went up/down").

## Lower priority / longer-horizon

11. **Local SEO Agent** and **Programmatic SEO Agent** — valuable for a
    subset of sites, best built once there's a real client with that
    business model to validate against real data rather than guessing at
    the right heuristics.
12. **Backlink/Authority Agent** — `BacklinkProvider` interface exists;
    needs Ahrefs/Majestic credentials + a policy layer that only ever
    proposes ethical, non-automatable digital-PR ideas (per spec section
    3.O, "never automate spammy link acquisition").
13. **AI-search-visibility layer** — treat as an experimental measurement,
    not a ranking-factor claim; needs periodically querying answer engines
    for target queries and logging whether/how the site is cited.
14. **CMS write integration (WordPress first)** — read-only by default,
    approval → backup → apply → verify → rollback as the spec requires.
    Real credential handling + a real WordPress REST API client; needs a
    live WP install to test safely against rather than guessing at
    response shapes.
15. **REST API + auth/RBAC + web dashboard + job queue/scheduling** — this
    is a genuine multi-service architecture change (a server process,
    a database migration tool, a task queue like RQ/Celery/arq, a
    frontend). Worth doing once there are 2+ real agents beyond what
    exists today generating enough ongoing findings to justify a live
    dashboard instead of the current CLI + HTML report.

