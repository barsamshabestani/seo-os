# Configuration

Everything is configured via environment variables (see `seo_os/config.py`).
Nothing is hard-coded and no secrets live in source control.

## Core

| Variable | Default | Meaning |
|---|---|---|
| `SEO_OS_DB` | `./data/seo_os.sqlite3` | SQLite database path |
| `SEO_OS_LOG_DIR` | `./logs` | Reserved for future file-based logging (agent runs are currently logged to the DB's `agent_runs` table) |

## Crawler

| Variable | Default | Meaning |
|---|---|---|
| `SEO_OS_MAX_PAGES` | 500 | Stop crawling after this many pages |
| `SEO_OS_MAX_DEPTH` | 10 | Max link depth from the seed URL |
| `SEO_OS_CONCURRENCY` | 4 | Concurrent fetches per crawl level (thread pool) |
| `SEO_OS_PER_HOST_DELAY` | 0 | Minimum seconds between requests to the same host, enforced across all worker threads |
| `SEO_OS_DELAY` | 0 | Reserved for a simple global inter-request delay (superseded by `SEO_OS_PER_HOST_DELAY` for the concurrent crawler; kept for backward compatibility) |
| `SEO_OS_USER_AGENT` | `SEO-OS-Bot/1.0 (...)` | User-Agent sent on every request and used for robots.txt matching |
| `SEO_OS_TIMEOUT` | 10 | Per-request timeout, seconds |
| `SEO_OS_RESPECT_ROBOTS` | `1` | Set to `0` to ignore robots.txt (e.g. your own staging environment) |
| `SEO_OS_MAX_RESPONSE_BYTES` | 20MB | Response bodies larger than this are truncated (streamed, not fully buffered first) — see `page.response_truncated` |
| `SEO_OS_MAX_RETRIES` | 2 | Retries with capped exponential backoff on transient fetch errors |
| `SEO_OS_ALLOW_PRIVATE_TARGETS` | `0` | **Security-relevant.** By default the crawler refuses to fetch loopback/private-network/link-local targets (SSRF protection — see `seo_os/security/url_safety.py`). Set to `1`, or pass `--allow-private-targets` on `seo audit`/`seo crawl`, only for intentional internal/staging crawls. |
| `SEO_OS_LOG_LEVEL` | `INFO` | Structured JSON log verbosity (`seo_os/observability.py`) |

## Risk / change management

| Variable | Default | Meaning |
|---|---|---|
| `SEO_OS_AUTO_LOW_RISK` | `0` | If `1`, low-risk actions are auto-approved (still logged, still require the same `apply` step — never silently applied) |
| `SEO_OS_MEDIUM_REQUIRES_APPROVAL` | `1` | Set to `0` to allow medium-risk actions to skip approval (not recommended) |

## External providers (all optional — unset = "unavailable", never fabricated)

| Variable | Enables |
|---|---|
| `GSC_SERVICE_ACCOUNT_JSON` | Google Search Console (path to a service account JSON key with Search Console API access, granted access to the property) |
| `GA4_PROPERTY_ID` | Google Analytics 4 (numeric GA4 property ID; also requires Google Cloud credentials to be available via the standard `google-auth` credential chain) |
| `AHREFS_API_KEY` | Ahrefs (backlinks + keyword data) |
| `SEMRUSH_API_KEY` | Semrush (keyword data) |
| `PAGESPEED_API_KEY` | Google PageSpeed Insights (Core Web Vitals) |
| `BING_WEBMASTER_API_KEY` | Bing Webmaster Tools (interface reserved; no client implemented yet — see ROADMAP) |

To wire up a real provider: set its environment variable and construct the
provider yourself when instantiating an agent (e.g.
`KeywordIntelligenceAgent(db, site_id, keyword_data_provider=AhrefsProvider())`);
the CLI's default wiring does not auto-inject paid providers so that running
`seo audit` never makes a billed API call you didn't explicitly opt into.
`is_configured()` will be `True` once the variable is set, and the agent
will use real returned data instead of marking it unavailable.

## Business context

Business goals (high-value products/services/locations/audiences/conversion
events) drive real priority-score boosts, not just storage. Manage them with:

```bash
seo goals add <url> --kind high_value_service --label roofing --weight 1.8
seo goals list <url>
seo goals update <url> <goal_id> --weight 2.0
seo goals remove <url> <goal_id>
```

`kind` must be one of: `high_value_product`, `high_value_service`,
`target_location`, `target_audience`, `conversion_event`. `label` is
matched case-insensitively as a substring against affected pages' URLs —
deliberately simple and explainable rather than a black box. After
`seo audit` runs, any issue affecting a page whose URL matches a goal's
label gets its `priority_score` boosted proportionally to that goal's
`weight`, and its `business_impact` field gets an explicit `[Boosted: ...]`
note naming which goal did it, so the score is never unexplained. With no
goals configured, scoring is unchanged from each agent's default
`business_value` (see `seo_os/agents/orchestrator.py::_apply_business_goal_weighting`).
