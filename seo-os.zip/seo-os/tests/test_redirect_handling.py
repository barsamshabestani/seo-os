from seo_os.providers.http_crawler import RequestsCrawlerProvider
from seo_os.security.url_safety import SSRFPolicy


def _provider():
    return RequestsCrawlerProvider(
        "test-agent", timeout=5,
        ssrf_policy=SSRFPolicy(allow_private_networks=True, allow_localhost=True),
    )


def test_redirect_chain_recorded(fixture_base_url):
    p = _provider()
    result = p.fetch(fixture_base_url + "redirect-chain-1")
    assert result.status_code == 200
    assert len(result.redirect_chain) == 3
    assert result.final_url.endswith("/services")


def test_redirect_loop_detected_not_hung(fixture_base_url):
    p = _provider()
    result = p.fetch(fixture_base_url + "redirect-loop-a")
    assert result.status_code == 0
    assert "loop" in (result.error or "").lower()


def test_ssrf_policy_blocks_fetch_to_metadata_endpoint():
    p = _provider()
    # Even with a permissive local policy, the *default* policy used by
    # RequestsCrawlerProvider() with no override must reject this --
    # exercised here directly against a strict provider instance.
    strict = RequestsCrawlerProvider("test-agent", timeout=2)
    result = strict.fetch("http://169.254.169.254/")
    assert result.status_code == 0
    assert "ssrf" in (result.error or "").lower() or "blocked" in (result.error or "").lower()
