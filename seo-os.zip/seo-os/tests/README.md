# Tests

`test_*.py` and `conftest.py` are normal pytest tests — in any environment
with `pip install pytest` and network access, `pytest tests/ -v` runs them
as-is.

This build environment had no outbound network access, so `pytest` itself
couldn't be installed. `run_all_tests.py` is a small (~100 line) runner
that imports the same unmodified test files and supplies the same
fixtures conftest.py defines (`db`, `site_id`, `fixture_base_url`,
`tmp_path`) by inspecting each test function's parameter names. It also
drops in a minimal `pytest` shim (`_pytest_shim/pytest.py`, providing just
`raises` and `fixture`) so the test files' `import pytest` doesn't fail.

```bash
python3 tests/run_all_tests.py
```

27/27 passing as of this build. All tests run against a real local HTTP
server (`fixtures/fixture_site.py`, a small Flask app with 17 deliberately
seeded SEO problems) — nothing is mocked at the HTTP layer.
