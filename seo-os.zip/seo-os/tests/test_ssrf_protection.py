from seo_os.security.url_safety import validate_url_safety, is_safe_url, UnsafeURLError, SSRFPolicy


def test_blocks_cloud_metadata_endpoint():
    assert not is_safe_url("http://169.254.169.254/latest/meta-data/")


def test_blocks_loopback():
    assert not is_safe_url("http://127.0.0.1/")
    assert not is_safe_url("http://localhost/")


def test_blocks_private_ranges():
    for ip in ("10.0.0.1", "172.16.0.1", "192.168.1.1"):
        assert not is_safe_url(f"http://{ip}/")


def test_blocks_disallowed_scheme():
    assert not is_safe_url("ftp://example.com/")
    assert not is_safe_url("file:///etc/passwd")


def test_allows_public_https():
    assert is_safe_url("https://example.com/")


def test_policy_can_explicitly_allow_private_targets():
    policy = SSRFPolicy(allow_private_networks=True, allow_localhost=True)
    assert is_safe_url("http://127.0.0.1:8000/", policy)
    assert is_safe_url("http://10.0.0.5/", policy)


def test_policy_still_blocks_link_local_even_when_private_allowed():
    """Cloud metadata (169.254.169.254) must stay blocked even for a policy
    that otherwise allows private/internal targets -- it's a distinct,
    always-dangerous range."""
    policy = SSRFPolicy(allow_private_networks=True, allow_localhost=True)
    assert not is_safe_url("http://169.254.169.254/", policy)


def test_validate_raises_with_reason():
    try:
        validate_url_safety("http://192.168.1.1/")
        assert False, "expected UnsafeURLError"
    except UnsafeURLError as e:
        assert "private" in str(e).lower()


def test_allowlist_mode_blocks_everything_not_listed():
    policy = SSRFPolicy(allowed_hosts=frozenset({"example.com"}))
    assert is_safe_url("https://example.com/", policy)
    assert not is_safe_url("https://other.com/", policy)
