from seo_os.agents.orchestrator import Orchestrator
from seo_os.config import CrawlConfig


def test_add_business_goal_rejects_invalid_kind(db, site_id):
    try:
        db.add_business_goal(site_id, "not_a_real_kind", "label")
        assert False, "expected ValueError"
    except ValueError:
        pass


def test_add_list_update_remove_business_goal(db, site_id):
    goal_id = db.add_business_goal(site_id, "high_value_service", "roofing", weight=1.5)
    goals = db.list_business_goals(site_id)
    assert len(goals) == 1
    assert goals[0]["label"] == "roofing"

    db.update_business_goal(goal_id, weight=2.0)
    goals = db.list_business_goals(site_id)
    assert goals[0]["weight"] == 2.0

    db.remove_business_goal(goal_id)
    assert db.list_business_goals(site_id) == []


def test_business_goal_boosts_matching_issue_priority(db, site_id, fixture_base_url):
    """End-to-end: an issue affecting a page that matches a configured
    business goal must score higher than the same issue would without
    that goal -- and must say why, not just present a bigger number."""
    cfg = CrawlConfig(max_pages=100, allow_private_targets=True)
    orch = Orchestrator(db, site_id)

    orch.run_full_audit(fixture_base_url, crawl_config=cfg)
    baseline = {i["issue_type"]: i["priority_score"] for i in db.get_issues(site_id)}
    assert "duplicate_title" in baseline  # /services and /services-2 share a title

    db.add_business_goal(site_id, "high_value_service", "services", weight=1.8,
                         notes="core service pages")
    orch.run_full_audit(fixture_base_url, crawl_config=cfg)

    latest_run = db.conn.execute(
        "SELECT id FROM crawl_runs WHERE site_id=? ORDER BY id DESC LIMIT 1", (site_id,)
    ).fetchone()["id"]
    boosted_issue = next(
        i for i in db.get_issues(site_id, latest_run) if i["issue_type"] == "duplicate_title"
    )
    assert boosted_issue["priority_score"] > baseline["duplicate_title"]
    assert "services" in boosted_issue["business_impact"]
    assert "Boosted" in boosted_issue["business_impact"]


def test_no_goals_configured_leaves_scores_unchanged(db, site_id, fixture_base_url):
    """Without any business_goals rows, weighting must be a no-op --
    documented, not a silent default multiplier."""
    cfg = CrawlConfig(max_pages=100, allow_private_targets=True)
    orch = Orchestrator(db, site_id)
    orch.run_full_audit(fixture_base_url, crawl_config=cfg)
    issue = next(i for i in db.get_issues(site_id) if i["issue_type"] == "duplicate_title")
    assert "Boosted" not in issue["business_impact"]
