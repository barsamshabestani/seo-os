from seo_os.agents.crawler_agent import CrawlerAgent
from seo_os.agents.technical_seo_agent import TechnicalSeoAgent
from seo_os.config import CrawlConfig


def _crawl_and_audit(db, site_id, base_url):
    crawler = CrawlerAgent(db, site_id, CrawlConfig(max_pages=100, allow_private_targets=True))
    run_id = crawler.crawl(base_url)
    TechnicalSeoAgent(db, site_id).audit(run_id)
    return {i["issue_type"]: i for i in db.get_issues(site_id, run_id)}


def test_finds_all_seeded_technical_issues(db, site_id, fixture_base_url):
    issues = _crawl_and_audit(db, site_id, fixture_base_url)
    expected_types = {
        "broken_page", "missing_title", "duplicate_title", "missing_meta_description",
        "missing_h1", "thin_content", "duplicate_content", "broken_internal_link",
        "parameter_urls", "redirect_present",
    }
    assert expected_types.issubset(issues.keys())


def test_every_issue_has_required_fields(db, site_id, fixture_base_url):
    issues = _crawl_and_audit(db, site_id, fixture_base_url)
    for issue in issues.values():
        assert issue["severity"] in ("critical", "high", "medium", "low")
        assert 0 <= issue["confidence"] <= 1
        assert issue["recommended_fix"]
        assert issue["priority_score"] is not None


def test_missing_title_flags_correct_page(db, site_id, fixture_base_url):
    issues = _crawl_and_audit(db, site_id, fixture_base_url)
    import json
    evidence = json.loads(issues["missing_title"]["evidence"])
    assert any("no-title" in ex for ex in evidence["examples"])


def test_new_phase4_checks_detected(db, site_id, fixture_base_url):
    """Covers the checks added in this pass: title length, image alt/dimensions,
    hreflang validation, canonical loop / canonical-to-invalid-target,
    long redirect chains, and URL hygiene."""
    issues = _crawl_and_audit(db, site_id, fixture_base_url)
    expected_new_types = {
        "title_length_issue", "missing_image_alt_text", "missing_image_dimensions",
        "hreflang_issue", "canonical_loop", "canonical_points_to_invalid_target",
        "long_redirect_chain", "url_hygiene",
    }
    assert expected_new_types.issubset(issues.keys())


def test_canonical_loop_evidence_names_both_pages(db, site_id, fixture_base_url):
    import json
    issues = _crawl_and_audit(db, site_id, fixture_base_url)
    evidence = json.loads(issues["canonical_loop"]["evidence"])
    urls = {e["url"] for e in evidence["examples"]}
    assert any("canonical-loop-a" in u for u in urls)
    assert any("canonical-loop-b" in u for u in urls)


def test_url_hygiene_flags_uppercase_path(db, site_id, fixture_base_url):
    import json
    issues = _crawl_and_audit(db, site_id, fixture_base_url)
    evidence = json.loads(issues["url_hygiene"]["evidence"])
    assert any("UPPERCASE-Path" in e["url"] for e in evidence["examples"])


def test_html_size_and_pagination_checks_present(db, site_id, fixture_base_url):
    from seo_os.agents.crawler_agent import normalize_url
    issues = _crawl_and_audit(db, site_id, fixture_base_url)

    home_page = db.get_page_by_url(site_id, normalize_url(fixture_base_url))
    assert home_page["html_size_bytes"] is not None and home_page["html_size_bytes"] > 0

    assert "pagination_missing_canonical" in issues
    import json
    evidence = json.loads(issues["pagination_missing_canonical"]["evidence"])
    urls = evidence["examples"]
    assert any("/blog/page/" in u for u in urls)


def test_no_false_positive_on_clean_page(db, site_id, fixture_base_url):
    """The /article page is deliberately well-formed and should not appear
    in the missing_title/missing_h1/missing_meta_description evidence."""
    issues = _crawl_and_audit(db, site_id, fixture_base_url)
    import json
    for key in ("missing_title", "missing_h1", "missing_meta_description"):
        evidence = json.loads(issues[key]["evidence"])
        examples = evidence["examples"]
        assert not any("/article" in (e if isinstance(e, str) else e.get("url", "")) for e in examples)
