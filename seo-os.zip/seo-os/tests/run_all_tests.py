"""
Minimal pytest-compatible test runner.

This sandbox has no outbound network access, so `pip install pytest` isn't
possible here. Rather than skip automated testing, this runner imports the
existing tests/test_*.py files unchanged (they're normal pytest-style test
functions) and supplies the same fixtures conftest.py defines, by inspecting
each test function's parameter names. This means the test files are real,
portable pytest tests -- `pip install pytest && pytest tests/` will run them
unmodified in any environment that does have network access; this script is
just how *this* environment proves they pass.
"""
from __future__ import annotations
import importlib
import inspect
import os
import shutil
import sys
import tempfile
import threading
import time
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixtures"))

try:
    import pytest  # noqa: F401
except ImportError:
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "_pytest_shim"))

os.environ.setdefault("SEO_OS_LOG_LEVEL", "WARNING")  # quiet structured logs during test runs


from fixture_site import app  # noqa: E402
from seo_os.db import DB  # noqa: E402

PORT = 8940
BASE_URL = f"http://127.0.0.1:{PORT}/"

TEST_MODULES = [
    "test_crawler",
    "test_technical_seo",
    "test_internal_linking",
    "test_schema",
    "test_priority_engine",
    "test_qa_and_change_management",
    "test_ssrf_protection",
    "test_redirect_handling",
    "test_historical_snapshots",
    "test_business_goals",
]


def start_server():
    t = threading.Thread(target=lambda: app.run(host="127.0.0.1", port=PORT, use_reloader=False, threaded=True), daemon=True)
    t.start()
    time.sleep(0.6)


class FixtureFactory:
    """Resolves the small set of fixtures conftest.py defines, purely by
    parameter name, for a single test invocation."""

    def __init__(self):
        self._tmp_dir = None
        self._db = None

    def resolve(self, param_name: str):
        if param_name == "fixture_base_url":
            return BASE_URL
        if param_name == "tmp_path":
            self._tmp_dir = tempfile.mkdtemp()
            import pathlib
            return pathlib.Path(self._tmp_dir)
        if param_name == "db":
            self._tmp_dir = self._tmp_dir or tempfile.mkdtemp()
            path = os.path.join(self._tmp_dir, "test.sqlite3")
            self._db = DB(path)
            return self._db
        if param_name == "site_id":
            db = self._db or self.resolve("db")
            return db.get_or_create_site(BASE_URL)
        raise ValueError(f"Unknown fixture: {param_name}")

    def cleanup(self):
        if self._db:
            self._db.close()
        if self._tmp_dir and os.path.exists(self._tmp_dir):
            shutil.rmtree(self._tmp_dir, ignore_errors=True)


def run():
    start_server()
    total = 0
    passed = 0
    failures = []

    for mod_name in TEST_MODULES:
        mod = importlib.import_module(mod_name)
        test_funcs = [
            (name, obj) for name, obj in inspect.getmembers(mod)
            if name.startswith("test_") and inspect.isfunction(obj)
        ]
        for name, func in test_funcs:
            total += 1
            factory = FixtureFactory()
            sig = inspect.signature(func)
            try:
                kwargs = {p: factory.resolve(p) for p in sig.parameters}
                func(**kwargs)
                passed += 1
                print(f"  PASS  {mod_name}.{name}")
            except Exception as e:
                failures.append((mod_name, name, e, traceback.format_exc()))
                print(f"  FAIL  {mod_name}.{name}: {e}")
            finally:
                factory.cleanup()

    print(f"\n{passed}/{total} tests passed")
    if failures:
        print("\n=== FAILURE DETAILS ===")
        for mod_name, name, e, tb in failures:
            print(f"\n--- {mod_name}.{name} ---")
            print(tb)
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    run()
