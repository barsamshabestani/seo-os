from seo_os.agents.crawler_agent import CrawlerAgent, normalize_url
from seo_os.config import CrawlConfig


def test_normalize_url_strips_fragment_and_trailing_slash():
    assert normalize_url("http://x.com/a/") == normalize_url("http://x.com/a")
    assert normalize_url("http://x.com/a#frag") == normalize_url("http://x.com/a")
    assert normalize_url("HTTP://X.COM/a") == normalize_url("http://x.com/a")


def test_crawl_discovers_all_seeded_pages(db, site_id, fixture_base_url):
    crawler = CrawlerAgent(db, site_id, CrawlConfig(max_pages=100, allow_private_targets=True))
    run_id = crawler.crawl(fixture_base_url)
    pages = [p for p in db.get_pages(site_id) if p["crawl_run_id"] == run_id]
    urls = {p["url"].replace(fixture_base_url.rstrip("/"), "") or "/" for p in pages}
    expected = {"/", "/services", "/services-2", "/about", "/blog/roof-guide", "/orphan",
                "/faq", "/article", "/invalid-schema", "/no-title", "/no-meta", "/no-h1",
                "/thin", "/dup-a", "/dup-b", "/old-page", "/broken-link-target"}
    assert expected.issubset(urls)


def test_broken_page_status_captured(db, site_id, fixture_base_url):
    crawler = CrawlerAgent(db, site_id, CrawlConfig(max_pages=100, allow_private_targets=True))
    run_id = crawler.crawl(fixture_base_url)
    broken = db.get_page_by_url(site_id, normalize_url(fixture_base_url + "broken-link-target"))
    assert broken["status_code"] == 404


def test_redirect_captured(db, site_id, fixture_base_url):
    crawler = CrawlerAgent(db, site_id, CrawlConfig(max_pages=100, allow_private_targets=True))
    run_id = crawler.crawl(fixture_base_url)
    old = db.get_page_by_url(site_id, normalize_url(fixture_base_url + "old-page"))
    assert old["redirect_target"] is not None
    assert "/services" in old["redirect_target"]


def test_duplicate_content_hash_matches(db, site_id, fixture_base_url):
    crawler = CrawlerAgent(db, site_id, CrawlConfig(max_pages=100, allow_private_targets=True))
    run_id = crawler.crawl(fixture_base_url)
    a = db.get_page_by_url(site_id, normalize_url(fixture_base_url + "dup-a"))
    b = db.get_page_by_url(site_id, normalize_url(fixture_base_url + "dup-b"))
    assert a["content_hash"] == b["content_hash"]


def test_max_pages_respected(db, site_id, fixture_base_url):
    crawler = CrawlerAgent(db, site_id, CrawlConfig(max_pages=3, allow_private_targets=True))
    run_id = crawler.crawl(fixture_base_url)
    pages = [p for p in db.get_pages(site_id) if p["crawl_run_id"] == run_id]
    assert len(pages) <= 3
