"""
Runs the fixture site in a background thread (same process, so it survives
regardless of how the outer shell manages child processes) and then drives
the full orchestrator against it. Used both as a manual e2e smoke test and
as the foundation for pytest fixtures.
"""
import os
import sys
import threading
import time

os.environ.setdefault("SEO_OS_ALLOW_PRIVATE_TARGETS", "1")  # this harness targets 127.0.0.1 on purpose

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixtures"))

from fixture_site import app  # noqa: E402
from seo_os.db import DB  # noqa: E402
from seo_os.agents.orchestrator import Orchestrator  # noqa: E402
from seo_os.reporting.report import render_markdown, render_html  # noqa: E402

PORT = 8931
BASE_URL = f"http://127.0.0.1:{PORT}/"


def start_server():
    t = threading.Thread(
        target=lambda: app.run(host="127.0.0.1", port=PORT, use_reloader=False, threaded=True),
        daemon=True,
    )
    t.start()
    time.sleep(0.6)
    return t


def main():
    start_server()
    db_path = "./data/seo_os.sqlite3"
    if os.path.exists(db_path):
        os.remove(db_path)
    db = DB(db_path)
    site_id = db.get_or_create_site(BASE_URL)
    from seo_os.config import CrawlConfig
    orch = Orchestrator(db, site_id)
    result = orch.run_full_audit(BASE_URL, brand_terms=["acme"], crawl_config=CrawlConfig(allow_private_targets=True))
    print("=== AUDIT RESULT ===")
    print(result)

    pages = db.get_pages(site_id)
    print(f"\n=== PAGES ({len(pages)}) ===")
    for p in pages:
        print(f"  {p['status_code']:>3} depth={p['depth']} words={p['word_count']} {p['url']}")

    issues = db.get_issues(site_id)
    print(f"\n=== ISSUES ({len(issues)}) ===")
    for i in sorted(issues, key=lambda x: -(x["priority_score"] or 0)):
        print(f"  [{i['priority_score']:>5.1f}] {i['severity']:>8} conf={i['confidence']:.2f}  {i['issue_type']:<38} {i['title']}")

    actions = db.get_actions(site_id)
    print(f"\n=== ACTIONS ({len(actions)}) ===")
    for a in actions:
        print(f"  #{a['id']} [{a['risk_level']}] {a['status']:<10} {a['description']}")

    kws = db.conn.execute("SELECT keyword, intent FROM keywords WHERE site_id=? LIMIT 15", (site_id,)).fetchall()
    print(f"\n=== SAMPLE KEYWORDS ===")
    for k in kws:
        print(f"  {k['intent']:<14} {k['keyword']}")

    md = render_markdown(db, site_id, BASE_URL)
    with open("./data/report.md", "w") as f:
        f.write(md)
    html = render_html(db, site_id, BASE_URL)
    with open("./data/report.html", "w") as f:
        f.write(html)
    print("\nWrote ./data/report.md and ./data/report.html")

    return db, site_id, issues, actions, pages


if __name__ == "__main__":
    main()
