"""
A small, deterministic fixture website used to test every agent against
real HTTP traffic instead of mocked data. It deliberately seeds a known
set of SEO issues so tests can assert the audit finds exactly what's there.

Seeded issues:
  - /broken-link-target -> 404 (linked from /services)
  - /old-page -> 301 redirects to /services
  - /orphan -> exists (in a route) but is never linked from anywhere
  - /thin -> under 150 words
  - /dup-a, /dup-b -> byte-identical body content
  - /no-title -> missing <title>
  - /no-meta -> missing meta description
  - /no-h1 -> missing <h1>
  - /faq -> has question-style headings, no FAQPage schema (schema opportunity)
  - /article -> has valid Article JSON-LD (control: should NOT trigger issues)
  - /invalid-schema -> Article JSON-LD missing required fields
  - /search?q=test -> parameterized URL
  - duplicate titles: /services and /services-2 share a title
"""
from __future__ import annotations
from flask import Flask, Response, redirect

app = Flask(__name__)

BASE_STYLE = "<html><head>{head}</head><body>{body}</body></html>"


def page(title=None, meta=None, h1=None, body_extra="", links=""):
    head = ""
    if title:
        head += f"<title>{title}</title>"
    if meta:
        head += f'<meta name="description" content="{meta}">'
    body = ""
    if h1:
        body += f"<h1>{h1}</h1>"
    body += f"<p>{body_extra}</p>{links}"
    return BASE_STYLE.format(head=head, body=body)


LONG_TEXT = " ".join(["This is genuinely useful, original content about our service."] * 40)


@app.route("/")
def home():
    return page(
        title="Acme Roofing | Home",
        meta="Acme Roofing installs and repairs roofs across the metro area.",
        h1="Acme Roofing",
        body_extra=LONG_TEXT,
        links=(
            '<a href="/services">Services</a> '
            '<a href="/about">About</a> '
            '<a href="/blog/roof-guide">Roof Guide</a> '
            '<a href="/faq">FAQ</a> '
            '<a href="/article">Article</a> '
            '<a href="/invalid-schema">Invalid Schema</a> '
            '<a href="/no-title">No Title</a> '
            '<a href="/no-meta">No Meta</a> '
            '<a href="/no-h1">No H1</a> '
            '<a href="/thin">Thin</a> '
            '<a href="/dup-a">Dup A</a> '
            '<a href="/dup-b">Dup B</a> '
            '<a href="/old-page">Old Page (redirects)</a> '
            '<a href="/search?q=test">Search</a> '
            '<a href="/redirect-chain-1">Redirect Chain</a> '
            '<a href="/bad-images">Bad Images</a> '
            '<a href="/hreflang-bad">Hreflang Bad</a> '
            '<a href="/canonical-loop-a">Canonical Loop A</a> '
            '<a href="/canonical-to-broken">Canonical To Broken</a> '
            '<a href="/UPPERCASE-Path">Uppercase Path</a> '
            '<a href="/blog/page/1">Blog Page 1</a>'
        ),
    )


@app.route("/services")
def services():
    return page(
        title="Our Services | Acme Roofing",
        meta="Explore our full range of roofing services.",
        h1="Our Services",
        body_extra=LONG_TEXT,
        links='<a href="/broken-link-target">Emergency Repairs</a> <a href="/services-2">More services</a>',
    )


@app.route("/services-2")
def services2():
    # Duplicate title vs /services on purpose.
    return page(
        title="Our Services | Acme Roofing",
        meta="A second services page with a different meta description.",
        h1="Residential & Commercial Roofing",
        body_extra=LONG_TEXT,
    )


@app.route("/about")
def about():
    return page(
        title="About Acme Roofing",
        meta="Family owned and operated since 1998.",
        h1="About Us",
        body_extra=LONG_TEXT,
    )


@app.route("/blog/roof-guide")
def blog_roof_guide():
    return page(
        title="The Complete Guide to Roof Maintenance",
        meta="Everything homeowners need to know about maintaining a roof.",
        h1="The Complete Guide to Roof Maintenance",
        body_extra=LONG_TEXT + " Learn how often to inspect your roof and what to look for.",
    )


@app.route("/orphan")
def orphan():
    # Deliberately not linked from any other page.
    return page(
        title="Unlinked Promo Page",
        meta="A page nobody links to.",
        h1="Unlinked Promo Page",
        body_extra=LONG_TEXT,
    )


@app.route("/thin")
def thin():
    return page(title="Thin Page", meta="Not much here.", h1="Thin Page", body_extra="Just a little bit of text.")


@app.route("/dup-a")
def dup_a():
    return page(title="Duplicate A", meta="Duplicate content example A.", h1="Duplicate Content",
                body_extra=LONG_TEXT)


@app.route("/dup-b")
def dup_b():
    return page(title="Duplicate B", meta="Duplicate content example B.", h1="Duplicate Content",
                body_extra=LONG_TEXT)


@app.route("/no-title")
def no_title():
    return "<html><head></head><body><h1>No Title Tag Here</h1><p>" + LONG_TEXT + "</p></body></html>"


@app.route("/no-meta")
def no_meta():
    return page(title="No Meta Description", h1="No Meta Description", body_extra=LONG_TEXT)


@app.route("/no-h1")
def no_h1():
    return page(title="No H1 Page", meta="This page has no H1.", body_extra=LONG_TEXT)


@app.route("/faq")
def faq():
    return page(
        title="Roofing FAQ",
        meta="Answers to common roofing questions.",
        h1="Frequently Asked Questions",
        body_extra=(
            "<h2>How long does a roof last?</h2><p>" + LONG_TEXT + "</p>"
            "<h2>What does a roof replacement cost?</h2><p>" + LONG_TEXT + "</p>"
        ),
    )


@app.route("/article")
def article():
    ld = (
        '<script type="application/ld+json">'
        '{"@context":"https://schema.org","@type":"Article",'
        '"headline":"Roof Maintenance 101","author":{"@type":"Person","name":"J. Smith"},'
        '"datePublished":"2026-01-01"}'
        "</script>"
    )
    return page(title="Roof Maintenance 101", meta="A well-formed article.", h1="Roof Maintenance 101",
                body_extra=LONG_TEXT + ld)


@app.route("/invalid-schema")
def invalid_schema():
    ld = (
        '<script type="application/ld+json">'
        '{"@context":"https://schema.org","@type":"Article","headline":"Incomplete Article"}'
        "</script>"
    )
    return page(title="Incomplete Article", meta="Missing required schema fields.", h1="Incomplete Article",
                body_extra=LONG_TEXT + ld)


@app.route("/old-page")
def old_page():
    return redirect("/services", code=301)


@app.route("/redirect-chain-1")
def redirect_chain_1():
    return redirect("/redirect-chain-2", code=301)


@app.route("/redirect-chain-2")
def redirect_chain_2():
    return redirect("/redirect-chain-3", code=302)


@app.route("/redirect-chain-3")
def redirect_chain_3():
    return redirect("/services", code=301)


@app.route("/redirect-loop-a")
def redirect_loop_a():
    return redirect("/redirect-loop-b", code=302)


@app.route("/redirect-loop-b")
def redirect_loop_b():
    return redirect("/redirect-loop-a", code=302)


@app.route("/search")
def search():
    return page(title="Search Results", meta="Search results page.", h1="Search",
                body_extra=LONG_TEXT)


@app.route("/long-redirect-chain-landing")
def long_redirect_landing():
    return page(title="Long Redirect Landing", meta="Reached after a chain.", h1="Landing",
                body_extra=LONG_TEXT)


@app.route("/bad-images")
def bad_images():
    return page(
        title="Roofing Photo Gallery",
        meta="Photos of our recent roofing projects.",
        h1="Photo Gallery",
        body_extra=(
            LONG_TEXT +
            '<img src="/static/roof1.jpg">'  # no alt, no dimensions
            '<img src="/static/roof2.jpg" alt="">'  # empty alt
            '<img src="/static/roof3.jpg" alt="A finished roof" width="400" height="300">'  # fine
        ),
    )


@app.route("/hreflang-bad")
def hreflang_bad():
    head_extra = (
        '<link rel="alternate" hreflang="en" href="http://EXAMPLE-NOT-SELF.test/hreflang-bad">'
        '<link rel="alternate" hreflang="en" href="http://EXAMPLE-NOT-SELF.test/hreflang-bad-2">'
    )
    return (
        f"<html><head><title>Hreflang Test</title>{head_extra}</head>"
        f"<body><h1>Hreflang Test</h1><p>{LONG_TEXT}</p></body></html>"
    )


@app.route("/canonical-loop-a")
def canonical_loop_a():
    from flask import request
    head = f'<link rel="canonical" href="{request.host_url.rstrip("/")}/canonical-loop-b">'
    body_links = '<a href="/canonical-loop-b">Loop B</a>'
    return (f"<html><head><title>Loop A</title>{head}</head>"
            f"<body><h1>Loop A</h1><p>{LONG_TEXT}</p>{body_links}</body></html>")


@app.route("/canonical-loop-b")
def canonical_loop_b():
    from flask import request
    head = f'<link rel="canonical" href="{request.host_url.rstrip("/")}/canonical-loop-a">'
    return f"<html><head><title>Loop B</title>{head}</head><body><h1>Loop B</h1><p>{LONG_TEXT}</p></body></html>"


@app.route("/canonical-to-broken")
def canonical_to_broken():
    from flask import request
    head = f'<link rel="canonical" href="{request.host_url.rstrip("/")}/broken-link-target">'
    return (f"<html><head><title>Canonical To Broken</title>{head}</head>"
            f"<body><h1>Canonical To Broken</h1><p>{LONG_TEXT}</p></body></html>")


@app.route("/blog/page/1")
def blog_page_1():
    head_extra = '<link rel="next" href="/blog/page/2">'
    return (f"<html><head><title>Blog Page 1</title>{head_extra}</head>"
            f"<body><h1>Blog Page 1</h1><p>{LONG_TEXT}</p>"
            f'<a href="/blog/page/2">Next</a></body></html>')


@app.route("/blog/page/2")
def blog_page_2():
    head_extra = '<link rel="prev" href="/blog/page/1"><link rel="next" href="/blog/page/3">'
    return (f"<html><head><title>Blog Page 2</title>{head_extra}</head>"
            f"<body><h1>Blog Page 2</h1><p>{LONG_TEXT}</p>"
            f'<a href="/blog/page/3">Next</a></body></html>')


@app.route("/blog/page/3")
def blog_page_3():
    head_extra = '<link rel="prev" href="/blog/page/2">'
    return (f"<html><head><title>Blog Page 3</title>{head_extra}</head>"
            f"<body><h1>Blog Page 3</h1><p>{LONG_TEXT}</p></body></html>")


@app.route("/UPPERCASE-Path")
def uppercase_path():
    return page(title="Uppercase Path Page", meta="URL hygiene test.", h1="Uppercase Path", body_extra=LONG_TEXT)


@app.route("/robots.txt")
def robots():
    return Response("User-agent: *\nAllow: /\nSitemap: /sitemap.xml\n", mimetype="text/plain")


@app.route("/sitemap.xml")
def sitemap():
    from flask import request
    urls = ["/", "/services", "/services-2", "/about", "/blog/roof-guide", "/orphan"]
    body = "".join(f"<url><loc>{request.host_url.rstrip('/')}{u}</loc></url>" for u in urls)
    return Response(
        f'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">{body}</urlset>',
        mimetype="application/xml",
    )


@app.errorhandler(404)
def not_found(e):
    return "<html><head><title>Not Found</title></head><body><h1>404</h1></body></html>", 404


def run(port=8931):
    app.run(host="127.0.0.1", port=port, threaded=True)


if __name__ == "__main__":
    run()
