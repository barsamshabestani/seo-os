import json
from seo_os.agents.crawler_agent import CrawlerAgent
from seo_os.agents.schema_agent import SchemaAgent
from seo_os.config import CrawlConfig


def test_invalid_schema_detected(db, site_id, fixture_base_url):
    crawler = CrawlerAgent(db, site_id, CrawlConfig(max_pages=100, allow_private_targets=True))
    run_id = crawler.crawl(fixture_base_url)
    SchemaAgent(db, site_id).audit(run_id)
    issues = {i["issue_type"]: i for i in db.get_issues(site_id, run_id)}
    assert "invalid_structured_data" in issues
    evidence = json.loads(issues["invalid_structured_data"]["evidence"])
    assert any("invalid-schema" in ex["url"] for ex in evidence["examples"])


def test_valid_article_not_flagged_as_invalid(db, site_id, fixture_base_url):
    crawler = CrawlerAgent(db, site_id, CrawlConfig(max_pages=100, allow_private_targets=True))
    run_id = crawler.crawl(fixture_base_url)
    SchemaAgent(db, site_id).audit(run_id)
    issues = {i["issue_type"]: i for i in db.get_issues(site_id, run_id)}
    evidence = json.loads(issues["invalid_structured_data"]["evidence"])
    assert not any("/article" == ex["url"].split("8931")[-1] for ex in evidence["examples"] if "8931" in ex["url"])


def test_faq_page_suggested_for_faq_schema(db, site_id, fixture_base_url):
    crawler = CrawlerAgent(db, site_id, CrawlConfig(max_pages=100, allow_private_targets=True))
    run_id = crawler.crawl(fixture_base_url)
    SchemaAgent(db, site_id).audit(run_id)
    issues = {i["issue_type"]: i for i in db.get_issues(site_id, run_id)}
    evidence = json.loads(issues["missing_structured_data_opportunity"]["evidence"])
    faq_suggestions = [c for c in evidence["candidates"] if c["suggest"] == "FAQPage"]
    assert any("/faq" in c["url"] for c in faq_suggestions)


def test_never_suggests_review_schema():
    """Hard safety check: the agent's suggestion whitelist must never include
    Review/AggregateRating, since fabricating those is deceptive structured data."""
    from seo_os.agents.schema_agent import SAFE_TO_SUGGEST
    assert "Review" not in SAFE_TO_SUGGEST
    assert "AggregateRating" not in SAFE_TO_SUGGEST
