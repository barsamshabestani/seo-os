import json
from seo_os.agents.crawler_agent import CrawlerAgent
from seo_os.agents.internal_linking_agent import InternalLinkingAgent
from seo_os.config import CrawlConfig


def test_orphan_page_detected(db, site_id, fixture_base_url):
    crawler = CrawlerAgent(db, site_id, CrawlConfig(max_pages=100, allow_private_targets=True))
    run_id = crawler.crawl(fixture_base_url)
    InternalLinkingAgent(db, site_id).analyze(run_id)
    issues = {i["issue_type"]: i for i in db.get_issues(site_id, run_id)}
    assert "orphan_page_needs_links" in issues
    evidence = json.loads(issues["orphan_page_needs_links"]["evidence"])
    assert any("/orphan" in s["orphan_url"] for s in evidence["suggestions"])
