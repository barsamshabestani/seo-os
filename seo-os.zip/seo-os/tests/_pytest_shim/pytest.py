"""
Tiny compatibility shim so tests/test_*.py can `import pytest` and use the
handful of APIs they need even in this sandbox, which has no network access
to `pip install pytest`. NOT a general pytest reimplementation -- only
`raises` and `fixture` are provided, which is all these tests use.

In any normal environment, the real `pytest` package (already listed in
requirements-dev.txt) takes precedence on sys.path and this file is unused.
"""
from contextlib import contextmanager


@contextmanager
def raises(exc_type):
    try:
        yield
    except exc_type:
        return
    else:
        raise AssertionError(f"Expected {exc_type} to be raised, but nothing was raised.")


def fixture(*args, **kwargs):
    def decorator(func):
        return func
    if args and callable(args[0]):
        return args[0]
    return decorator
