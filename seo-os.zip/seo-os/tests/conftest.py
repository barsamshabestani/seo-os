import os
import sys
import threading
import time

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixtures"))

from fixture_site import app  # noqa: E402
from seo_os.db import DB  # noqa: E402

TEST_PORT = 8933
BASE_URL = f"http://127.0.0.1:{TEST_PORT}/"

_server_started = False
_lock = threading.Lock()


def _ensure_server():
    global _server_started
    with _lock:
        if _server_started:
            return
        t = threading.Thread(
            target=lambda: app.run(host="127.0.0.1", port=TEST_PORT, use_reloader=False, threaded=True),
            daemon=True,
        )
        t.start()
        time.sleep(0.6)
        _server_started = True


@pytest.fixture(scope="session")
def fixture_base_url():
    _ensure_server()
    return BASE_URL


@pytest.fixture()
def db(tmp_path):
    path = str(tmp_path / "test.sqlite3")
    database = DB(path)
    yield database
    database.close()


@pytest.fixture()
def site_id(db, fixture_base_url):
    return db.get_or_create_site(fixture_base_url)
