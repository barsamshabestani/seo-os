import pytest
from seo_os.agents.qa_agent import QAAgent
from seo_os.agents.orchestrator import Orchestrator
from seo_os.agents.crawler_agent import CrawlerAgent
from seo_os.config import CrawlConfig


def test_qa_fails_on_too_long_title(db, site_id):
    qa = QAAgent(db, site_id)
    result = qa.check_action({
        "action_type": "update_title",
        "description": "test",
        "after_state": {"title": "x" * 100},
    })
    assert not result.passed


def test_qa_passes_reasonable_title(db, site_id):
    qa = QAAgent(db, site_id)
    result = qa.check_action({
        "action_type": "update_title",
        "description": "test",
        "after_state": {"title": "A Reasonable Page Title"},
    })
    assert result.passed


def test_qa_flags_generic_anchor_text(db, site_id):
    qa = QAAgent(db, site_id)
    result = qa.check_action({
        "action_type": "add_internal_link",
        "description": "test",
        "after_state": {"target_url": "/x", "anchor_text": "click here"},
    })
    assert not result.passed


def test_high_risk_action_cannot_be_applied_without_approval(db, site_id, fixture_base_url):
    CrawlerAgent(db, site_id, CrawlConfig(max_pages=5, allow_private_targets=True)).crawl(fixture_base_url)
    orch = Orchestrator(db, site_id)
    action_id = db.propose_action(site_id, {
        "action_type": "update_canonical", "description": "risky change",
        "risk_level": "high", "before_state": {"canonical": "/a"}, "after_state": {"canonical": "/b"},
    })
    with pytest.raises(ValueError):
        orch.apply_action(action_id)


def test_approve_then_apply_then_rollback(db, site_id):
    orch = Orchestrator(db, site_id)
    action_id = db.propose_action(site_id, {
        "action_type": "update_meta_description", "description": "fix meta",
        "risk_level": "low", "before_state": {"meta": "old"}, "after_state": {"meta": "new"},
    })
    orch.approve_action(action_id)
    orch.apply_action(action_id)
    applied = [a for a in db.get_actions(site_id) if a["id"] == action_id][0]
    assert applied["status"] == "applied"
    orch.rollback_action(action_id)
    rolled_back = [a for a in db.get_actions(site_id) if a["id"] == action_id][0]
    assert rolled_back["status"] == "rolled_back"


def test_propose_action_is_idempotent(db, site_id):
    a1 = db.propose_action(site_id, {
        "action_type": "resolve:missing_title", "description": "fix it",
        "risk_level": "low", "idempotency_key": "same-key",
    })
    a2 = db.propose_action(site_id, {
        "action_type": "resolve:missing_title", "description": "fix it again",
        "risk_level": "low", "idempotency_key": "same-key",
    })
    assert a1 == a2
    assert len(db.get_actions(site_id)) == 1


def test_propose_action_without_key_always_creates_new(db, site_id):
    a1 = db.propose_action(site_id, {
        "action_type": "resolve:missing_title", "description": "fix it",
        "risk_level": "low",
    })
    a2 = db.propose_action(site_id, {
        "action_type": "resolve:missing_title", "description": "fix it",
        "risk_level": "low",
    })
    assert a1 != a2


def test_rerunning_audit_does_not_duplicate_actions(db, site_id, fixture_base_url):
    from seo_os.config import CrawlConfig
    orch = Orchestrator(db, site_id)
    cfg = CrawlConfig(max_pages=100, allow_private_targets=True)
    orch.run_full_audit(fixture_base_url, crawl_config=cfg)
    first_count = len(db.get_actions(site_id))
    orch.run_full_audit(fixture_base_url, crawl_config=cfg)
    second_count = len(db.get_actions(site_id))
    assert second_count == first_count, (
        "Re-running the audit against an unchanged site rediscovered the same "
        "issues and must reuse the same idempotency-keyed actions, not duplicate them."
    )


def test_full_audit_creates_change_managed_actions_not_silent_edits(db, site_id, fixture_base_url):
    from seo_os.config import CrawlConfig
    orch = Orchestrator(db, site_id)
    orch.run_full_audit(fixture_base_url, crawl_config=CrawlConfig(allow_private_targets=True))
    actions = db.get_actions(site_id)
    assert len(actions) > 0
    assert all(a["status"] == "proposed" for a in actions)  # nothing auto-applied by default
