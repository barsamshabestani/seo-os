from seo_os.agents.crawler_agent import CrawlerAgent, normalize_url
from seo_os.config import CrawlConfig


def _cfg():
    return CrawlConfig(max_pages=100, allow_private_targets=True)


def test_snapshot_created_on_each_crawl(db, site_id, fixture_base_url):
    crawler = CrawlerAgent(db, site_id, _cfg())
    crawler.crawl(fixture_base_url)
    crawler.crawl(fixture_base_url)  # crawl again, unchanged site
    page = db.get_page_by_url(site_id, normalize_url(fixture_base_url))
    snapshots = db.get_page_snapshots(site_id, page["id"])
    assert len(snapshots) == 2, "each crawl run must append a snapshot, not overwrite history"


def test_pages_table_reflects_current_state_not_first_state(db, site_id, fixture_base_url):
    """The `pages` table is the fast current-state view; upsert_page must
    still update it in place (history lives in page_snapshots, not here)."""
    crawler = CrawlerAgent(db, site_id, _cfg())
    run1 = crawler.crawl(fixture_base_url)
    run2 = crawler.crawl(fixture_base_url)
    page = db.get_page_by_url(site_id, normalize_url(fixture_base_url))
    assert page["crawl_run_id"] == run2, "pages.crawl_run_id should reflect the most recent crawl"


def test_get_changed_pages_detects_title_change(db, site_id, fixture_base_url):
    import sqlite3
    crawler = CrawlerAgent(db, site_id, _cfg())
    run1 = crawler.crawl(fixture_base_url)

    # Simulate a real change between crawls by hand-editing the snapshot the
    # same way a re-crawl after a site edit would produce a different one.
    page = db.get_page_by_url(site_id, normalize_url(fixture_base_url))
    run2 = db.start_crawl_run(site_id)
    db.conn.execute(
        """INSERT INTO page_snapshots (site_id, page_id, crawl_run_id, normalized_url,
           status_code, canonical_url, is_indexable, noindex, title, meta_description, h1,
           word_count, content_hash, html_size_bytes, snapshot_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?, strftime('%s','now'))""",
        (site_id, page["id"], run2, page["normalized_url"], 200, None, 1, 0,
         "A Brand New Title", "desc", "H1", 500, "differenthash", 1000),
    )
    db.conn.commit()

    changes = db.get_changed_pages(site_id, run1, run2)
    assert len(changes) == 1
    assert changes[0]["url"] == page["normalized_url"]
    assert "title" in changes[0]["changes"]
    assert changes[0]["changes"]["title"]["after"] == "A Brand New Title"


def test_get_changed_pages_no_diff_when_unchanged(db, site_id, fixture_base_url):
    crawler = CrawlerAgent(db, site_id, _cfg())
    run1 = crawler.crawl(fixture_base_url)
    run2 = crawler.crawl(fixture_base_url)
    changes = db.get_changed_pages(site_id, run1, run2)
    assert changes == []


def test_get_latest_two_crawl_runs(db, site_id, fixture_base_url):
    crawler = CrawlerAgent(db, site_id, _cfg())
    r1 = crawler.crawl(fixture_base_url)
    r2 = crawler.crawl(fixture_base_url)
    latest_from, latest_to = db.get_latest_two_crawl_runs(site_id)
    assert (latest_from, latest_to) == (r1, r2)
