from seo_os.agents.priority_engine import PriorityInputs, score


def test_higher_impact_scores_higher():
    low = score(PriorityInputs(impact="low", confidence=0.8))
    high = score(PriorityInputs(impact="high", confidence=0.8))
    assert high > low


def test_higher_effort_scores_lower():
    easy = score(PriorityInputs(impact="high", confidence=0.8, effort="low"))
    hard = score(PriorityInputs(impact="high", confidence=0.8, effort="high"))
    assert easy > hard


def test_higher_risk_scores_lower():
    safe = score(PriorityInputs(impact="high", confidence=0.8, risk="low"))
    risky = score(PriorityInputs(impact="high", confidence=0.8, risk="high"))
    assert safe > risky


def test_low_confidence_dampens_score():
    confident = score(PriorityInputs(impact="high", confidence=0.95))
    unsure = score(PriorityInputs(impact="high", confidence=0.1))
    assert confident > unsure


def test_more_affected_urls_scores_higher_with_diminishing_returns():
    few = score(PriorityInputs(impact="medium", confidence=0.7, affected_url_count=1))
    many = score(PriorityInputs(impact="medium", confidence=0.7, affected_url_count=50))
    lots = score(PriorityInputs(impact="medium", confidence=0.7, affected_url_count=5000))
    assert many > few
    # Diminishing returns: going from 50 to 5000 should not scale linearly the
    # way going from 1 to 50 did.
    assert (lots - many) < (many - few) * 50


def test_score_is_nonnegative_and_bounded():
    s = score(PriorityInputs(impact="critical", confidence=1.0, business_value="critical",
                              urgency="high", effort="low", risk="low", affected_url_count=100000))
    assert 0 <= s <= 100
